# -*- coding: utf-8 -*-
"""MikroERP — влезна точка.

Редослед при стартување:
  1. логирање и фаќач на грешки
  2. config.ini (се креира ако го нема)
  3. база: отворање → резервна копија → миграции
  4. главен прозорец
"""

from __future__ import annotations

import sys
import traceback


def _enable_dpi_awareness() -> None:
    """Без ова текстот е заматен на екрани со скалирање (125%, 150%)."""
    if sys.platform != "win32":
        return
    import ctypes

    for attempt in (
        lambda: ctypes.windll.shcore.SetProcessDpiAwareness(1),
        lambda: ctypes.windll.user32.SetProcessDPIAware(),
    ):
        try:
            attempt()
            return
        except Exception:  # noqa: BLE001 — постар Windows, продолжи без DPI
            continue


def _fatal(message: str) -> None:
    """Грешка пред да има прозорец — сепак покажи нешто на корисникот."""
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("MikroERP — грешка при стартување", message)
        root.destroy()
    except Exception:  # noqa: BLE001
        print(message, file=sys.stderr)
    sys.exit(1)


def main() -> None:
    _enable_dpi_awareness()

    from mikroerp import logging_setup
    from mikroerp.logging_setup import log

    logging_setup.setup()
    logging_setup.install_excepthook()

    from mikroerp.config import config
    from mikroerp.db import close_database, open_database
    from mikroerp.migrations import migrate
    from mikroerp.version import VERSION

    log.info("=" * 60)
    log.info("Стартување на MikroERP %s", VERSION)

    cfg = config()
    try:
        database = open_database(cfg.db_path)
    except Exception as exc:  # noqa: BLE001
        log.exception("Базата не може да се отвори")
        _fatal(
            f"Базата на податоци не може да се отвори:\n\n{cfg.db_path}\n\n{exc}\n\n"
            "Провери ја патеката во config.ini → [baza] fajl"
        )
        return

    if cfg.get_bool("backup", "avtomatski", True):
        database.backup(keep=cfg.get_int("backup", "zadrzi_kopii", 15))

    try:
        migrate(database)
    except Exception as exc:  # noqa: BLE001
        log.exception("Миграциите паднаа")
        _fatal(
            f"Базата не може да се надгради:\n\n{exc}\n\n"
            "Најновата резервна копија е во папката backups."
        )
        return

    from mikroerp.repo import paycodes

    paycodes.ensure_seed()      # шифрарникот на шифри за плаќање при прво стартување

    from mikroerp.ui.main_window import MainWindow

    app = MainWindow()
    try:
        app.mainloop()
    finally:
        close_database()
        log.info("Крај.")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001 — последна одбрана
        _fatal("Неочекувана грешка при стартување:\n\n" + traceback.format_exc())
