# -*- coding: utf-8 -*-
"""Магацини.

Засега се работи со еден стандарден магацин и изборот е скриен во екраните,
но сите документи и движења го носат `warehouse_id`, па вклучувањето повеќе
магацини подоцна е само нов екран — без миграција на постоечките податоци.
"""

from __future__ import annotations

import sqlite3

from ..db import db

TABLE = "warehouses"


class ValidationError(ValueError):
    pass


def list_all(only_active: bool = False) -> list[sqlite3.Row]:
    sql = "SELECT * FROM warehouses"
    if only_active:
        sql += " WHERE active = 1"
    sql += " ORDER BY is_default DESC, name COLLATE NOCASE"
    return db().query(sql)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one("SELECT * FROM warehouses WHERE id = ?", (rec_id,))


def default() -> sqlite3.Row:
    """Стандардниот магацин; ако некако недостасува — се создава."""
    row = db().one("SELECT * FROM warehouses WHERE is_default = 1 ORDER BY id LIMIT 1")
    if row is None:
        row = db().one("SELECT * FROM warehouses ORDER BY id LIMIT 1")
    if row is None:
        database = db()
        with database.tx():
            new_id = database.insert(TABLE, {"code": "01", "name": "Главен магацин",
                                             "is_default": 1})
        row = get(new_id)
    return row


def default_id() -> int:
    return int(default()["id"])


def options(only_active: bool = True) -> list[tuple[int, str]]:
    return [(int(r["id"]), r["name"]) for r in list_all(only_active)]


def _clean(data: dict) -> dict:
    return {
        "code": str(data.get("code") or "").strip(),
        "name": str(data.get("name") or "").strip(),
        "address": str(data.get("address") or "").strip(),
        "note": str(data.get("note") or "").strip(),
        "is_default": 1 if data.get("is_default") else 0,
        "active": 1 if data.get("active", True) else 0,
    }


def _validate(payload: dict, rec_id: int | None = None) -> None:
    if not payload["name"]:
        raise ValidationError("Внеси име на магацинот.")
    exists = db().one(
        "SELECT id FROM warehouses WHERE name = ? COLLATE NOCASE AND id IS NOT ?",
        (payload["name"], rec_id),
    )
    if exists:
        raise ValidationError(f"Веќе постои магацин „{payload['name']}“.")


def create(data: dict) -> int:
    payload = _clean(data)
    _validate(payload)
    database = db()
    with database.tx():
        new_id = database.insert(TABLE, payload)
        if payload["is_default"]:
            database.execute("UPDATE warehouses SET is_default = 0 WHERE id <> ?", (new_id,))
        return new_id


def update(rec_id: int, data: dict) -> None:
    payload = _clean(data)
    _validate(payload, rec_id)
    database = db()
    with database.tx():
        database.update(TABLE, rec_id, payload)
        database.execute(
            "UPDATE warehouses SET updated_at = datetime('now','localtime') WHERE id = ?",
            (rec_id,))
        if payload["is_default"]:
            database.execute("UPDATE warehouses SET is_default = 0 WHERE id <> ?", (rec_id,))


def usage(rec_id: int) -> int:
    """Колку движења има во овој магацин (пред бришење)."""
    return int(db().scalar("SELECT COUNT(*) FROM stock_moves WHERE warehouse_id = ?",
                           (rec_id,), default=0) or 0)


def delete(rec_id: int) -> None:
    if usage(rec_id):
        raise ValidationError("Магацинот има движења и не може да се избрише.\n\n"
                              "Означи го како неактивен ако повеќе не се користи.")
    if int(db().scalar("SELECT COUNT(*) FROM warehouses", default=0) or 0) <= 1:
        raise ValidationError("Мора да остане барем еден магацин.")
    database = db()
    with database.tx():
        database.delete(TABLE, rec_id)
        if not database.one("SELECT id FROM warehouses WHERE is_default = 1"):
            first = database.one("SELECT id FROM warehouses ORDER BY id LIMIT 1")
            if first:
                database.execute("UPDATE warehouses SET is_default = 1 WHERE id = ?",
                                 (first["id"],))


def count() -> int:
    return int(db().scalar("SELECT COUNT(*) FROM warehouses WHERE active = 1", default=0) or 0)


def many() -> bool:
    """Дали воопшто има смисла да се прикажува избор на магацин."""
    return count() > 1
