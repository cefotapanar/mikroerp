# -*- coding: utf-8 -*-
"""Банки и трансакциски сметки на фирмата.

Фирмата може да има повеќе сметки, во иста или во различни банки. За секоја се
одлучува дали се печати на фактурата, а изводите се водат **по сметка** — затоа
изборот на сметка во изводите се полни од тука.
"""

from __future__ import annotations

import re
import sqlite3

from ..db import db


class ValidationError(ValueError):
    pass


def clean_no(account: str) -> str:
    """Само цифри — сметките се пишуваат со и без цртички."""
    return re.sub(r"\D", "", str(account or ""))


def list_all(only_active: bool = False) -> list[sqlite3.Row]:
    sql = "SELECT * FROM bank_accounts WHERE 1 = 1"
    if only_active:
        sql += " AND active = 1"
    sql += " ORDER BY sort_order, id"
    return db().query(sql)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one("SELECT * FROM bank_accounts WHERE id = ?", (rec_id,))


def by_account(account_no: str) -> sqlite3.Row | None:
    digits = clean_no(account_no)
    if not digits:
        return None
    return db().one(
        "SELECT * FROM bank_accounts "
        "WHERE REPLACE(REPLACE(account_no, '-', ''), ' ', '') = ?", (digits,))


def for_invoice() -> list[sqlite3.Row]:
    """Сметките што се печатат на документите."""
    return db().query("SELECT * FROM bank_accounts WHERE active = 1 "
                      "AND show_on_invoice = 1 ORDER BY sort_order, id")


def options(only_active: bool = True) -> list[tuple]:
    """(сметка, натпис) за паѓачките менија."""
    rows = list_all(only_active=only_active)
    return [(row["account_no"],
             f"{row['account_no']} — {row['bank_name']}" if row["bank_name"]
             else row["account_no"]) for row in rows]


def label(account_no: str) -> str:
    row = by_account(account_no)
    if row is None:
        return str(account_no or "")
    return (f"{row['account_no']} — {row['bank_name']}" if row["bank_name"]
            else row["account_no"])


def statement_count(account_no: str) -> int:
    """Колку изводи има внесено на таа сметка."""
    return int(db().scalar(
        "SELECT COUNT(*) FROM bank_statements "
        "WHERE REPLACE(REPLACE(account, '-', ''), ' ', '') = ?",
        (clean_no(account_no),), default=0) or 0)


def save(rec_id: int | None, data: dict) -> int:
    account = str(data.get("account_no") or "").strip()
    if not account:
        raise ValidationError("Внеси трансакциска сметка.")
    existing = by_account(account)
    if existing is not None and (rec_id is None or int(existing["id"]) != int(rec_id)):
        raise ValidationError(f"Сметката {account} веќе е внесена.")

    payload = {
        "bank_name": str(data.get("bank_name") or "").strip(),
        "account_no": account,
        "show_on_invoice": 1 if data.get("show_on_invoice", True) else 0,
        "active": 1 if data.get("active", True) else 0,
        "sort_order": int(data.get("sort_order") or 0),
        "note": str(data.get("note") or "").strip(),
    }
    database = db()
    with database.tx():
        if rec_id:
            database.update("bank_accounts", rec_id, payload)
        else:
            rec_id = database.insert("bank_accounts", payload)
    return int(rec_id)


def delete(rec_id: int) -> None:
    """Сметка со изводи не се брише — инаку изводите остануваат без сопственик."""
    row = get(rec_id)
    if row is None:
        return
    used = db().scalar(
        "SELECT COUNT(*) FROM bank_statements "
        "WHERE REPLACE(REPLACE(account, '-', ''), ' ', '') = ?",
        (clean_no(row["account_no"]),), default=0)
    if used:
        raise ValidationError(
            f"На сметката {row['account_no']} има {used} извод(и).\n\n"
            "Означи ја како неактивна наместо да ја бришеш.")
    db().delete("bank_accounts", rec_id)


def ensure(account_no: str, bank_name: str = "") -> int | None:
    """Ја додава сметката ако сè уште ја нема (пр. онаа што ја дава УЈП)."""
    account = str(account_no or "").strip()
    if not account:
        return None
    found = by_account(account)
    if found is not None:
        return int(found["id"])
    return save(None, {"account_no": account, "bank_name": bank_name})
