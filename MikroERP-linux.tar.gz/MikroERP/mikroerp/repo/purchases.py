﻿# -*- coding: utf-8 -*-
"""Влезни фактури — обврска кон добавувач.

Огледало на излезната фактура:
  * **направена од приемница** — стоката веќе влегла, фактурата само ја
    евидентира обврската и рокот на плаќање;
  * **самостојна** — сама ја внесува стоката во магацин по FIFO (за кога се
    купува без посебна приемница, или за услуги што и онака не одат на лагер).
"""

from __future__ import annotations

import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q, q2
from . import docnum, items, receipts, stock, warehouses
from .doclines import ValidationError, clean_line, line_amounts, totals_of  # noqa: F401

DOC_TYPE = "vlezna_faktura"
STOCK_TYPE = "vlezna_faktura"


# ------------------------------------------------------------------- листа
def list_all(search: str = "", year: int | None = None) -> list[sqlite3.Row]:
    sql = [
        "SELECT f.*, COALESCE(p.name, '') AS partner_name,",
        "       COALESCE(r.doc_no, '') AS receipt_no,",
        "       (SELECT COUNT(*) FROM purchase_invoice_items l WHERE l.doc_id = f.id) AS lines_count",
        "FROM purchase_invoices f",
        "LEFT JOIN partners p ON p.id = f.partner_id",
        "LEFT JOIN goods_receipts r ON r.id = f.receipt_id",
        "WHERE 1 = 1",
    ]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(f.doc_no, '') || ' ' || COALESCE(f.supplier_doc, '') || ' ' || COALESCE(p.name, '') || ' ' || COALESCE(f.note, ''), ?)")
        params.append(text)
    if year:
        sql.append("AND f.doc_year = ?")
        params.append(year)
    sql.append("ORDER BY f.doc_year DESC, f.doc_seq DESC")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT f.*, COALESCE(p.name, '') AS partner_name, "
        "       COALESCE(r.doc_no, '') AS receipt_no "
        "FROM purchase_invoices f "
        "LEFT JOIN partners p ON p.id = f.partner_id "
        "LEFT JOIN goods_receipts r ON r.id = f.receipt_id WHERE f.id = ?",
        (rec_id,),
    )


def lines(rec_id: int) -> list[sqlite3.Row]:
    return db().query(
        "SELECT l.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit "
        "FROM purchase_invoice_items l JOIN items i ON i.id = l.item_id "
        "WHERE l.doc_id = ? ORDER BY l.line_no, l.id",
        (rec_id,),
    )


def header_of(record) -> dict:
    return {
        "id": record["id"], "doc_no": record["doc_no"], "date": record["date"],
        "due_date": record["due_date"], "partner_id": record["partner_id"],
        "warehouse_id": record["warehouse_id"], "receipt_id": record["receipt_id"],
        "supplier_doc": record["supplier_doc"], "supplier_date": record["supplier_date"],
        "update_prices": bool(record["update_prices"]), "note": record["note"],
        "use_full_name": bool(record["use_full_name"]),
    }


def blank(when: str | None = None) -> dict:
    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    return {
        "id": None,
        "doc_no": docnum.peek(DOC_TYPE, year)[1],
        "date": when,
        "due_date": "",
        "partner_id": None,
        "warehouse_id": warehouses.default_id(),
        "receipt_id": None,
        "supplier_doc": "",
        "supplier_date": "",
        "update_prices": True,
        "note": "",
        "use_full_name": False,
    }


def totals(rec_id: int) -> tuple:
    row = db().one("SELECT total_net, total_vat, total_gross FROM purchase_invoices "
                   "WHERE id = ?", (rec_id,))
    if row is None:
        return D(0), D(0), D(0)
    return q2(row["total_net"]), q2(row["total_vat"]), q2(row["total_gross"])


# ------------------------------------------------------------------ снимање
def save_document(rec_id: int | None, header: dict, doc_lines: list[dict]) -> int:
    if not header.get("partner_id"):
        raise ValidationError("Избери добавувач.")
    if not doc_lines:
        raise ValidationError("Влезната фактура нема ниту една ставка.")
    clean = [clean_line(line) for line in doc_lines]

    when = str(header.get("date") or _date.today().isoformat())
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    warehouse_id = int(header.get("warehouse_id") or warehouses.default_id())
    receipt_id = header.get("receipt_id")
    update_prices = bool(header.get("update_prices", True))
    # Фактура по приемница не ја движи залихата — стоката веќе влегла.
    moves_stock = not receipt_id

    database = db()
    with database.tx():
        if rec_id:
            existing = database.one("SELECT * FROM purchase_invoices WHERE id = ?", (rec_id,))
            if existing is None:
                raise ValidationError("Влезната фактура не постои.")
            if existing["moves_stock"]:
                stock.revert_document(STOCK_TYPE, rec_id)
            database.execute("DELETE FROM purchase_invoice_items WHERE doc_id = ?", (rec_id,))
            doc_no = existing["doc_no"]
            database.execute(
                "UPDATE purchase_invoices SET date = ?, due_date = ?, partner_id = ?, "
                "warehouse_id = ?, supplier_doc = ?, supplier_date = ?, "
                "update_prices = ?, moves_stock = ?, note = ?, "
                "updated_at = datetime('now','localtime'), use_full_name = ? WHERE id = ?",
                (when, str(header.get("due_date") or ""), int(header["partner_id"]),
                 warehouse_id, str(header.get("supplier_doc") or "").strip(),
                 str(header.get("supplier_date") or ""),
                 1 if update_prices else 0, 1 if moves_stock else 0,
                 str(header.get("note") or "").strip(),
                 1 if header.get("use_full_name") else 0, rec_id),
            )
        else:
            seq, doc_no, doc_year = docnum.take(DOC_TYPE, year)
            rec_id = database.insert("purchase_invoices", {
                "doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq,
                "date": when, "due_date": str(header.get("due_date") or ""),
                "partner_id": int(header["partner_id"]), "warehouse_id": warehouse_id,
                "receipt_id": int(receipt_id) if receipt_id else None,
                "supplier_doc": str(header.get("supplier_doc") or "").strip(),
                "supplier_date": str(header.get("supplier_date") or ""),
                "update_prices": 1 if update_prices else 0,
                "moves_stock": 1 if moves_stock else 0,
                "note": str(header.get("note") or "").strip(),
                "use_full_name": 1 if header.get("use_full_name") else 0,
            })

        for index, line in enumerate(clean, start=1):
            database.insert("purchase_invoice_items",
                            dict(line, doc_id=rec_id, line_no=index))
            if moves_stock:
                qty = D(line["qty"])
                unit_cost = q(D(line["net"]) / qty, 4) if qty else D(0)
                stock.receive(
                    item_id=line["item_id"], warehouse_id=warehouse_id, date=when,
                    doc_type=STOCK_TYPE, doc_id=rec_id, doc_no=doc_no,
                    qty=qty, unit_cost=unit_cost,
                )
                if update_prices:
                    items.set_purchase_price(line["item_id"], unit_cost)

        net, vat, gross = totals_of(clean)
        database.execute(
            "UPDATE purchase_invoices SET total_net = ?, total_vat = ?, total_gross = ? "
            "WHERE id = ?", (float(net), float(vat), float(gross), rec_id),
        )
    return int(rec_id)


def delete(rec_id: int) -> None:
    from . import links
    links.forget(links.VLEZNA, rec_id)
    rec = get(rec_id)
    if rec is None:
        return
    database = db()
    with database.tx():
        if rec["moves_stock"]:
            stock.revert_document(STOCK_TYPE, rec_id)
        database.delete("purchase_invoices", rec_id)


# ------------------------------------------------------------- претворања
def invoice_no_for_receipt(receipt_id: int) -> str:
    row = db().one("SELECT doc_no FROM purchase_invoices WHERE receipt_id = ?", (receipt_id,))
    return row["doc_no"] if row else ""


def from_receipt(receipt_id: int) -> int:
    """Приемница → влезна фактура (стоката веќе влегла, само се евидентира)."""
    receipt = receipts.get(receipt_id)
    if receipt is None:
        raise ValidationError("Приемницата не постои.")
    existing = invoice_no_for_receipt(receipt_id)
    if existing:
        raise ValidationError(f"Приемницата е веќе фактурирана со {existing}.")
    header = {
        "date": _date.today().isoformat(), "due_date": "",
        "partner_id": receipt["partner_id"], "warehouse_id": receipt["warehouse_id"],
        "receipt_id": receipt_id,
        "supplier_doc": receipt["supplier_doc"], "supplier_date": receipt["supplier_date"],
        "update_prices": False,
        "note": f"По приемница {receipt['doc_no']}",
    }
    rows = [{"item_id": r["item_id"], "qty": r["qty"], "price": r["price"],
             "discount": r["discount"], "tax_rate": r["tax_rate"]}
            for r in receipts.lines(receipt_id)]
    new_id = save_document(None, header, rows)
    from . import links
    links.link(links.PRIEMNICA, receipt_id, links.VLEZNA, new_id)
    return new_id
