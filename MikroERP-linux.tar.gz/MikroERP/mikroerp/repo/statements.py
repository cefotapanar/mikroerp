﻿# -*- coding: utf-8 -*-
"""Банкарски изводи.

Изводот може да се внесе рачно или да се увезе од MT940 датотека.
Секоја ставка се обидува сама да го погоди клиентот:

  1. по **сметката** на другата страна (`partners.bank_account`);
  2. по **нормализирано име** (се тргаат ДООЕЛ/ДОО/АД, интерпункција…);
  3. по единствен почеток на името.

Кога ставката ќе се зачува со рачно избран клиент, **сметката се памети** во
шифрарникот — следниот увоз веднаш ја погодува. Кај шифрите каде другата
страна е самата банка (провизии, откуп девизи) не се погодува и не се памети.

Место за AI: `suggest_partner()` е единствената точка на погодување. Кога ќе се
вклучи AI, доволно е таа да добие уште еден чекор — сè друго останува исто и
работи и без AI.
"""

from __future__ import annotations

import re
import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q2
from ..util import fold
from . import expenses, paycodes, payments

IN = "прилив"
OUT = "одлив"

SOURCE_MANUAL = "рачно"
SOURCE_MT940 = "MT940"

# Наставки што не помагаат при споредба на имиња
_SUFFIX_RE = re.compile(
    r"\b(дооел|доо|д\.о\.о|ад|акционерско|друштво|друштвo|тп|увоз|извоз|"
    r"dooel|doo|d\.o\.o|ltd|llc|inc)\b", re.IGNORECASE)


class ValidationError(ValueError):
    pass


# ------------------------------------------------------------------- листа
def list_all(search: str = "", year: int | None = None,
             account: str = "") -> list[sqlite3.Row]:
    sql = [
        "SELECT s.*, (SELECT COUNT(*) FROM bank_statement_lines l "
        "             WHERE l.statement_id = s.id) AS lines_count,",
        "       (SELECT COUNT(*) FROM bank_statement_lines l "
        "        WHERE l.statement_id = s.id AND l.partner_id IS NULL "
        "          AND l.expense_id IS NULL) AS unmatched",
        "FROM bank_statements s WHERE 1 = 1",
    ]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(s.doc_no, '') || ' ' || COALESCE(s.account, '') || ' ' || COALESCE(s.bank_name, '') || ' ' || COALESCE(s.note, '') || ' ' || COALESCE(s.file_name, ''), ?)")
        params.append(text)
    if year:
        sql.append("AND s.year = ?")
        params.append(year)
    if account:
        # сметката се пишува со и без цртички — се споредува по цифри
        sql.append("AND REPLACE(REPLACE(s.account, '-', ''), ' ', '') = ?")
        params.append(re.sub(r"\D", "", str(account)))
    sql.append("ORDER BY s.date DESC, s.id DESC")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one("SELECT * FROM bank_statements WHERE id = ?", (rec_id,))


def lines(rec_id: int) -> list[sqlite3.Row]:
    return db().query(
        "SELECT l.*, COALESCE(p.name, '') AS partner_name "
        "FROM bank_statement_lines l LEFT JOIN partners p ON p.id = l.partner_id "
        "WHERE l.statement_id = ? ORDER BY l.line_no, l.id",
        (rec_id,),
    )


def find(account: str, year: int, doc_no: str) -> sqlite3.Row | None:
    return db().one(
        "SELECT * FROM bank_statements WHERE account = ? AND year = ? AND doc_no = ?",
        (str(account or ""), int(year), str(doc_no)),
    )


def blank(when: str | None = None) -> dict:
    when = when or _date.today().isoformat()
    return {
        "id": None, "account": "", "bank_name": "", "doc_no": "",
        "year": int(when[:4]) if when[:4].isdigit() else _date.today().year,
        "date": when, "opening": D(0), "closing": D(0),
        "ref": "", "source": SOURCE_MANUAL, "file_name": "", "note": "",
    }


def last_statement(account: str = "") -> sqlite3.Row | None:
    """Последниот внесен извод (по датум), по избор на дадена сметка."""
    sql = "SELECT * FROM bank_statements WHERE 1 = 1"
    params: list = []
    if account:
        sql += " AND account = ?"
        params.append(str(account))
    sql += " ORDER BY date DESC, id DESC LIMIT 1"
    return db().one(sql, params)


def next_doc_no(account: str, year: int) -> str:
    """Кој број следи на таа сметка во таа година."""
    rows = db().query(
        "SELECT doc_no FROM bank_statements WHERE account = ? AND year = ?",
        (str(account or ""), int(year)),
    )
    numbers = []
    for row in rows:
        digits = re.sub(r"\D", "", str(row["doc_no"] or ""))
        if digits:
            numbers.append(int(digits))
    return str(max(numbers) + 1) if numbers else "1"


def propose_new(when: str | None = None, account: str = "") -> dict:
    """Нов извод со предложени вредности — да не се почнува од празно.

    Сметката и банката се земаат од последниот извод, бројот е следниот по ред
    на таа сметка, а почетната состојба е завршната на претходниот извод.
    """
    header = blank(when)
    last = last_statement(account)
    if last is None:
        if account:
            from . import bank_accounts
            row = bank_accounts.by_account(account)
            header["account"] = account
            header["bank_name"] = row["bank_name"] if row is not None else ""
            header["doc_no"] = next_doc_no(account, header["year"])
        else:
            header["doc_no"] = "1"
        return header
    header["account"] = last["account"]
    header["bank_name"] = last["bank_name"]
    header["opening"] = q2(last["closing"])
    header["closing"] = q2(last["closing"])
    header["doc_no"] = next_doc_no(header["account"], header["year"])
    return header


# ------------------------------------------------------- погодување клиент
def _norm_name(name: str) -> str:
    return fold(_SUFFIX_RE.sub(" ", str(name or "")))


def suggest_partner(line: dict) -> tuple[int | None, str]:
    """Кој клиент е другата страна? Враќа (id, како е погоден).

    Тука подоцна ќе се вметне и AI чекор — останатото не се менува.
    """
    if paycodes.always_ask(line.get("code")):
        return None, ""

    database = db()
    account = re.sub(r"\D", "", str(line.get("cp_account") or ""))
    if account:
        row = database.one(
            "SELECT id FROM partners WHERE REPLACE(REPLACE(bank_account, '-', ''), ' ', '') = ?",
            (account,))
        if row:
            return int(row["id"]), "сметка"

    name = _norm_name(line.get("cp_name"))
    if not name:
        return None, ""

    candidates = [(int(r["id"]), _norm_name(r["name"]))
                  for r in database.query("SELECT id, name FROM partners")]
    exact = [pid for pid, folded in candidates if folded == name]
    if len(exact) == 1:
        return exact[0], "име"
    prefix = [pid for pid, folded in candidates
              if folded and (folded.startswith(name) or name.startswith(folded))]
    if len(prefix) == 1:
        return prefix[0], "име"
    return None, ""


def learn_account(partner_id: int, line: dict) -> None:
    """Ја памети сметката на клиентот, ако сè уште ја нема."""
    if not partner_id:
        return
    if paycodes.always_ask(line.get("code")):
        return
    account = re.sub(r"\D", "", str(line.get("cp_account") or ""))
    if not account:
        return
    row = db().one("SELECT bank_account FROM partners WHERE id = ?", (partner_id,))
    if row is not None and not str(row["bank_account"] or "").strip():
        db().execute("UPDATE partners SET bank_account = ?, "
                     "updated_at = datetime('now','localtime') WHERE id = ?",
                     (account, partner_id))


# ------------------------------------------------------------------ снимање
def _clean_line(data: dict, index: int) -> dict:
    amount = q2(data.get("amount") or 0)
    if amount < 0:
        amount = -amount
    direction = str(data.get("direction") or IN)
    if direction not in (IN, OUT):
        direction = IN
    return {
        "line_no": index,
        "date": str(data.get("date") or ""),
        "direction": direction,
        "amount": float(amount),
        "cp_account": str(data.get("cp_account") or "").strip(),
        "cp_name": str(data.get("cp_name") or "").strip(),
        "purpose": str(data.get("purpose") or "").strip(),
        "code": str(data.get("code") or "").strip(),
        "bank_ref": str(data.get("bank_ref") or "").strip(),
        "partner_id": int(data["partner_id"]) if data.get("partner_id") else None,
        "matched_by": str(data.get("matched_by") or "").strip(),
        "note": str(data.get("note") or "").strip(),
        "expense_id": int(data["expense_id"]) if data.get("expense_id") else None,
    }


def save_document(rec_id: int | None, header: dict, doc_lines: list[dict]) -> int:
    if not str(header.get("doc_no") or "").strip():
        raise ValidationError("Внеси број на изводот.")
    when = str(header.get("date") or _date.today().isoformat())
    year = int(str(header.get("year") or when[:4]) or _date.today().year)
    account = str(header.get("account") or "").strip()

    clean = [_clean_line(line, index) for index, line in enumerate(doc_lines, start=1)]
    total_in = q2(sum((D(l["amount"]) for l in clean if l["direction"] == IN), D(0)))
    total_out = q2(sum((D(l["amount"]) for l in clean if l["direction"] == OUT), D(0)))

    existing = find(account, year, str(header["doc_no"]).strip())
    if existing is not None and (rec_id is None or int(existing["id"]) != int(rec_id)):
        raise ValidationError(
            f"Извод бр. {header['doc_no']} за {year} на сметка {account or '—'} "
            "веќе постои."
        )

    database = db()
    with database.tx():
        payload = {
            "account": account,
            "bank_name": str(header.get("bank_name") or "").strip(),
            "doc_no": str(header["doc_no"]).strip(),
            "year": year, "date": when,
            "opening": float(q2(header.get("opening") or 0)),
            "closing": float(q2(header.get("closing") or 0)),
            "total_in": float(total_in), "total_out": float(total_out),
            "ref": str(header.get("ref") or "").strip(),
            "source": str(header.get("source") or SOURCE_MANUAL),
            "file_name": str(header.get("file_name") or "").strip(),
            "note": str(header.get("note") or "").strip(),
        }
        if rec_id:
            database.update("bank_statements", rec_id, payload)
            database.execute("UPDATE bank_statements SET updated_at = "
                             "datetime('now','localtime') WHERE id = ?", (rec_id,))
            database.execute("DELETE FROM bank_statement_lines WHERE statement_id = ?",
                             (rec_id,))
        else:
            rec_id = database.insert("bank_statements", payload)

        prefix = expenses.origin_prefix(account, year, payload["doc_no"])
        used: list[int] = []
        for source_line, line in zip(doc_lines, clean):
            line_id = database.insert("bank_statement_lines",
                                      dict(line, statement_id=rec_id))
            if line["partner_id"]:
                learn_account(int(line["partner_id"]), line)
            expense_id = _apply_expense_and_payments(line_id, source_line, line, prefix)
            if expense_id:
                used.append(expense_id)
        # Трошоци што овој извод ги создал, а веќе не му требаат (ставката е
        # избришана или одштиклирана) — заминуваат со него.
        expenses.delete_by_origin(prefix, keep=used)
    return int(rec_id)


def _apply_expense_and_payments(line_id: int, source: dict, line: dict,
                                prefix: str = "") -> int | None:
    """Создава трошок (ако ставката е означена како трошок) и ги врзува уплатите.

    Трошокот НИКОГАШ не се создава двапати за иста ставка: прво се бара по
    потпис (`origin_key`), потоа се усвојува стар трошок без потпис од истиот
    датум и износ, и дури ако нема ништо — се создава нов.
    """
    database = db()
    targets = list(source.get("targets") or [])
    wanted = source.get("expense")

    if not wanted:
        # Ставката повеќе не е трошок — врската се раскинува, а самиот трошок
        # го чисти `delete_by_origin` при снимањето.
        database.execute("UPDATE bank_statement_lines SET expense_id = NULL WHERE id = ?",
                         (line_id,))
        payments.set_for_line(line_id, targets, date=line["date"])
        return None

    key = (prefix + str(line["line_no"])) if prefix else ""
    expense_id = int(source["expense_id"]) if source.get("expense_id") else None
    if not expense_id and key:
        found = expenses.find_by_origin(key)
        if found is None:
            found = expenses.find_orphan(line["date"], line["amount"])
        if found is not None:
            expense_id = int(found["id"])

    expense_id = expenses.save_document(expense_id, {
        "date": line["date"],
        "partner_id": line["partner_id"],
        "category": wanted.get("category") or expenses.DEFAULT_BANK_CATEGORY,
        "description": wanted.get("description") or line["purpose"] or line["cp_name"],
        "amount": line["amount"],
        "vat_rate": wanted.get("vat_rate") or 0,
        "source": expenses.SOURCE_BANK,
        "note": wanted.get("note") or "",
        "origin_key": key,
    })
    database.execute("UPDATE bank_statement_lines SET expense_id = ? WHERE id = ?",
                     (expense_id, line_id))
    targets.append({"kind": payments.KIND_EXPENSE, "id": expense_id,
                    "amount": line["amount"]})
    payments.set_for_line(line_id, targets, date=line["date"])
    return int(expense_id)


def expense_ids(rec_id: int) -> list[int]:
    """Трошоците што ги создал овој извод."""
    found = {int(r["expense_id"]) for r in db().query(
        "SELECT expense_id FROM bank_statement_lines "
        "WHERE statement_id = ? AND expense_id IS NOT NULL", (rec_id,))}
    record = get(rec_id)
    if record is not None:
        prefix = expenses.origin_prefix(record["account"], record["year"],
                                        record["doc_no"])
        found |= {int(r["id"]) for r in expenses.by_origin_prefix(prefix)}
    return sorted(found)


def delete(rec_id: int) -> None:
    """Изводот ги носи со себе и трошоците што сам ги создал.

    Инаку трошокот останува сирак: изводот го нема, а при повторен увоз ќе се
    создаде уште еден ист трошок.
    """
    database = db()
    doomed = expense_ids(rec_id)
    with database.tx():
        database.delete("bank_statements", rec_id)
        for expense_id in doomed:
            expenses.delete(expense_id)


def balance_check(header: dict, doc_lines: list[dict]) -> tuple:
    """(пресметана завршна состојба, се совпаѓа ли со внесената)."""
    total = D(header.get("opening") or 0)
    for line in doc_lines:
        amount = D(line.get("amount") or 0)
        total += amount if line.get("direction") == IN else -amount
    computed = q2(total)
    return computed, computed == q2(header.get("closing") or 0)


# --------------------------------------------------------------- увоз MT940
def prepare_import(parsed: list[dict], file_name: str = "") -> list[dict]:
    """Од испарсираните изводи прави документи спремни за преглед и снимање."""
    result = []
    for statement in parsed:
        when = statement.get("date") or _date.today().isoformat()
        year = int(when[:4]) if when[:4].isdigit() else _date.today().year
        header = {
            "id": None,
            "account": statement.get("account") or "",
            "bank_name": "",
            "doc_no": statement.get("izvod_broj") or "",
            "year": year,
            "date": when,
            "opening": q2(statement.get("opening") or 0),
            "closing": q2(statement.get("closing") or 0),
            "ref": statement.get("ref") or "",
            "source": SOURCE_MT940,
            "file_name": file_name,
            "note": "",
        }
        rows = []
        for entry in statement.get("entries", []):
            line = {
                "date": entry.get("date") or when,
                "direction": IN if entry.get("dc") == "C" else OUT,
                "amount": q2(entry.get("amount") or 0),
                "cp_account": entry.get("cp_account") or "",
                "cp_name": entry.get("cp_name") or "",
                "purpose": entry.get("purpose") or "",
                "code": entry.get("code") or "",
                "bank_ref": entry.get("bank_ref") or "",
            }
            partner_id, how = suggest_partner(line)
            line["partner_id"] = partner_id
            line["matched_by"] = how
            # Провизиите и слични банкарски одливи не бараат клиент —
            # тие се самите по себе трошок.
            if line["direction"] == OUT and paycodes.is_bank_fee(line["code"]):
                line["expense"] = {
                    "category": paycodes.expense_category(line["code"], expenses.DEFAULT_BANK_CATEGORY),
                    "description": paycodes.label(line["code"]) or line["purpose"],
                    "vat_rate": 0,
                }
            rows.append(line)

        computed, ok = balance_check(header, rows)
        existing = find(header["account"], year, header["doc_no"])
        result.append({
            "header": header, "lines": rows,
            "balanced": ok, "computed_closing": computed,
            "duplicate": existing["doc_no"] if existing is not None else "",
            "matched": sum(1 for r in rows if r["partner_id"]),
        })
    return result
