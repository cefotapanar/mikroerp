﻿# -*- coding: utf-8 -*-
"""Профактури и излезни фактури.

Двата документа делат иста табела, за да може профактурата да се претвори во
фактура без препишување.

Кој документ ја движи залихата:
  * **профактура** — никогаш (тоа е понуда);
  * **фактура** — да, освен ако е направена од испратница; тогаш стоката веќе
    излегла и фактурата само ја наплаќа.
"""

from __future__ import annotations

import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q2
from . import docnum, issues, stock, warehouses
from .doclines import ValidationError, clean_line, line_amounts, totals_of  # noqa: F401

KIND_PROFORMA = "profaktura"
KIND_INVOICE = "faktura"

# Тип за нумерирање и за движењата на залихата
NUMBER_TYPE = {KIND_PROFORMA: "profaktura", KIND_INVOICE: "izlezna_faktura"}
STOCK_TYPE = "izlezna_faktura"

LABEL = {KIND_PROFORMA: "Профактура", KIND_INVOICE: "Излезна фактура"}


# ------------------------------------------------------------------- листа
def list_all(kind: str, search: str = "", year: int | None = None,
             date_from: str = "", date_to: str = "",
             classification: str = "") -> list[sqlite3.Row]:
    sql = [
        "SELECT d.*, COALESCE(p.name, '') AS partner_name,",
        "       COALESCE(g.doc_no, '') AS issue_no,",
        "       COALESCE(s.doc_no, '') AS source_no,",
        "       (SELECT COUNT(*) FROM sales_doc_items l WHERE l.doc_id = d.id) AS lines_count,",
        "       (SELECT doc_no FROM sales_docs c WHERE c.source_id = d.id LIMIT 1) AS converted_no",
        "FROM sales_docs d",
        "LEFT JOIN partners p ON p.id = d.partner_id",
        "LEFT JOIN goods_issues g ON g.id = d.issue_id",
        "LEFT JOIN sales_docs s ON s.id = d.source_id",
        "WHERE d.kind = ?",
    ]
    params: list = [kind]
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(d.doc_no, '') || ' ' || COALESCE(p.name, '') || ' ' || COALESCE(d.note, '') || ' ' || COALESCE(d.classification, ''), ?)")
        params.append(text)
    if year:
        sql.append("AND d.doc_year = ?")
        params.append(year)
    if date_from:
        sql.append("AND d.date >= ?")
        params.append(str(date_from))
    if date_to:
        sql.append("AND d.date <= ?")
        params.append(str(date_to))
    if classification:
        sql.append("AND d.classification = ?")
        params.append(str(classification))
    sql.append("ORDER BY d.doc_year DESC, d.doc_seq DESC")
    return db().query(" ".join(sql), params)


def classifications(kind: str = KIND_INVOICE) -> list[str]:
    """Она што веќе е внесувано — за да не се пишува секој пат одново."""
    return [r["classification"] for r in db().query(
        "SELECT DISTINCT classification FROM sales_docs "
        "WHERE kind = ? AND classification <> '' ORDER BY classification", (kind,))]


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT d.*, COALESCE(p.name, '') AS partner_name, "
        "       COALESCE(g.doc_no, '') AS issue_no, "
        "       (SELECT doc_no FROM sales_docs c WHERE c.source_id = d.id LIMIT 1) AS converted_no "
        "FROM sales_docs d "
        "LEFT JOIN partners p ON p.id = d.partner_id "
        "LEFT JOIN goods_issues g ON g.id = d.issue_id WHERE d.id = ?",
        (rec_id,),
    )


def lines(rec_id: int) -> list[sqlite3.Row]:
    return db().query(
        "SELECT l.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit "
        "FROM sales_doc_items l JOIN items i ON i.id = l.item_id "
        "WHERE l.doc_id = ? ORDER BY l.line_no, l.id",
        (rec_id,),
    )


def header_of(record) -> dict:
    return {
        "id": record["id"], "doc_no": record["doc_no"], "date": record["date"],
        "due_date": record["due_date"], "partner_id": record["partner_id"],
        "warehouse_id": record["warehouse_id"], "issue_id": record["issue_id"],
        "source_id": record["source_id"], "note": record["note"],
        "use_full_name": bool(record["use_full_name"]),
        "classification": record["classification"] or "",
    }


def blank(kind: str, when: str | None = None) -> dict:
    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    return {
        "id": None,
        "doc_no": docnum.peek(NUMBER_TYPE[kind], year)[1],
        "date": when,
        "due_date": "",
        "partner_id": None,
        "warehouse_id": warehouses.default_id(),
        "issue_id": None,
        "source_id": None,
        "note": "",
        "use_full_name": False,
        "classification": "",
    }


def totals(rec_id: int) -> tuple:
    row = db().one("SELECT total_net, total_vat, total_gross FROM sales_docs WHERE id = ?",
                   (rec_id,))
    if row is None:
        return D(0), D(0), D(0)
    return q2(row["total_net"]), q2(row["total_vat"]), q2(row["total_gross"])


# ------------------------------------------------------------------ снимање
def save_document(rec_id: int | None, header: dict, doc_lines: list[dict],
                  kind: str = KIND_INVOICE) -> int:
    if not header.get("partner_id"):
        raise ValidationError("Избери купувач.")
    if not doc_lines:
        raise ValidationError(f"{LABEL[kind]} нема ниту една ставка.")
    clean = [clean_line(line) for line in doc_lines]

    when = str(header.get("date") or _date.today().isoformat())
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    warehouse_id = int(header.get("warehouse_id") or warehouses.default_id())
    issue_id = header.get("issue_id")
    # Фактура направена од испратница не ја движи залихата — веќе е извадена.
    moves_stock = (kind == KIND_INVOICE and not issue_id)

    database = db()
    with database.tx():
        if rec_id:
            existing = database.one("SELECT * FROM sales_docs WHERE id = ?", (rec_id,))
            if existing is None:
                raise ValidationError("Документот не постои.")
            if existing["moves_stock"]:
                stock.revert_document(STOCK_TYPE, rec_id)
            database.execute("DELETE FROM sales_doc_items WHERE doc_id = ?", (rec_id,))
            doc_no = existing["doc_no"]
            database.execute(
                "UPDATE sales_docs SET date = ?, due_date = ?, partner_id = ?, "
                "warehouse_id = ?, note = ?, moves_stock = ?, classification = ?, "
                "updated_at = datetime('now','localtime'), use_full_name = ? WHERE id = ?",
                (when, str(header.get("due_date") or ""), int(header["partner_id"]),
                 warehouse_id, str(header.get("note") or "").strip(),
                 1 if moves_stock else 0,
                 str(header.get("classification") or "").strip(),
                 1 if header.get("use_full_name") else 0, rec_id),
            )
        else:
            seq, doc_no, doc_year = docnum.take(NUMBER_TYPE[kind], year)
            rec_id = database.insert("sales_docs", {
                "kind": kind, "doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq,
                "date": when, "due_date": str(header.get("due_date") or ""),
                "partner_id": int(header["partner_id"]), "warehouse_id": warehouse_id,
                "issue_id": int(issue_id) if issue_id else None,
                "source_id": int(header["source_id"]) if header.get("source_id") else None,
                "moves_stock": 1 if moves_stock else 0,
                "note": str(header.get("note") or "").strip(),
                "use_full_name": 1 if header.get("use_full_name") else 0,
                "classification": str(header.get("classification") or "").strip(),
            })

        total_cost = D(0)
        for index, line in enumerate(clean, start=1):
            cost = D(0)
            if moves_stock:
                taken = stock.issue(
                    item_id=line["item_id"], warehouse_id=warehouse_id, date=when,
                    doc_type=STOCK_TYPE, doc_id=rec_id, doc_no=doc_no, qty=line["qty"],
                )
                cost = q2(sum((t["qty"] * t["unit_cost"] for t in taken), D(0)))
            total_cost += cost
            database.insert("sales_doc_items",
                            dict(line, doc_id=rec_id, line_no=index, cost=float(cost)))

        if issue_id:
            # Цената на чинење ја презема од испратницата.
            total_cost = q2(database.scalar(
                "SELECT COALESCE(total_cost, 0) FROM goods_issues WHERE id = ?",
                (issue_id,), default=0) or 0)

        net, vat, gross = totals_of(clean)
        database.execute(
            "UPDATE sales_docs SET total_net = ?, total_vat = ?, total_gross = ?, "
            "total_cost = ? WHERE id = ?",
            (float(net), float(vat), float(gross), float(q2(total_cost)), rec_id),
        )
    return int(rec_id)


def delete(rec_id: int) -> None:
    from . import links
    links.forget(links.FAKTURA, rec_id)
    rec = get(rec_id)
    if rec is None:
        return
    if rec["converted_no"]:
        raise ValidationError(
            f"Од овој документ е направена {rec['converted_no']}.\n\n"
            "Прво избриши ја таа, па потоа овој."
        )
    database = db()
    with database.tx():
        if rec["moves_stock"]:
            stock.revert_document(STOCK_TYPE, rec_id)
        database.delete("sales_docs", rec_id)


# ------------------------------------------------------------- претворања
def _copy_lines(source_rows) -> list[dict]:
    return [{"item_id": r["item_id"], "qty": r["qty"], "price": r["price"],
             "discount": r["discount"], "tax_rate": r["tax_rate"]} for r in source_rows]


def convert_to_invoice(proforma_id: int) -> int:
    """Профактура → фактура (стоката излегува при фактурирањето)."""
    rec = get(proforma_id)
    if rec is None or rec["kind"] != KIND_PROFORMA:
        raise ValidationError("Профактурата не постои.")
    if rec["converted_no"]:
        raise ValidationError(f"Веќе е фактурирана со {rec['converted_no']}.")
    header = dict(header_of(rec), source_id=proforma_id, issue_id=None,
                  date=_date.today().isoformat())
    return save_document(None, header, _copy_lines(lines(proforma_id)), KIND_INVOICE)


def invoice_from_issue(issue_id: int) -> int:
    """Испратница → фактура (стоката веќе излегла, само се наплаќа)."""
    issue = issues.get(issue_id)
    if issue is None:
        raise ValidationError("Испратницата не постои.")
    existing = db().one("SELECT doc_no FROM sales_docs WHERE issue_id = ?", (issue_id,))
    if existing:
        raise ValidationError(f"Испратницата е веќе фактурирана со {existing['doc_no']}.")
    header = {
        "date": _date.today().isoformat(), "due_date": "",
        "partner_id": issue["partner_id"], "warehouse_id": issue["warehouse_id"],
        "issue_id": issue_id, "source_id": None,
        "note": f"По испратница {issue['doc_no']}",
    }
    new_id = save_document(None, header, _copy_lines(issues.lines(issue_id)), KIND_INVOICE)
    from . import links
    links.link(links.ISPRATNICA, issue_id, links.FAKTURA, new_id)
    return new_id


def invoice_no_for_issue(issue_id: int) -> str:
    row = db().one("SELECT doc_no FROM sales_docs WHERE issue_id = ?", (issue_id,))
    return row["doc_no"] if row else ""


# ----------------------------------------------------- адаптер за формата
class SalesApi:
    """Го дава истиот интерфејс како другите документи, за зададен вид."""

    def __init__(self, kind: str):
        self.kind = kind

    def blank(self, when=None):
        return blank(self.kind, when)

    def get(self, rec_id):
        return get(rec_id)

    def lines(self, rec_id):
        return lines(rec_id)

    def header_of(self, record):
        return header_of(record)

    def save_document(self, rec_id, header, doc_lines):
        return save_document(rec_id, header, doc_lines, self.kind)

    line_amounts = staticmethod(line_amounts)
    clean_line = staticmethod(clean_line)
    totals_of = staticmethod(totals_of)
