﻿# -*- coding: utf-8 -*-
"""Испратници — излез на стока од магацин.

Огледало на приемницата: документот се снима како целина, а при снимањето
стоката излегува по **FIFO** — прво најстарата серија. Цената на чинење што
FIFO ја одзел се запишува во ставката (`cost`), па заработувачката по документ
е позната веднаш.

Измена на зачувана испратница прво ја враќа стоката во сериите од кои била
земена, па повторно ја издава по новите ставки.
"""

from __future__ import annotations

import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q, q2
from . import docnum, stock, warehouses
from .doclines import ValidationError, clean_line, line_amounts, totals_of  # noqa: F401

DOC_TYPE = "ispratnica"
STATUS_POSTED = "проведена"


# ------------------------------------------------------------------- листа
def list_all(search: str = "", year: int | None = None) -> list[sqlite3.Row]:
    sql = [
        "SELECT s.*, COALESCE(p.name, '') AS partner_name,",
        "       COALESCE(w.name, '') AS warehouse_name,",
        "       (SELECT COUNT(*) FROM goods_issue_items l WHERE l.issue_id = s.id) AS lines_count",
        "FROM goods_issues s",
        "LEFT JOIN partners p ON p.id = s.partner_id",
        "LEFT JOIN warehouses w ON w.id = s.warehouse_id",
        "WHERE 1 = 1",
    ]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(s.doc_no, '') || ' ' || COALESCE(p.name, '') || ' ' || COALESCE(s.note, ''), ?)")
        params.append(text)
    if year:
        sql.append("AND s.doc_year = ?")
        params.append(year)
    sql.append("ORDER BY s.doc_year DESC, s.doc_seq DESC")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT s.*, COALESCE(p.name, '') AS partner_name, "
        "       COALESCE(w.name, '') AS warehouse_name "
        "FROM goods_issues s "
        "LEFT JOIN partners p ON p.id = s.partner_id "
        "LEFT JOIN warehouses w ON w.id = s.warehouse_id WHERE s.id = ?",
        (rec_id,),
    )


def lines(rec_id: int) -> list[sqlite3.Row]:
    return db().query(
        "SELECT l.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit, "
        "       i.is_service AS item_is_service "
        "FROM goods_issue_items l JOIN items i ON i.id = l.item_id "
        "WHERE l.issue_id = ? ORDER BY l.line_no, l.id",
        (rec_id,),
    )


def header_of(record) -> dict:
    return {
        "id": record["id"], "doc_no": record["doc_no"], "date": record["date"],
        "partner_id": record["partner_id"], "warehouse_id": record["warehouse_id"],
        "note": record["note"],
        "use_full_name": bool(record["use_full_name"]),
    }


def blank(when: str | None = None) -> dict:
    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    return {
        "id": None,
        "doc_no": docnum.peek(DOC_TYPE, year)[1],
        "date": when,
        "partner_id": None,
        "warehouse_id": warehouses.default_id(),
        "note": "",
        "use_full_name": False,
    }


def totals(rec_id: int) -> tuple:
    row = db().one("SELECT total_net, total_vat, total_gross FROM goods_issues WHERE id = ?",
                   (rec_id,))
    if row is None:
        return D(0), D(0), D(0)
    return q2(row["total_net"]), q2(row["total_vat"]), q2(row["total_gross"])


def profit(rec_id: int) -> tuple:
    """(основица, цена на чинење, заработувачка, маржа %)."""
    row = db().one("SELECT total_net, total_cost FROM goods_issues WHERE id = ?", (rec_id,))
    if row is None:
        return D(0), D(0), D(0), D(0)
    net = q2(row["total_net"])
    cost = q2(row["total_cost"])
    gain = q2(net - cost)
    percent = q2(gain / cost * 100) if cost else D(0)
    return net, cost, gain, percent


# ------------------------------------------------------------------ снимање
def save_document(rec_id: int | None, header: dict, doc_lines: list[dict]) -> int:
    """Го снима документот и ја издава стоката по FIFO."""
    if not header.get("partner_id"):
        raise ValidationError("Избери купувач.")
    if not doc_lines:
        raise ValidationError("Испратницата нема ниту една ставка.")
    clean = [clean_line(line) for line in doc_lines]

    when = str(header.get("date") or _date.today().isoformat())
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    warehouse_id = int(header.get("warehouse_id") or warehouses.default_id())

    database = db()
    with database.tx():
        if rec_id:
            existing = database.one("SELECT * FROM goods_issues WHERE id = ?", (rec_id,))
            if existing is None:
                raise ValidationError("Испратницата не постои.")
            # Стоката се враќа во сериите од кои била земена, па се издава одново.
            stock.revert_document(DOC_TYPE, rec_id)
            database.execute("DELETE FROM goods_issue_items WHERE issue_id = ?", (rec_id,))
            doc_no = existing["doc_no"]
            database.execute(
                "UPDATE goods_issues SET date = ?, partner_id = ?, warehouse_id = ?, "
                "note = ?, status = ?, posted_at = datetime('now','localtime'), "
                "updated_at = datetime('now','localtime'), use_full_name = ? WHERE id = ?",
                (when, int(header["partner_id"]), warehouse_id,
                 str(header.get("note") or "").strip(), STATUS_POSTED,
                 1 if header.get("use_full_name") else 0, rec_id),
            )
        else:
            seq, doc_no, doc_year = docnum.take(DOC_TYPE, year)
            rec_id = database.insert("goods_issues", {
                "doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq,
                "date": when, "partner_id": int(header["partner_id"]),
                "warehouse_id": warehouse_id,
                "note": str(header.get("note") or "").strip(),
                "use_full_name": 1 if header.get("use_full_name") else 0,
                "status": STATUS_POSTED, "posted_at": "",
            })
            database.execute(
                "UPDATE goods_issues SET posted_at = datetime('now','localtime') WHERE id = ?",
                (rec_id,))

        total_cost = D(0)
        for index, line in enumerate(clean, start=1):
            taken = stock.issue(
                item_id=line["item_id"], warehouse_id=warehouse_id, date=when,
                doc_type=DOC_TYPE, doc_id=rec_id, doc_no=doc_no, qty=line["qty"],
            )
            cost = q2(sum((t["qty"] * t["unit_cost"] for t in taken), D(0)))
            total_cost += cost
            database.insert("goods_issue_items",
                            dict(line, issue_id=rec_id, line_no=index, cost=float(cost)))

        net, vat, gross = totals_of(clean)
        database.execute(
            "UPDATE goods_issues SET total_net = ?, total_vat = ?, total_gross = ?, "
            "total_cost = ? WHERE id = ?",
            (float(net), float(vat), float(gross), float(q2(total_cost)), rec_id),
        )
    return int(rec_id)


def delete(rec_id: int) -> None:
    from . import links
    links.forget(links.ISPRATNICA, rec_id)
    rec = get(rec_id)
    if rec is None:
        return
    database = db()
    with database.tx():
        stock.revert_document(DOC_TYPE, rec_id)     # стоката се враќа во магацин
        database.delete("goods_issues", rec_id)
