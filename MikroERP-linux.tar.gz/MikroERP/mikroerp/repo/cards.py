# -*- coding: utf-8 -*-
"""Картички — класична картица на клиент и картица на артикл.

**Картица на клиент** ги собира сите документи и уплати на едно место:
  * излезна фактура → задолжување (нè должи);
  * прилив од него   → побарување (плати);
  * влезна фактура и трошок → побарување (ние должиме);
  * одлив кон него   → задолжување (платено).
Салдото е задолжување − побарување: позитивно значи дека клиентот нè должи.

**Картица на артикл** е движењето на залихата — влез, излез и состојба по
секој документ.
"""

from __future__ import annotations

from ..db import db
from ..money import D, q, q2
from . import payments


def partner_card(partner_id: int, date_from: str = "", date_to: str = "") -> list[dict]:
    """Сите ставки на клиентот, хронолошки."""
    database = db()
    rows: list[dict] = []

    def within(when: str) -> bool:
        return (not date_from or when >= date_from) and (not date_to or when <= date_to)

    for row in database.query(
        "SELECT id, doc_no, date, total_gross FROM sales_docs "
        "WHERE kind = 'faktura' AND partner_id = ? ORDER BY date, id", (partner_id,)
    ):
        if within(row["date"]):
            rows.append({"date": row["date"], "kind": payments.KIND_SALES,
                         "id": int(row["id"]), "doc_no": row["doc_no"],
                         "what": "Излезна фактура", "debit": q2(row["total_gross"]),
                         "credit": D(0), "group": (payments.KIND_SALES, int(row["id"]))})

    for row in database.query(
        "SELECT id, doc_no, date, total_gross FROM purchase_invoices "
        "WHERE partner_id = ? ORDER BY date, id", (partner_id,)
    ):
        if within(row["date"]):
            rows.append({"date": row["date"], "kind": payments.KIND_PURCHASE,
                         "id": int(row["id"]), "doc_no": row["doc_no"],
                         "what": "Влезна фактура", "debit": D(0),
                         "credit": q2(row["total_gross"]),
                         "group": (payments.KIND_PURCHASE, int(row["id"]))})

    for row in database.query(
        "SELECT id, doc_no, date, amount FROM expenses WHERE partner_id = ? "
        "ORDER BY date, id", (partner_id,)
    ):
        if within(row["date"]):
            rows.append({"date": row["date"], "kind": payments.KIND_EXPENSE,
                         "id": int(row["id"]), "doc_no": row["doc_no"],
                         "what": "Трошок", "debit": D(0), "credit": q2(row["amount"]),
                         "group": (payments.KIND_EXPENSE, int(row["id"]))})

    # уплати преку извод
    for row in database.query(
        "SELECT pm.*, l.direction, l.cp_name, s.doc_no AS statement_no, "
        "       s.date AS statement_date "
        "FROM payments pm "
        "JOIN bank_statement_lines l ON l.id = pm.line_id "
        "JOIN bank_statements s ON s.id = l.statement_id "
        "WHERE l.partner_id = ? ORDER BY pm.date, pm.id", (partner_id,)
    ):
        when = row["date"] or row["statement_date"]
        if not within(when):
            continue
        inflow = row["direction"] == "прилив"
        rows.append({
            "date": when, "kind": "uplata", "id": int(row["id"]),
            "doc_no": "извод " + str(row["statement_no"]),
            "what": "Уплата" if inflow else "Исплата",
            "debit": D(0) if inflow else q2(row["amount"]),
            "credit": q2(row["amount"]) if inflow else D(0),
            "group": (str(row["target_kind"]), int(row["target_id"])),
        })

    rows.sort(key=lambda r: (r["date"], r["kind"] == "uplata", r["id"]))
    return rows


def group_by_document(rows: list[dict]) -> list[dict]:
    """Подредување „по уплата“: документот и неговите уплати одат заедно.

    Редоследот на групите го одредува најраната ставка во групата — ако
    уплатата дошла прва, таа е горе, а фактурата под неа.
    """
    groups: dict = {}
    order: list = []
    for row in rows:
        key = row.get("group") or ("", row["id"])
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(row)

    order.sort(key=lambda k: min(r["date"] for r in groups[k]))
    out: list[dict] = []
    for key in order:
        items = sorted(groups[key], key=lambda r: (r["date"], r["kind"] == "uplata"))
        for index, row in enumerate(items):
            row = dict(row)
            row["indent"] = index > 0
            out.append(row)
    return out


def with_balance(rows: list[dict]) -> tuple:
    """Додава колона салдо и враќа (редови, вкупно задолжување, побарување, салдо)."""
    balance = D(0)
    debit_total = D(0)
    credit_total = D(0)
    out = []
    for row in rows:
        balance += D(row["debit"]) - D(row["credit"])
        debit_total += D(row["debit"])
        credit_total += D(row["credit"])
        out.append(dict(row, balance=q2(balance)))
    return out, q2(debit_total), q2(credit_total), q2(balance)


def item_card(item_id: int, warehouse_id: int | None = None,
              date_from: str = "", date_to: str = "") -> list[dict]:
    """Движење на залихата по артикл."""
    sql = ["SELECT * FROM stock_moves WHERE item_id = ?"]
    params: list = [item_id]
    if warehouse_id:
        sql.append("AND warehouse_id = ?")
        params.append(warehouse_id)
    if date_from:
        sql.append("AND date >= ?")
        params.append(date_from)
    if date_to:
        sql.append("AND date <= ?")
        params.append(date_to)
    sql.append("ORDER BY date, id")

    balance = D(0)
    value = D(0)
    rows = []
    for row in db().query(" ".join(sql), params):
        qty = D(row["qty"])
        balance += qty
        value += D(row["value"])
        rows.append({
            "date": row["date"], "doc_no": row["doc_no"], "doc_type": row["doc_type"],
            "in_qty": q(qty, 3) if qty > 0 else D(0),
            "out_qty": q(-qty, 3) if qty < 0 else D(0),
            "unit_cost": q2(row["unit_cost"]), "value": q2(row["value"]),
            "balance": q(balance, 3), "stock_value": q2(value),
        })
    return rows
