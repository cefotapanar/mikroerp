# -*- coding: utf-8 -*-
"""Клиенти (купувачи и добавувачи во иста табела)."""

from __future__ import annotations

import sqlite3

from ..db import db

TABLE = "partners"

TEXT_FIELDS = (
    "code", "name", "full_name", "tax_number", "reg_number", "address", "city",
    "country", "phone", "email", "contact_person", "bank_account", "bank_name",
    "note",
)
BOOL_FIELDS = ("is_customer", "is_supplier", "active")

KIND_COMPANY = "правно"
KIND_PERSON = "физичко"
KINDS = [KIND_COMPANY, KIND_PERSON]


class ValidationError(ValueError):
    pass


def kind_of(row) -> str:
    try:
        return str(row["kind"] or KIND_COMPANY)
    except (KeyError, IndexError, TypeError):
        return KIND_COMPANY


def is_person(row) -> bool:
    return kind_of(row) == KIND_PERSON


def display_name(row, full: bool = False) -> str:
    """Кратниот назив е главен; полниот се користи кога документот го бара."""
    if full:
        try:
            return str(row["full_name"] or row["name"])
        except (KeyError, IndexError, TypeError):
            pass
    return str(row["name"])


def list_all(search: str = "", role: str = "site", only_active: bool = False) -> list[sqlite3.Row]:
    """role: 'site' | 'kupuvaci' | 'dobavuvaci'"""
    sql = ["SELECT * FROM partners WHERE 1 = 1"]
    params: list = []
    text = search.strip()
    if text:
        sql.append(
            "AND mkmatch(COALESCE(name, '') || ' ' || COALESCE(full_name, '') || ' ' || COALESCE(code, '') || ' ' || COALESCE(tax_number, '') || ' ' || COALESCE(reg_number, '') || ' ' || COALESCE(city, '') || ' ' || COALESCE(phone, '') || ' ' || COALESCE(email, ''), ?)"
        )
        params.append(text)
    if role == "kupuvaci":
        sql.append("AND is_customer = 1")
    elif role == "dobavuvaci":
        sql.append("AND is_supplier = 1")
    if only_active:
        sql.append("AND active = 1")
    sql.append("ORDER BY name COLLATE NOCASE")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one("SELECT * FROM partners WHERE id = ?", (rec_id,))


def options(role: str = "site", only_active: bool = True) -> list[tuple[int, str]]:
    return [(int(r["id"]), r["name"]) for r in list_all(role=role, only_active=only_active)]


def _clean(data: dict) -> dict:
    payload: dict = {}
    for field in TEXT_FIELDS:
        payload[field] = str(data.get(field) or "").strip()
    for field in BOOL_FIELDS:
        payload[field] = 1 if data.get(field, field == "active") else 0
    kind = str(data.get("kind") or KIND_COMPANY)
    payload["kind"] = kind if kind in KINDS else KIND_COMPANY
    if payload["kind"] == KIND_PERSON:
        # физичко лице нема даночни броеви ни полн назив
        payload["tax_number"] = ""
        payload["reg_number"] = ""
        payload["full_name"] = ""
    return payload


def _validate(payload: dict, rec_id: int | None = None) -> None:
    if not payload["name"]:
        raise ValidationError("Внеси назив на клиентот.")
    if not payload["is_customer"] and not payload["is_supplier"]:
        raise ValidationError("Означи дали клиентот е купувач, добавувач или двете.")
    if payload["code"]:
        exists = db().one(
            "SELECT id FROM partners WHERE code = ? COLLATE NOCASE AND id IS NOT ?",
            (payload["code"], rec_id),
        )
        if exists:
            raise ValidationError(f"Шифрата „{payload['code']}“ е веќе зафатена.")
    edb = payload["tax_number"]
    if edb and (not edb.isdigit() or len(edb) not in (13, 15)):
        raise ValidationError("ЕДБ треба да е 13 или 15 цифри (или остави празно).")


def create(data: dict, contacts: list[dict] | None = None) -> int:
    payload = _clean(data)
    _validate(payload)
    database = db()
    with database.tx():
        rec_id = database.insert(TABLE, payload)
        _save_contacts(rec_id, contacts, payload["kind"])
    return rec_id


def update(rec_id: int, data: dict, contacts: list[dict] | None = None) -> None:
    payload = _clean(data)
    _validate(payload, rec_id)
    database = db()
    with database.tx():
        database.update(TABLE, rec_id, payload)
        database.execute(
            "UPDATE partners SET updated_at = datetime('now','localtime') WHERE id = ?", (rec_id,)
        )
        _save_contacts(rec_id, contacts, payload["kind"])


# ------------------------------------------------------------------ контакти
def contacts(partner_id: int) -> list:
    return db().query(
        "SELECT * FROM partner_contacts WHERE partner_id = ? ORDER BY line_no, id",
        (partner_id,))


def _save_contacts(partner_id: int, rows: list[dict] | None, kind: str) -> None:
    """`None` значи „не ги допирај“; листа ги заменува сите."""
    if rows is None:
        return
    database = db()
    database.execute("DELETE FROM partner_contacts WHERE partner_id = ?", (partner_id,))
    if kind == KIND_PERSON:
        return                      # физичко лице нема посебни контакти
    for index, row in enumerate(rows, start=1):
        name = str(row.get("name") or "").strip()
        phone = str(row.get("phone") or "").strip()
        email = str(row.get("email") or "").strip()
        note = str(row.get("note") or "").strip()
        if not any((name, phone, email, note)):
            continue
        database.insert("partner_contacts", {
            "partner_id": partner_id, "line_no": index,
            "name": name, "phone": phone, "email": email, "note": note,
        })


def delete(rec_id: int) -> None:
    database = db()
    with database.tx():
        database.delete(TABLE, rec_id)


def next_code() -> str:
    """Предлага следна слободна шифра (0001, 0002, ...)."""
    rows = db().query("SELECT code FROM partners WHERE code GLOB '[0-9]*'")
    numbers = []
    for row in rows:
        try:
            numbers.append(int(row["code"]))
        except (TypeError, ValueError):
            continue
    return f"{(max(numbers) + 1) if numbers else 1:04d}"
