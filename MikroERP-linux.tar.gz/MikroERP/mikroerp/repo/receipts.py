﻿# -*- coding: utf-8 -*-
"""Приемници — влез на стока во магацин.

Документот се уредува во меморија и се снима **како целина**: едно копче
„Зачувај“ го запишува заглавието, ставките и влезот во магацинот (FIFO серии)
во една трансакција.  „Откажи“ не остава траг.

Измена на веќе зачувана приемница = поништување на нејзиниот влез и повторно
запишување.  Ако од таа стока веќе е издадено нешто, измената се одбива —
инаку цената на чинење на издадената стока би останала без покритие.
"""

from __future__ import annotations

import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q, q2
from . import docnum, items, stock, warehouses
from .doclines import ValidationError, clean_line, line_amounts, totals_of  # noqa: F401

DOC_TYPE = "priemnica"
STATUS_POSTED = "проведена"


# ------------------------------------------------------------------- листа
def list_all(search: str = "", year: int | None = None) -> list[sqlite3.Row]:
    sql = [
        "SELECT r.*, COALESCE(p.name, '') AS partner_name,",
        "       COALESCE(w.name, '') AS warehouse_name,",
        "       (SELECT COUNT(*) FROM goods_receipt_items l WHERE l.receipt_id = r.id) AS lines_count",
        "FROM goods_receipts r",
        "LEFT JOIN partners p ON p.id = r.partner_id",
        "LEFT JOIN warehouses w ON w.id = r.warehouse_id",
        "WHERE 1 = 1",
    ]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(r.doc_no, '') || ' ' || COALESCE(r.supplier_doc, '') || ' ' || COALESCE(p.name, '') || ' ' || COALESCE(r.note, ''), ?)")
        params.append(text)
    if year:
        sql.append("AND r.doc_year = ?")
        params.append(year)
    sql.append("ORDER BY r.doc_year DESC, r.doc_seq DESC")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT r.*, COALESCE(p.name, '') AS partner_name, "
        "       COALESCE(w.name, '') AS warehouse_name "
        "FROM goods_receipts r "
        "LEFT JOIN partners p ON p.id = r.partner_id "
        "LEFT JOIN warehouses w ON w.id = r.warehouse_id WHERE r.id = ?",
        (rec_id,),
    )


def lines(rec_id: int) -> list[sqlite3.Row]:
    return db().query(
        "SELECT l.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit, "
        "       i.is_service AS item_is_service "
        "FROM goods_receipt_items l JOIN items i ON i.id = l.item_id "
        "WHERE l.receipt_id = ? ORDER BY l.line_no, l.id",
        (rec_id,),
    )


def header_of(record) -> dict:
    """Заглавието во облик со кој работи формата."""
    return {
        "id": record["id"], "doc_no": record["doc_no"], "date": record["date"],
        "partner_id": record["partner_id"], "warehouse_id": record["warehouse_id"],
        "supplier_doc": record["supplier_doc"], "supplier_date": record["supplier_date"],
        "update_prices": bool(record["update_prices"]), "note": record["note"],
        "use_full_name": bool(record["use_full_name"]),
    }


def blank(when: str | None = None) -> dict:
    """Празен документ за нов внес — сè уште ништо не е запишано во базата."""
    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    return {
        "id": None,
        "doc_no": docnum.peek(DOC_TYPE, year)[1],
        "date": when,
        "partner_id": None,
        "warehouse_id": warehouses.default_id(),
        "supplier_doc": "",
        "supplier_date": "",
        "update_prices": True,
        "note": "",
        "use_full_name": False,
    }


def totals(rec_id: int) -> tuple:
    row = db().one("SELECT total_net, total_vat, total_gross FROM goods_receipts WHERE id = ?",
                   (rec_id,))
    if row is None:
        return D(0), D(0), D(0)
    return q2(row["total_net"]), q2(row["total_vat"]), q2(row["total_gross"])


# ------------------------------------------------------------------ снимање
def save_document(rec_id: int | None, header: dict, doc_lines: list[dict]) -> int:
    """Го снима целиот документ и ја внесува стоката во магацин."""
    if not header.get("partner_id"):
        raise ValidationError("Избери добавувач.")
    if not doc_lines:
        raise ValidationError("Приемницата нема ниту една ставка.")
    clean = [clean_line(line) for line in doc_lines]

    when = str(header.get("date") or _date.today().isoformat())
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    warehouse_id = int(header.get("warehouse_id") or warehouses.default_id())
    update_prices = bool(header.get("update_prices", True))

    database = db()
    with database.tx():
        if rec_id:
            existing = database.one("SELECT * FROM goods_receipts WHERE id = ?", (rec_id,))
            if existing is None:
                raise ValidationError("Приемницата не постои.")
            stock.revert_document(DOC_TYPE, rec_id)     # ќе фрли ако е потрошена стоката
            database.execute("DELETE FROM goods_receipt_items WHERE receipt_id = ?", (rec_id,))
            doc_no = existing["doc_no"]
            database.execute(
                "UPDATE goods_receipts SET date = ?, partner_id = ?, warehouse_id = ?, "
                "supplier_doc = ?, supplier_date = ?, update_prices = ?, note = ?, "
                "status = ?, posted_at = datetime('now','localtime'), "
                "updated_at = datetime('now','localtime'), use_full_name = ? WHERE id = ?",
                (when, int(header["partner_id"]), warehouse_id,
                 str(header.get("supplier_doc") or "").strip(),
                 str(header.get("supplier_date") or "").strip(),
                 1 if update_prices else 0,
                 str(header.get("note") or "").strip(),
                 STATUS_POSTED, 1 if header.get("use_full_name") else 0, rec_id),
            )
        else:
            seq, doc_no, doc_year = docnum.take(DOC_TYPE, year)
            rec_id = database.insert("goods_receipts", {
                "doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq,
                "date": when, "partner_id": int(header["partner_id"]),
                "warehouse_id": warehouse_id,
                "supplier_doc": str(header.get("supplier_doc") or "").strip(),
                "supplier_date": str(header.get("supplier_date") or "").strip(),
                "update_prices": 1 if update_prices else 0,
                "note": str(header.get("note") or "").strip(),
                "use_full_name": 1 if header.get("use_full_name") else 0,
                "status": STATUS_POSTED,
                "posted_at": "",
            })
            database.execute(
                "UPDATE goods_receipts SET posted_at = datetime('now','localtime') WHERE id = ?",
                (rec_id,))

        for index, line in enumerate(clean, start=1):
            payload = dict(line, receipt_id=rec_id, line_no=index)
            database.insert("goods_receipt_items", payload)

            qty = D(line["qty"])
            # Цената на чинење е нето вредноста поделена со количината —
            # рабатот е веќе вкалкулиран.
            unit_cost = q(D(line["net"]) / qty, 4) if qty else D(0)
            stock.receive(
                item_id=line["item_id"], warehouse_id=warehouse_id, date=when,
                doc_type=DOC_TYPE, doc_id=rec_id, doc_no=doc_no,
                qty=qty, unit_cost=unit_cost,
            )
            if update_prices:
                items.set_purchase_price(line["item_id"], unit_cost)

        net, vat, gross = totals_of(clean)
        database.execute(
            "UPDATE goods_receipts SET total_net = ?, total_vat = ?, total_gross = ? "
            "WHERE id = ?", (float(net), float(vat), float(gross), rec_id),
        )
    return int(rec_id)


def delete(rec_id: int) -> None:
    from . import links
    links.forget(links.PRIEMNICA, rec_id)
    rec = get(rec_id)
    if rec is None:
        return
    database = db()
    with database.tx():
        stock.revert_document(DOC_TYPE, rec_id)     # ќе фрли ако е потрошена стоката
        database.delete("goods_receipts", rec_id)   # ставките одат со ON DELETE CASCADE
