# -*- coding: utf-8 -*-
"""Врски меѓу документите.

Испратницата се фактурира со **излезна фактура**, приемницата со **влезна**.
Врската е табела, не поле, зашто во пракса неколку испратници одат на една
фактура (месечна фактура за повеќе испораки), а и една испратница може да се
подели на повеќе фактури.

Тука се и текстовите што ги гледаат листите: „нема фактура“, „нема испратници“.
"""

from __future__ import annotations

from ..db import db
from ..util import fmt_date
from . import issues, purchases, receipts, sales

ISPRATNICA = "ispratnica"
PRIEMNICA = "priemnica"
FAKTURA = "faktura"
VLEZNA = "vlezna_faktura"

SOURCES = {
    ISPRATNICA: (issues, "Испратница", "испратници"),
    PRIEMNICA: (receipts, "Приемница", "приемници"),
}
TARGETS = {
    FAKTURA: (sales, "Фактура", "фактура"),
    VLEZNA: (purchases, "Влезна фактура", "влезна фактура"),
}
PAIR = {ISPRATNICA: FAKTURA, PRIEMNICA: VLEZNA}
BACK = {FAKTURA: ISPRATNICA, VLEZNA: PRIEMNICA}

EMPTY_TARGET = {FAKTURA: "нема фактура", VLEZNA: "нема фактура"}
EMPTY_SOURCE = {ISPRATNICA: "нема испратници", PRIEMNICA: "нема приемници"}


def _repo(kind: str):
    if kind in SOURCES:
        return SOURCES[kind][0]
    return TARGETS[kind][0]


def link(source_kind: str, source_id: int, target_kind: str, target_id: int) -> None:
    db().execute(
        "INSERT OR IGNORE INTO doc_links "
        "(source_kind, source_id, target_kind, target_id) VALUES (?, ?, ?, ?)",
        (source_kind, int(source_id), target_kind, int(target_id)),
    )


def unlink(source_kind: str, source_id: int, target_kind: str, target_id: int) -> None:
    db().execute(
        "DELETE FROM doc_links WHERE source_kind = ? AND source_id = ? "
        "AND target_kind = ? AND target_id = ?",
        (source_kind, int(source_id), target_kind, int(target_id)),
    )


def forget(kind: str, rec_id: int) -> None:
    """Документот се брише — врските со него исто."""
    database = db()
    database.execute("DELETE FROM doc_links WHERE source_kind = ? AND source_id = ?",
                     (kind, int(rec_id)))
    database.execute("DELETE FROM doc_links WHERE target_kind = ? AND target_id = ?",
                     (kind, int(rec_id)))


def _describe(kind: str, rec_id: int) -> dict | None:
    record = _repo(kind).get(int(rec_id))
    if record is None:
        return None
    return {"kind": kind, "id": int(rec_id), "doc_no": record["doc_no"],
            "date": record["date"],
            "total": record["total_gross"] if "total_gross" in record.keys() else 0}


def targets_of(source_kind: str, source_id: int) -> list[dict]:
    """Фактурите што ја покриваат оваа испратница/приемница."""
    rows = db().query(
        "SELECT target_kind, target_id FROM doc_links "
        "WHERE source_kind = ? AND source_id = ? ORDER BY id",
        (source_kind, int(source_id)))
    found = [_describe(r["target_kind"], r["target_id"]) for r in rows]
    return [x for x in found if x]


def sources_of(target_kind: str, target_id: int) -> list[dict]:
    """Испратниците/приемниците што ги покрива оваа фактура."""
    rows = db().query(
        "SELECT source_kind, source_id FROM doc_links "
        "WHERE target_kind = ? AND target_id = ? ORDER BY id",
        (target_kind, int(target_id)))
    found = [_describe(r["source_kind"], r["source_id"]) for r in rows]
    return [x for x in found if x]


def numbers(items: list[dict]) -> str:
    return ", ".join(item["doc_no"] for item in items)


def target_label(source_kind: str, source_id: int) -> str:
    """Што пишува во колоната „Фактура“ на испратниците/приемниците."""
    items = targets_of(source_kind, source_id)
    return numbers(items) if items else EMPTY_TARGET[PAIR[source_kind]]


def source_label(target_kind: str, target_id: int) -> str:
    """Што пишува во колоната „Испратници/Приемници“ на фактурите."""
    items = sources_of(target_kind, target_id)
    return numbers(items) if items else EMPTY_SOURCE[BACK[target_kind]]


def has_target(source_kind: str, source_id: int) -> bool:
    return bool(targets_of(source_kind, source_id))


def open_targets(target_kind: str, partner_id: int | None,
                 exclude: list[int] | None = None) -> list[dict]:
    """Фактурите на тој клиент, за рачно поврзување."""
    exclude = set(exclude or [])
    rows = []
    if target_kind == FAKTURA:
        records = sales.list_all(sales.KIND_INVOICE)
    else:
        records = purchases.list_all()
    for record in records:
        if partner_id and record["partner_id"] and \
                int(record["partner_id"]) != int(partner_id):
            continue
        if int(record["id"]) in exclude:
            continue
        rows.append({
            "kind": target_kind, "id": int(record["id"]),
            "doc_no": record["doc_no"], "date": record["date"],
            "date_text": fmt_date(record["date"]),
            "partner_name": record["partner_name"] or "—",
            "total": record["total_gross"],
        })
    return rows
