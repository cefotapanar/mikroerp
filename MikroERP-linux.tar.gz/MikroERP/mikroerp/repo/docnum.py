# -*- coding: utf-8 -*-
"""Нумерирање на документите.

Формат: ПРЕФИКС-НННН-ГГ   (пример: PR-0001-26, VF-0007-26)
Броењето почнува одново секоја година, посебно за секој тип документ.
"""

from __future__ import annotations

from datetime import date

from ..db import db

# клуч → (префикс, назив)
DOC_TYPES: dict[str, tuple[str, str]] = {
    "priemnica": ("PR", "Приемница"),
    "ispratnica": ("IS", "Испратница"),
    "vlezna_faktura": ("VF", "Влезна фактура"),
    "izlezna_faktura": ("IF", "Излезна фактура"),
    "profaktura": ("PF", "Профактура"),
    "raboten_nalog": ("RN", "Работен налог"),
    "trosok": ("ТР", "Трошок"),
}


def prefix(doc_type: str) -> str:
    return DOC_TYPES.get(doc_type, (doc_type.upper()[:2], doc_type))[0]


def label(doc_type: str) -> str:
    return DOC_TYPES.get(doc_type, ("", doc_type))[1]


def format_no(doc_type: str, seq: int, year: int) -> str:
    return f"{prefix(doc_type)}-{seq:04d}-{year % 100:02d}"


def peek(doc_type: str, year: int | None = None) -> tuple[int, str]:
    """Кој број би бил следен, БЕЗ да се потроши."""
    year = year or date.today().year
    last = db().scalar(
        "SELECT last_no FROM doc_counters WHERE doc_type = ? AND year = ?",
        (doc_type, year), default=0,
    ) or 0
    seq = int(last) + 1
    return seq, format_no(doc_type, seq, year)


def take(doc_type: str, year: int | None = None) -> tuple[int, str, int]:
    """Го зема следниот број и го троши. Враќа (реден број, ознака, година).

    Мора да се повика ВО трансакција заедно со создавањето на документот,
    за да не остане потрошен број ако создавањето падне.
    """
    year = year or date.today().year
    row = db().one(
        "INSERT INTO doc_counters (doc_type, year, last_no) VALUES (?, ?, 1) "
        "ON CONFLICT (doc_type, year) DO UPDATE SET last_no = last_no + 1 "
        "RETURNING last_no",
        (doc_type, year),
    )
    seq = int(row["last_no"])
    return seq, format_no(doc_type, seq, year), year
