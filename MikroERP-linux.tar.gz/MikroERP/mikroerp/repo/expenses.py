# -*- coding: utf-8 -*-
"""Трошоци.

Трошокот може да се внесе рачно или да се создаде од ставка во извод
(банкарски провизии и слични одливи што немаат фактура).

Категоријата служи за извештаи. Ако не се избере ДДВ стапка, ДДВ-то е 0 —
износот е цел трошок.
"""

from __future__ import annotations

import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q2, without_vat
from . import docnum

DOC_TYPE = "trosok"

SOURCE_MANUAL = "рачно"
SOURCE_BANK = "извод"

# Предлог-сметки (категории) за извештаи
CATEGORIES = [
    "Материјални трошоци",
    "Ситен инвентар",
    "Оперативни трошоци",
    "Банкарски трошоци",
    "Плата и придонеси",
    "Данок",
    "Останато",
]
DEFAULT_BANK_CATEGORY = "Оперативни трошоци"

VAT_RATES = ["0", "5", "10", "18"]


# ------------------------------------------------------- потпис од каде дошол
# Трошокот создаден од ставка во извод носи потпис што го врзува за таа
# конкретна ставка. Со него истиот извод НЕ МОЖЕ да создаде ист трошок двапати
# — ако изводот е избришан па повторно увезен, трошокот се препознава.
def origin_prefix(account, year, doc_no) -> str:
    return f"{SOURCE_BANK}:{str(account or '')}|{int(year or 0)}|{str(doc_no or '')}|"


def origin_key(account, year, doc_no, line_no) -> str:
    return origin_prefix(account, year, doc_no) + str(int(line_no or 0))


def find_by_origin(key: str) -> sqlite3.Row | None:
    if not str(key or "").strip():
        return None
    return db().one("SELECT * FROM expenses WHERE origin_key = ? ORDER BY id LIMIT 1",
                    (str(key),))


def find_orphan(when: str, amount) -> sqlite3.Row | None:
    """Стар трошок од извод што останал без свој извод (без потпис).

    Служи за податоците внесени пред потписот да постои: ако изводот бил
    избришан, трошокот останал сам. При повторен увоз тој се **усвојува**
    наместо да се создаде втор, ист трошок.
    """
    return db().one(
        "SELECT * FROM expenses WHERE source = ? AND origin_key = '' "
        "  AND date = ? AND ROUND(amount, 2) = ROUND(?, 2) "
        "  AND id NOT IN (SELECT expense_id FROM bank_statement_lines "
        "                 WHERE expense_id IS NOT NULL) "
        "ORDER BY id LIMIT 1",
        (SOURCE_BANK, str(when or ""), float(q2(amount or 0))),
    )


def by_origin_prefix(prefix: str) -> list[sqlite3.Row]:
    if not str(prefix or "").strip():
        return []
    return db().query("SELECT * FROM expenses WHERE origin_key LIKE ? ORDER BY id",
                      (str(prefix) + "%",))


def delete_by_origin(prefix: str, keep: list[int] | tuple = ()) -> int:
    """Ги брише трошоците на еден извод, освен оние што сè уште се потребни.

    Со ова изводот не остава зад себе трошоци што ги нема во ниту една негова
    ставка (ставката е избришана или е одштиклирана како трошок).
    """
    kept = {int(x) for x in keep or ()}
    removed = 0
    for row in by_origin_prefix(prefix):
        if int(row["id"]) in kept:
            continue
        delete(int(row["id"]))
        removed += 1
    return removed


class ValidationError(ValueError):
    pass


# ------------------------------------------------------------------- листа
def list_all(search: str = "", category: str = "", year: int | None = None,
             source: str = "", orphans_only: bool = False) -> list[sqlite3.Row]:
    sql = [
        "SELECT e.*, COALESCE(p.name, '') AS partner_name,",
        "       (SELECT COUNT(*) FROM bank_statement_lines l "
        "        WHERE l.expense_id = e.id) AS linked",
        "FROM expenses e LEFT JOIN partners p ON p.id = e.partner_id",
        "WHERE 1 = 1",
    ]
    params: list = []
    if orphans_only:
        # Трошок од извод што повеќе го нема во ниту еден извод.
        sql.append("AND e.source = ? AND NOT EXISTS "
                   "(SELECT 1 FROM bank_statement_lines l WHERE l.expense_id = e.id)")
        params.append(SOURCE_BANK)
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(e.doc_no, '') || ' ' || COALESCE(e.description, '') || ' ' || COALESCE(e.category, '') || ' ' || COALESCE(p.name, '') || ' ' || COALESCE(e.note, ''), ?)")
        params.append(text)
    if category:
        sql.append("AND e.category = ?")
        params.append(category)
    if source:
        sql.append("AND e.source = ?")
        params.append(source)
    if year:
        sql.append("AND e.doc_year = ?")
        params.append(year)
    sql.append("ORDER BY e.date DESC, e.id DESC")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT e.*, COALESCE(p.name, '') AS partner_name "
        "FROM expenses e LEFT JOIN partners p ON p.id = e.partner_id WHERE e.id = ?",
        (rec_id,),
    )


def categories() -> list[str]:
    """Предлозите + сè што веќе е внесено."""
    used = [r["category"] for r in db().query(
        "SELECT DISTINCT category FROM expenses WHERE category <> '' ORDER BY category")]
    out = list(CATEGORIES)
    for name in used:
        if name not in out:
            out.append(name)
    return out


def totals_by_category(year: int | None = None) -> list[sqlite3.Row]:
    sql = ["SELECT category, COUNT(*) AS broj, SUM(amount) AS vkupno,",
           "       SUM(net) AS neto, SUM(vat_amount) AS ddv",
           "FROM expenses WHERE 1 = 1"]
    params: list = []
    if year:
        sql.append("AND doc_year = ?")
        params.append(year)
    sql.append("GROUP BY category ORDER BY vkupno DESC")
    return db().query(" ".join(sql), params)


# ------------------------------------------------------------------ снимање
def _amounts(amount, vat_rate) -> tuple:
    gross = q2(amount or 0)
    rate = q2(vat_rate or 0)
    net = without_vat(gross, rate) if rate else gross
    return gross, rate, q2(gross - net), net


def save_document(rec_id: int | None, data: dict) -> int:
    gross, rate, vat, net = _amounts(data.get("amount"), data.get("vat_rate"))
    if gross <= 0:
        raise ValidationError("Внеси износ на трошокот.")
    if not str(data.get("category") or "").strip():
        raise ValidationError("Избери категорија на трошокот.")

    when = str(data.get("date") or _date.today().isoformat())
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year

    payload = {
        "date": when,
        "partner_id": int(data["partner_id"]) if data.get("partner_id") else None,
        "category": str(data["category"]).strip(),
        "description": str(data.get("description") or "").strip(),
        "amount": float(gross), "vat_rate": float(rate),
        "vat_amount": float(vat), "net": float(net),
        "source": str(data.get("source") or SOURCE_MANUAL),
        "note": str(data.get("note") or "").strip(),
    }
    # Потписот се запишува само кога е даден — измена на трошок не го брише.
    if str(data.get("origin_key") or "").strip():
        payload["origin_key"] = str(data["origin_key"]).strip()

    database = db()
    with database.tx():
        if rec_id:
            database.update("expenses", rec_id, payload)
            database.execute("UPDATE expenses SET updated_at = "
                             "datetime('now','localtime') WHERE id = ?", (rec_id,))
        else:
            seq, doc_no, doc_year = docnum.take(DOC_TYPE, year)
            payload.update({"doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq})
            rec_id = database.insert("expenses", payload)
    return int(rec_id)


def delete(rec_id: int) -> None:
    database = db()
    with database.tx():
        database.execute("UPDATE bank_statement_lines SET expense_id = NULL "
                         "WHERE expense_id = ?", (rec_id,))
        database.execute("DELETE FROM payments WHERE target_kind = ? AND target_id = ?",
                         (DOC_TYPE, rec_id))
        database.delete("expenses", rec_id)


def blank(when: str | None = None) -> dict:
    return {
        "id": None, "date": when or _date.today().isoformat(),
        "partner_id": None, "category": "", "description": "",
        "amount": D(0), "vat_rate": D(0), "source": SOURCE_MANUAL, "note": "",
    }
