# -*- coding: utf-8 -*-
"""Шифрарник на шифри за намена на плаќањето.

Табелата се полни со **официјалната листа на НБРСМ** (200 шифри, во
`paycodes_data.py`). Шифрите и описите се такви какви што се пропишани, а трите
правила што ги користи изводот се менуваат во ПОДЕСУВАЊА → Шифри на плаќање:

  * `auto_expense`     — ставката сама станува трошок (нема клиент за неа);
  * `expense_category` — во која категорија оди тој трошок;
  * `ask_always`       — не погодувај клиент и не памети сметка (другата страна
    е банка или менувачница, па сметката би се залепила за случаен клиент).

Промените на корисникот се неприкосновени: при надградба на листата се менуваат
само шифрите што стојат како што биле поставени, а не и оние што тој ги дотерал.
"""

from __future__ import annotations

import sqlite3

from ..db import db
from . import settings
from .paycodes_data import OFFICIAL

SEED_KEY = "paycodes_seed"
SEED_VERSION = 2          # 1 = првите 21 проверени шифри, 2 = официјалната листа

# Првата верзија на шифрарникот (значењата беа изведени од самите изводи).
# Стои тука само за да се препознае што корисникот НЕ го менувал.
LEGACY: list[tuple] = [
    ("100", "Лични примања на физичко лице преку трезор", "Лично", 0, "", 0),
    ("101", "Исплата на нето плата", "Плата", 1, "Плата и придонеси", 0),
    ("103", "Исплата на нето плата за вработени", "Плата", 1, "Плата и придонеси", 0),
    ("140", "Исплата на пензии", "Лично", 0, "", 0),
    ("180", "Други лични примања", "Лично", 0, "", 0),
    ("200", "Промет на производи и стоки помеѓу правни субјекти", "Стоки", 0, "", 0),
    ("210", "Аванс за производи и стоки", "Стоки", 0, "", 0),
    ("211", "Набавка на потрошен материјал", "Стоки", 0, "Материјални трошоци", 0),
    ("220", "Промет на услуги помеѓу правни субјекти", "Услуги", 0, "", 0),
    ("221", "Аванс за услуги", "Услуги", 0, "", 0),
    ("240", "Аванс за услуги/набавки", "Аванс", 0, "", 0),
    ("241", "Плаќање обврски пред прием на фактура (аванс)", "Аванс", 0, "", 0),
    ("262", "Други неспоменати плаќања на правни субјекти", "Останато", 0, "", 0),
    ("280", "Плаќање по профактура", "Профактура", 0, "", 0),
    ("479", "Откуп на девизни средства", "Девизи", 0, "", 1),
    ("666", "Банкарска провизија", "Банка", 1, "Банкарски трошоци", 1),
    ("674", "Провизија за откуп на девизи / дознака", "Банка", 1, "Банкарски трошоци", 1),
    ("800", "Уплата на дневен пазар (готовина)", "Готовина", 0, "", 0),
    ("840", "Данок на личен доход", "Данок", 1, "Данок", 0),
    ("843", "Социјални придонеси", "Придонес", 1, "Плата и придонеси", 0),
    ("930", "Останати плаќања на физички лица", "Останато", 0, "", 0),
]


def _payload(entry: tuple) -> dict:
    code, name, category, auto, expense_cat, ask = entry[:6]
    note = entry[6] if len(entry) > 6 else ""
    return {"code": code, "name": name, "category": category,
            "auto_expense": auto, "expense_category": expense_cat,
            "ask_always": ask, "note": note}


def _same_as(row: sqlite3.Row, entry: tuple) -> bool:
    """Дали редот стои точно како што бил поставен (значи корисникот не го пипал)."""
    code, name, category, auto, expense_cat, ask = entry[:6]
    return (str(row["name"]) == name and str(row["category"]) == category
            and int(row["auto_expense"]) == int(auto)
            and str(row["expense_category"]) == expense_cat
            and int(row["ask_always"]) == int(ask))


def ensure_seed() -> None:
    """Го полни/надградува шифрарникот, без да ги гази промените на корисникот."""
    database = db()
    version = settings.get_int(SEED_KEY, 0)
    if version >= SEED_VERSION:
        return

    empty = not database.scalar("SELECT COUNT(*) FROM payment_codes", default=0)
    legacy = {entry[0]: entry for entry in LEGACY}
    with database.tx():
        for entry in OFFICIAL:
            code = entry[0]
            payload = _payload(entry)
            row = database.one("SELECT * FROM payment_codes WHERE code = ?", (code,))
            if row is None:
                database.insert("payment_codes", dict(payload, active=1))
            elif empty or (code in legacy and _same_as(row, legacy[code])):
                # шифрата стои како што ја поставивме — ја заменува официјалната
                sets = ", ".join(f"{k} = :{k}" for k in payload if k != "code")
                database.execute(f"UPDATE payment_codes SET {sets} WHERE code = :code",
                                 payload)

        # Шифра од старата листа што ја нема во официјалната — нејзиното
        # значење било претпоставка, па тоа се пишува отворено.
        official = {entry[0] for entry in OFFICIAL}
        for code, entry in legacy.items():
            if code in official:
                continue
            row = database.one("SELECT * FROM payment_codes WHERE code = ?", (code,))
            if row is not None and _same_as(row, entry):
                database.execute(
                    "UPDATE payment_codes SET note = ? WHERE code = ?",
                    ("Не е во официјалната листа — значењето е претпоставено.", code))
        settings.set(SEED_KEY, SEED_VERSION)


def list_all(search: str = "", only_active: bool = False) -> list[sqlite3.Row]:
    sql = ["SELECT * FROM payment_codes WHERE 1 = 1"]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(code, '') || ' ' || COALESCE(name, '') || ' ' || COALESCE(category, '') || ' ' || COALESCE(note, ''), ?)")
        params.append(text)
    if only_active:
        sql.append("AND active = 1")
    sql.append("ORDER BY code")
    return db().query(" ".join(sql), params)


def get(code) -> sqlite3.Row | None:
    code = str(code or "").strip()
    if not code:
        return None
    return db().one("SELECT * FROM payment_codes WHERE code = ? AND active = 1", (code,))


def label(code) -> str:
    row = get(code)
    return row["name"] if row is not None else ""


def category(code) -> str:
    row = get(code)
    return row["category"] if row is not None else ""


def describe(code) -> str:
    code = str(code or "").strip()
    if not code:
        return ""
    name = label(code)
    return f"{code} — {name}" if name else code


def is_bank_fee(code) -> bool:
    row = get(code)
    return bool(row is not None and row["auto_expense"])


def always_ask(code) -> bool:
    row = get(code)
    return bool(row is not None and row["ask_always"])


def expense_category(code, default: str = "") -> str:
    row = get(code)
    if row is not None and row["expense_category"]:
        return row["expense_category"]
    return default


def save(code: str, data: dict) -> None:
    code = str(code or "").strip()
    if not code:
        raise ValueError("Внеси шифра.")
    payload = {
        "name": str(data.get("name") or "").strip(),
        "category": str(data.get("category") or "").strip(),
        "auto_expense": 1 if data.get("auto_expense") else 0,
        "expense_category": str(data.get("expense_category") or "").strip(),
        "ask_always": 1 if data.get("ask_always") else 0,
        "active": 1 if data.get("active", True) else 0,
        "note": str(data.get("note") or "").strip(),
    }
    database = db()
    with database.tx():
        if database.one("SELECT code FROM payment_codes WHERE code = ?", (code,)):
            sets = ", ".join(f"{k} = :{k}" for k in payload)
            database.execute(f"UPDATE payment_codes SET {sets} WHERE code = :code",
                             dict(payload, code=code))
        else:
            database.insert("payment_codes", dict(payload, code=code))


def delete(code: str) -> None:
    database = db()
    with database.tx():
        database.execute("DELETE FROM payment_codes WHERE code = ?", (str(code),))
