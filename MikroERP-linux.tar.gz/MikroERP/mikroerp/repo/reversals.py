# -*- coding: utf-8 -*-
"""Сторно на фактура и повратница на испратница.

**Сторно** е огледало на фактурата: истите ставки со негативни количини и
износи. Во книгите ефектот се брише, а бројот на оригиналната фактура останува
— затоа сторно, а не бришење. Сторното е фактура како и секоја друга и се
гледа во истата листа.

**Повратница** е испратница во обратна насока. Стоката се враќа на залиха по
**цената по која излегла** (цената на чинење што ја одзеде FIFO), а на самиот
документ стојат продажните цени од испратницата — по тоа се разликува од
приемница, каде цените се набавни. Се гледа во листата на испратници.

Правило за бришење: додека фактурата не е поднесена во УЈП, се брише нормално.
Штом е поднесена, бришењето е забрането и единствениот пат назад е сторно.
"""

from __future__ import annotations

from datetime import date as _date

from ..db import db
from ..money import D, q, q2
from . import docnum, issues, links, sales, stock

# Состојби во е-Фактура кои значат „поднесена е, нема враќање назад“
SUBMITTED = ("podnesena", "prifatena", "odbiena", "stornirana")


class ReversalError(RuntimeError):
    pass


# ------------------------------------------------------------------ состојба
def is_submitted(record) -> bool:
    """Дали фактурата е пратена во УЈП (тогаш не се брише, само се сторнира)."""
    try:
        return str(record["ujp_status"] or "").strip().lower() in SUBMITTED
    except (KeyError, IndexError, TypeError):
        return False


def storno_of(invoice_id: int):
    """Сторното на оваа фактура, ако е сторнирана."""
    return db().one("SELECT * FROM sales_docs WHERE storno_of_id = ? LIMIT 1",
                    (int(invoice_id),))


def is_stornirana(invoice_id: int) -> bool:
    return storno_of(invoice_id) is not None


def why_cannot_delete(record) -> str:
    """Празно ако смее да се брише, инаку причината."""
    if record is None:
        return ""
    if is_submitted(record):
        return ("Фактурата е поднесена во УЈП и не смее да се брише.\n\n"
                "Направи сторно — тоа го поништува ефектот, а бројот останува.")
    if int(record["is_storno"] or 0):
        return ""
    if is_stornirana(int(record["id"])):
        storno = storno_of(int(record["id"]))
        return (f"Фактурата е сторнирана со {storno['doc_no']}.\n\n"
                "Прво избриши го сторното, ако навистина треба да се брише.")
    return ""


def return_of(issue_id: int):
    """Повратницата на оваа испратница, ако постои."""
    return db().one("SELECT * FROM goods_issues WHERE return_of_id = ? LIMIT 1",
                    (int(issue_id),))


# -------------------------------------------------------------------- сторно
def _line_cost(line) -> D.__class__:
    """Цената на чинење по единица, онаа со која стоката излегла."""
    qty = D(line["qty"] or 0)
    cost = D(line["cost"] or 0) if "cost" in line.keys() else D(0)
    return q(cost / qty, 4) if qty else D(0)


def storno_invoice(invoice_id: int, when: str | None = None) -> int:
    """Прави сторно фактура (огледало со негативни износи). Враќа нов id."""
    record = sales.get(invoice_id)
    if record is None:
        raise ReversalError("Фактурата не постои.")
    if int(record["is_storno"] or 0):
        raise ReversalError("Ова е сторно документ — не се сторнира сторно.")
    existing = storno_of(invoice_id)
    if existing is not None:
        raise ReversalError(f"Фактурата е веќе сторнирана со {existing['doc_no']}.")

    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    lines = sales.lines(invoice_id)
    if not lines:
        raise ReversalError("Фактурата нема ставки.")

    database = db()
    with database.tx():
        seq, doc_no, doc_year = docnum.take(sales.NUMBER_TYPE[sales.KIND_INVOICE], year)
        total_net = total_vat = total_gross = total_cost = D(0)
        new_id = database.insert("sales_docs", {
            "kind": sales.KIND_INVOICE, "doc_no": doc_no, "doc_year": doc_year,
            "doc_seq": seq, "date": when, "due_date": "",
            "partner_id": record["partner_id"], "warehouse_id": record["warehouse_id"],
            "issue_id": None, "source_id": None,
            "moves_stock": 0,          # враќањето го правиме тука, рачно
            "note": f"Сторно на фактура {record['doc_no']}",
            "use_full_name": record["use_full_name"],
            "classification": record["classification"] or "",
            "is_storno": 1, "storno_of_id": int(invoice_id),
        })

        # Стоката се враќа само ако ОВАА фактура ја однела (без испратница).
        returns_stock = bool(record["moves_stock"])
        for index, line in enumerate(lines, start=1):
            qty = D(line["qty"] or 0)
            net = -q2(line["net"])
            vat = -q2(line["vat"])
            gross = -q2(line["gross"])
            cost = D(0)
            if returns_stock and qty > 0:
                unit_cost = _line_cost(line)
                stock.receive(
                    item_id=int(line["item_id"]), warehouse_id=record["warehouse_id"],
                    date=when, doc_type=sales.STOCK_TYPE, doc_id=new_id,
                    doc_no=doc_no, qty=qty, unit_cost=unit_cost)
                cost = -q2(line["cost"] or 0)
            total_net += net
            total_vat += vat
            total_gross += gross
            total_cost += cost
            database.insert("sales_doc_items", {
                "doc_id": new_id, "line_no": index, "item_id": line["item_id"],
                "qty": float(-qty), "price": float(line["price"]),
                "discount": float(line["discount"]), "tax_rate": float(line["tax_rate"]),
                "net": float(net), "vat": float(vat), "gross": float(gross),
                "cost": float(cost),
            })

        database.execute(
            "UPDATE sales_docs SET total_net = ?, total_vat = ?, total_gross = ?, "
            "total_cost = ? WHERE id = ?",
            (float(q2(total_net)), float(q2(total_vat)), float(q2(total_gross)),
             float(q2(total_cost)), new_id))
    return int(new_id)


# --------------------------------------------------------------- повратница
def povratnica(issue_id: int, when: str | None = None) -> int:
    """Прави повратница по испратница — стоката се враќа на залиха."""
    record = issues.get(issue_id)
    if record is None:
        raise ReversalError("Испратницата не постои.")
    if int(record["is_return"] or 0):
        raise ReversalError("Ова е повратница — не се прави повратница на повратница.")
    existing = return_of(issue_id)
    if existing is not None:
        raise ReversalError(f"Испратницата веќе има повратница {existing['doc_no']}.")

    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    lines = issues.lines(issue_id)
    if not lines:
        raise ReversalError("Испратницата нема ставки.")

    database = db()
    with database.tx():
        seq, doc_no, doc_year = docnum.take(issues.DOC_TYPE, year)
        total_net = total_vat = total_gross = total_cost = D(0)
        new_id = database.insert("goods_issues", {
            "doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq,
            "date": when, "partner_id": record["partner_id"],
            "warehouse_id": record["warehouse_id"],
            "note": f"Повратница по испратница {record['doc_no']}",
            "use_full_name": record["use_full_name"],
            "is_return": 1, "return_of_id": int(issue_id),
        })

        for index, line in enumerate(lines, start=1):
            qty = D(line["qty"] or 0)
            unit_cost = _line_cost(line)
            if qty > 0:
                # Се враќа по цената на чинење со која излегла — вредноста на
                # залихата останува иста како пред испратницата.
                stock.receive(
                    item_id=int(line["item_id"]), warehouse_id=record["warehouse_id"],
                    date=when, doc_type=issues.DOC_TYPE, doc_id=new_id,
                    doc_no=doc_no, qty=qty, unit_cost=unit_cost)
            net = -q2(line["net"])
            vat = -q2(line["vat"])
            gross = -q2(line["gross"])
            cost = -q2(line["cost"] or 0)
            total_net += net
            total_vat += vat
            total_gross += gross
            total_cost += cost
            database.insert("goods_issue_items", {
                "issue_id": new_id, "line_no": index, "item_id": line["item_id"],
                "qty": float(-qty), "price": float(line["price"]),
                "discount": float(line["discount"]), "tax_rate": float(line["tax_rate"]),
                "net": float(net), "vat": float(vat), "gross": float(gross),
                "cost": float(cost),
            })

        database.execute(
            "UPDATE goods_issues SET total_net = ?, total_vat = ?, total_gross = ?, "
            "total_cost = ? WHERE id = ?",
            (float(q2(total_net)), float(q2(total_vat)), float(q2(total_gross)),
             float(q2(total_cost)), new_id))
    return int(new_id)


def issues_of_invoice(invoice_id: int) -> list:
    """Испратниците што ги покрива фактурата — за прашањето „и повратница?“."""
    return links.sources_of(links.FAKTURA, int(invoice_id))
