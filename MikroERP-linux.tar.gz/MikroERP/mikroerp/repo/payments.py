# -*- coding: utf-8 -*-
"""Плаќања — ставка од извод затвора фактура или трошок.

Една ставка може да покрие повеќе документи, и еден документ може да се
затвори со повеќе уплати. Затоа врската е посебна табела.
"""

from __future__ import annotations

import sqlite3

from ..db import db
from ..money import D, q2

KIND_SALES = "izlezna_faktura"
KIND_PURCHASE = "vlezna_faktura"
KIND_EXPENSE = "trosok"

LABEL = {
    KIND_SALES: "Излезна фактура",
    KIND_PURCHASE: "Влезна фактура",
    KIND_EXPENSE: "Трошок",
}

EPS = 0.005


class ValidationError(ValueError):
    pass


# ---------------------------------------------------------------- читање
def for_line(line_id: int) -> list[sqlite3.Row]:
    return db().query("SELECT * FROM payments WHERE line_id = ? ORDER BY id", (line_id,))


def for_target(kind: str, target_id: int) -> list[sqlite3.Row]:
    """Уплатите на еден документ, со податоци за изводот."""
    return db().query(
        "SELECT pm.*, l.direction, s.doc_no AS statement_no, s.date AS statement_date "
        "FROM payments pm "
        "JOIN bank_statement_lines l ON l.id = pm.line_id "
        "JOIN bank_statements s ON s.id = l.statement_id "
        "WHERE pm.target_kind = ? AND pm.target_id = ? ORDER BY pm.date, pm.id",
        (kind, target_id),
    )


def paid(kind: str, target_id: int):
    return q2(db().scalar(
        "SELECT COALESCE(SUM(amount), 0) FROM payments WHERE target_kind = ? AND target_id = ?",
        (kind, target_id), default=0) or 0)


def paid_map(kind: str) -> dict:
    """{id документ: платено} — за листите, во едно прашање."""
    rows = db().query(
        "SELECT target_id, SUM(amount) AS paid FROM payments WHERE target_kind = ? "
        "GROUP BY target_id", (kind,))
    return {int(r["target_id"]): q2(r["paid"] or 0) for r in rows}


def status(total, paid_amount) -> str:
    total = float(D(total or 0))
    paid_amount = float(D(paid_amount or 0))
    if paid_amount <= EPS:
        return "неплатена"
    if paid_amount + EPS >= total:
        return "платена"
    return "делумно"


# ---------------------------------------------------------------- пишување
def set_for_line(line_id: int, targets: list[dict], date: str = "") -> None:
    """Ги заменува сите врски на една ставка од извод.

    `targets`: [{kind, id, amount}]. Се повикува во веќе отворена трансакција.
    """
    database = db()
    database.execute("DELETE FROM payments WHERE line_id = ?", (line_id,))
    for target in targets or []:
        amount = q2(target.get("amount") or 0)
        if amount <= 0:
            continue
        database.insert("payments", {
            "line_id": line_id,
            "target_kind": str(target["kind"]),
            "target_id": int(target["id"]),
            "amount": float(amount),
            "date": str(target.get("date") or date or ""),
        })


# ------------------------------------------------- отворени документи
def open_documents(partner_id: int, direction: str) -> list[dict]:
    """Што чека наплата/плаќање кај овој клиент.

    Прилив → неговите излезни фактури; одлив → влезни фактури и трошоци.
    """
    database = db()
    out: list[dict] = []

    if direction == "прилив":
        rows = database.query(
            "SELECT id, doc_no, date, total_gross FROM sales_docs "
            "WHERE kind = 'faktura' AND partner_id = ? ORDER BY date, id", (partner_id,))
        kind = KIND_SALES
        for row in rows:
            total = q2(row["total_gross"])
            done = paid(kind, int(row["id"]))
            if float(total - done) > EPS:
                out.append({"kind": kind, "id": int(row["id"]), "doc_no": row["doc_no"],
                            "date": row["date"], "total": total, "paid": done,
                            "remaining": q2(total - done)})
        return out

    rows = database.query(
        "SELECT id, doc_no, date, total_gross FROM purchase_invoices "
        "WHERE partner_id = ? ORDER BY date, id", (partner_id,))
    for row in rows:
        total = q2(row["total_gross"])
        done = paid(KIND_PURCHASE, int(row["id"]))
        if float(total - done) > EPS:
            out.append({"kind": KIND_PURCHASE, "id": int(row["id"]), "doc_no": row["doc_no"],
                        "date": row["date"], "total": total, "paid": done,
                        "remaining": q2(total - done)})

    rows = database.query(
        "SELECT id, doc_no, date, amount FROM expenses WHERE partner_id = ? "
        "ORDER BY date, id", (partner_id,))
    for row in rows:
        total = q2(row["amount"])
        done = paid(KIND_EXPENSE, int(row["id"]))
        if float(total - done) > EPS:
            out.append({"kind": KIND_EXPENSE, "id": int(row["id"]), "doc_no": row["doc_no"],
                        "date": row["date"], "total": total, "paid": done,
                        "remaining": q2(total - done)})
    return out
