# -*- coding: utf-8 -*-
"""Пресметка на ставка во документ — заедничка за сите документи.

Основица = количина × цена × (1 − рабат/100);  ДДВ = основица × стапка/100.
Сè оди преку `Decimal`, па збировите на документот се точни до денар.
"""

from __future__ import annotations

from ..money import D, q, q2


class ValidationError(ValueError):
    pass


def line_amounts(qty, price, discount, tax_rate) -> dict:
    qty_d = q(qty, 3)
    price_d = q(price, 4)
    disc = q(discount or 0, 2)
    rate = q(tax_rate if tax_rate not in (None, "") else 18, 2)
    net = q2(qty_d * price_d * (D(1) - disc / D(100)))
    vat = q2(net * rate / D(100))
    return {"qty": qty_d, "price": price_d, "discount": disc, "tax_rate": rate,
            "net": net, "vat": vat, "gross": q2(net + vat)}


def clean_line(data: dict) -> dict:
    if not data.get("item_id"):
        raise ValidationError("Избери артикл.")
    amounts = line_amounts(data.get("qty"), data.get("price"),
                           data.get("discount"), data.get("tax_rate"))
    if amounts["qty"] <= 0:
        raise ValidationError("Количината мора да е поголема од нула.")
    if amounts["price"] < 0:
        raise ValidationError("Цената не може да е негативна.")
    if amounts["discount"] < 0 or amounts["discount"] > 100:
        raise ValidationError("Рабатот мора да е меѓу 0 и 100 %.")
    return {
        "item_id": int(data["item_id"]),
        "qty": float(amounts["qty"]), "price": float(amounts["price"]),
        "discount": float(amounts["discount"]), "tax_rate": float(amounts["tax_rate"]),
        "net": float(amounts["net"]), "vat": float(amounts["vat"]),
        "gross": float(amounts["gross"]),
    }


def totals_of(rows) -> tuple:
    net = vat = gross = D(0)
    for row in rows:
        net += D(row["net"])
        vat += D(row["vat"])
        gross += D(row["gross"])
    return q2(net), q2(vat), q2(gross)
