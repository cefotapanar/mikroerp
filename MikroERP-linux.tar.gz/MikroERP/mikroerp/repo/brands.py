# -*- coding: utf-8 -*-
"""Брендови."""

from __future__ import annotations

import sqlite3

from ..db import db

TABLE = "brands"


class ValidationError(ValueError):
    """Порака што директно се покажува на корисникот."""


def list_all(search: str = "", only_active: bool = False) -> list[sqlite3.Row]:
    sql = [
        "SELECT b.*, (SELECT COUNT(*) FROM items i WHERE i.brand_id = b.id) AS items_count",
        "FROM brands b WHERE 1 = 1",
    ]
    params: list = []
    if search.strip():
        sql.append("AND mkmatch(COALESCE(b.name, '') || ' ' || COALESCE(b.note, ''), ?)")
        params.append(search.strip())
    if only_active:
        sql.append("AND b.active = 1")
    sql.append("ORDER BY b.name COLLATE NOCASE")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one("SELECT * FROM brands WHERE id = ?", (rec_id,))


def options(only_active: bool = True) -> list[tuple[int, str]]:
    """За combobox во формите."""
    sql = "SELECT id, name FROM brands"
    if only_active:
        sql += " WHERE active = 1"
    sql += " ORDER BY name COLLATE NOCASE"
    return [(int(r["id"]), r["name"]) for r in db().query(sql)]


def _validate(data: dict, rec_id: int | None = None) -> None:
    name = (data.get("name") or "").strip()
    if not name:
        raise ValidationError("Внеси име на бренд.")
    exists = db().one(
        "SELECT id FROM brands WHERE name = ? COLLATE NOCASE AND id IS NOT ?",
        (name, rec_id),
    )
    if exists:
        raise ValidationError(f"Веќе постои бренд со име „{name}“.")


def create(data: dict) -> int:
    _validate(data)
    payload = {
        "name": (data.get("name") or "").strip(),
        "note": (data.get("note") or "").strip(),
        "active": 1 if data.get("active", True) else 0,
    }
    database = db()
    with database.tx():
        return database.insert(TABLE, payload)


def update(rec_id: int, data: dict) -> None:
    _validate(data, rec_id)
    database = db()
    with database.tx():
        database.execute(
            "UPDATE brands SET name = ?, note = ?, active = ?, "
            "updated_at = datetime('now','localtime') WHERE id = ?",
            (
                (data.get("name") or "").strip(),
                (data.get("note") or "").strip(),
                1 if data.get("active", True) else 0,
                rec_id,
            ),
        )


def items_count(rec_id: int) -> int:
    return int(db().scalar("SELECT COUNT(*) FROM items WHERE brand_id = ?", (rec_id,), default=0) or 0)


def delete(rec_id: int) -> None:
    database = db()
    with database.tx():
        database.delete(TABLE, rec_id)
