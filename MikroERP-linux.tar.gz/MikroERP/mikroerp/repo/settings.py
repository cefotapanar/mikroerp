# -*- coding: utf-8 -*-
"""Подесувања што се чуваат ВО базата (податоци за фирмата и сл.).

Разлика од config.ini: config.ini е за оваа инсталација (патека до база,
изглед), а `settings` се деловни податоци што патуваат заедно со базата.
"""

from __future__ import annotations

from ..db import db

# Стандардни клучеви + почетни вредности
DEFAULTS: dict[str, str] = {
    "firma_naziv": "",
    "firma_adresa": "",
    "firma_grad": "",
    "firma_postenski": "",
    "firma_drzava": "Македонија",
    "firma_edb": "",
    "firma_embs": "",
    "firma_danocen_obvrznik": "1",
    "firma_telefon": "",
    "firma_email": "",
    "firma_web": "",
    "firma_banka": "",
    "firma_ziro_smetka": "",
    "firma_direktor": "",
    "firma_dejnost": "",
    "firma_logo": "",
    "ddv_stapka": "18",
    "valuta": "ден.",
    # Официјалните податоци од УЈП стојат одвоено од оние што се печатат:
    # регистарот кажува едно, а на документот фирмата може да се претстави
    # поинаку (друга адреса, друг телефон, друга сметка).
    "ujp_naziv": "",
    "ujp_pln_naziv": "",
    "ujp_edb": "",
    "ujp_embs": "",
    "ujp_adresa": "",
    "ujp_grad": "",
    "ujp_telefon": "",
    "ujp_banka": "",
    "ujp_smetka": "",
    "ujp_dejnost": "",
    "ujp_povlecen": "",
    # е-Фактура (УЈП) — по фирма, за да работи софтверот и кај друга фирма со
    # друг токен: сертификатот се избира од складот на Windows, не се вградува.
    "efaktura_cert_serial": "",
    "efaktura_eujp_id": "",
    "efaktura_ulica": "",          # УЈП ја бара адресата разделена
    "efaktura_broj": "",
    "efaktura_postenski": "",
    "efaktura_grad": "",
    "efaktura_okolina": "test",    # test | prod
    # Регистрација на примерокот. Стои во базата (а не во config.ini) за да
    # преживее ажурирање — при копирањето на новите фајлови `data\` се изземa.
    "reg_install_id": "",
    "reg_licenca": "",
    "reg_status": "",
    "reg_datum": "",
    "reg_proverka": "",
}


def all() -> dict[str, str]:  # noqa: A001 — намерно, чита се како settings.all()
    values = dict(DEFAULTS)
    for row in db().query("SELECT key, value FROM settings"):
        values[row["key"]] = row["value"]
    return values


def get(key: str, default: str | None = None) -> str:
    row = db().one("SELECT value FROM settings WHERE key = ?", (key,))
    if row is not None:
        return row["value"]
    return DEFAULTS.get(key, "" if default is None else default)


def get_int(key: str, default: int = 0) -> int:
    try:
        return int(str(get(key)).strip())
    except (TypeError, ValueError):
        return default


def get_bool(key: str, default: bool = False) -> bool:
    value = str(get(key)).strip().lower()
    if value in ("1", "true", "да", "da"):
        return True
    if value in ("0", "false", "не", "ne"):
        return False
    return default


def set(key: str, value) -> None:  # noqa: A001
    db().execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT (key) DO UPDATE SET value = excluded.value",
        (key, "" if value is None else str(value)),
    )


def save_many(values: dict) -> None:
    database = db()
    with database.tx():
        for key, value in values.items():
            database.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) "
                "ON CONFLICT (key) DO UPDATE SET value = excluded.value",
                (key, "" if value is None else str(value)),
            )


def company_name() -> str:
    return get("firma_naziv") or "(фирмата не е внесена)"
