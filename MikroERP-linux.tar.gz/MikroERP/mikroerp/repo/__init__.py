﻿# -*- coding: utf-8 -*-
"""Пристап до податоците. GUI-то никогаш не пишува SQL директно."""

from . import (settings, brands, partners, items, warehouses, docnum,  # noqa: F401
               doclines, paycodes, stock, receipts, issues, sales, purchases, workorders,
               expenses, payments, statements, cards)

__all__ = ["settings", "brands", "partners", "items", "warehouses", "docnum",
           "doclines", "paycodes", "stock", "receipts", "issues", "sales", "purchases",
           "workorders", "expenses", "payments", "statements", "cards"]
