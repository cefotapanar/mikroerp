# -*- coding: utf-8 -*-
"""Залиха по FIFO.

Две табели работат заедно:
  * `stock_batches` — секој влез отвора серија со своја цена на чинење и
    преостаната количина (`qty_left`);
  * `stock_moves`  — дневник на сите движења (+ влез, − излез). Залихата и
    вредноста се читаат оттука.

Сите функции овде претпоставуваат дека повикувачот веќе отворил трансакција
(`with db().tx():`), за да може цел документ да помине или воопшто да не помине.
"""

from __future__ import annotations

import sqlite3

from ..db import db
from ..money import D, q, q2

EPS = 1e-9          # толеранција при споредба на количини (float во базата)


class StockError(RuntimeError):
    """Порака што директно се покажува на корисникот."""


# --------------------------------------------------------------------- влез
def receive(item_id: int, warehouse_id: int, date: str, doc_type: str, doc_id: int,
            doc_no: str, qty, unit_cost, source_line_id: int | None = None) -> int | None:
    """Влез на стока: отвора нова FIFO серија и запишува движење."""
    if not is_tracked(item_id):
        return None                     # услуга — не влегува во магацин
    qty_dec = q(qty, 3)
    if qty_dec <= 0:
        raise StockError("Количината мора да е поголема од нула.")
    cost_dec = q(unit_cost, 4)
    if cost_dec < 0:
        raise StockError("Цената на чинење не може да е негативна.")

    database = db()
    batch_id = database.insert("stock_batches", {
        "item_id": item_id, "warehouse_id": warehouse_id, "date": date,
        "doc_type": doc_type, "doc_id": doc_id, "doc_no": doc_no,
        "source_line_id": source_line_id,
        "qty_in": float(qty_dec), "qty_left": float(qty_dec),
        "unit_cost": float(cost_dec),
    })
    database.insert("stock_moves", {
        "item_id": item_id, "warehouse_id": warehouse_id, "date": date,
        "doc_type": doc_type, "doc_id": doc_id, "doc_no": doc_no,
        "batch_id": batch_id, "qty": float(qty_dec), "unit_cost": float(cost_dec),
        "value": float(q2(qty_dec * cost_dec)),
    })
    return batch_id


# -------------------------------------------------------------------- излез
def is_tracked(item_id: int) -> bool:
    """Услугите не се водат на залиха."""
    return not bool(db().scalar("SELECT is_service FROM items WHERE id = ?",
                                (item_id,), default=0))


def issue(item_id: int, warehouse_id: int, date: str, doc_type: str, doc_id: int,
          doc_no: str, qty) -> list[dict]:
    """Излез на стока по FIFO. Враќа од кои серии и по која цена е земено."""
    if not is_tracked(item_id):
        return []                       # услуга — нема движење на залиха

    remaining = q(qty, 3)
    if remaining <= 0:
        raise StockError("Количината мора да е поголема од нула.")

    database = db()
    batches = database.query(
        "SELECT * FROM stock_batches WHERE item_id = ? AND warehouse_id = ? "
        "AND qty_left > ? ORDER BY date, id",
        (item_id, warehouse_id, EPS),
    )
    available = sum((D(b["qty_left"]) for b in batches), D(0))
    if available + D(EPS) < remaining:
        item = database.one("SELECT name, allow_negative, purchase_price FROM items "
                            "WHERE id = ?", (item_id,))
        name = item["name"] if item else ""
        if not (item and item["allow_negative"]):
            raise StockError(
                f"Нема доволно залиха за „{name}“: бара се {remaining}, "
                f"а има {q(available, 3)}.\n\n"
                "Ако овој артикл смее да оди во минус, штиклирај го тоа во "
                "ШИФРАРНИК → Артикли."
            )
        # Дозволен минус: она што недостасува излегува по последната набавна
        # цена и се води како серија со негативна количина, за да се израмни
        # со следниот влез.
        short = q(remaining - available, 3)
        cost = q(D(item["purchase_price"]), 4)
        batch_id = database.insert("stock_batches", {
            "item_id": item_id, "warehouse_id": warehouse_id, "date": date,
            "doc_type": doc_type, "doc_id": doc_id, "doc_no": doc_no,
            "source_line_id": None,
            "qty_in": 0.0, "qty_left": float(-short), "unit_cost": float(cost),
        })
        database.insert("stock_moves", {
            "item_id": item_id, "warehouse_id": warehouse_id, "date": date,
            "doc_type": doc_type, "doc_id": doc_id, "doc_no": doc_no,
            "batch_id": batch_id, "qty": float(-short), "unit_cost": float(cost),
            "value": float(q2(-short * cost)),
        })
        remaining = available

    taken: list[dict] = []
    for batch in batches:
        if remaining <= 0:
            break
        left = D(batch["qty_left"])
        use = left if left <= remaining else remaining
        cost = D(batch["unit_cost"])
        database.execute(
            "UPDATE stock_batches SET qty_left = ? WHERE id = ?",
            (float(q(left - use, 3)), batch["id"]),
        )
        database.insert("stock_moves", {
            "item_id": item_id, "warehouse_id": warehouse_id, "date": date,
            "doc_type": doc_type, "doc_id": doc_id, "doc_no": doc_no,
            "batch_id": batch["id"], "qty": float(-use), "unit_cost": float(cost),
            "value": float(q2(-use * cost)),
        })
        taken.append({"batch_id": int(batch["id"]), "qty": use, "unit_cost": cost})
        remaining = q(remaining - use, 3)
    return taken


# ------------------------------------------------------------- поништување
def revert_document(doc_type: str, doc_id: int) -> None:
    """Ги брише сите последици од еден документ (враќање во нацрт).

    За влезните документи сериите смеат да се тргнат само ако ништо не е
    потрошено од нив — инаку цената на чинење на веќе издадената стока би
    останала без покритие.
    """
    database = db()

    for batch in database.query(
        "SELECT * FROM stock_batches WHERE doc_type = ? AND doc_id = ? AND qty_in > 0",
        (doc_type, doc_id)
    ):
        if abs(float(batch["qty_left"]) - float(batch["qty_in"])) > EPS:
            used = q(D(batch["qty_in"]) - D(batch["qty_left"]), 3)
            name = database.scalar("SELECT name FROM items WHERE id = ?",
                                   (batch["item_id"],), default="")
            raise StockError(
                f"Од „{name}“ веќе е издадено {used} од оваа приемница.\n\n"
                "Прво поништи ги документите што ја трошеле оваа стока."
            )

    # Излезните движења се враќаат назад во своите серии.
    for move in database.query(
        "SELECT * FROM stock_moves WHERE doc_type = ? AND doc_id = ? AND qty < 0",
        (doc_type, doc_id),
    ):
        if move["batch_id"]:
            database.execute(
                "UPDATE stock_batches SET qty_left = qty_left + ? WHERE id = ?",
                (float(-D(move["qty"])), move["batch_id"]),
            )

    database.execute("DELETE FROM stock_moves WHERE doc_type = ? AND doc_id = ?",
                     (doc_type, doc_id))
    database.execute("DELETE FROM stock_batches WHERE doc_type = ? AND doc_id = ?",
                     (doc_type, doc_id))


# ---------------------------------------------------------------- прашалници
def on_hand(item_id: int, warehouse_id: int | None = None):
    sql = "SELECT COALESCE(SUM(qty), 0) FROM stock_moves WHERE item_id = ?"
    params: list = [item_id]
    if warehouse_id:
        sql += " AND warehouse_id = ?"
        params.append(warehouse_id)
    return q(db().scalar(sql, params, default=0) or 0, 3)


def estimate_cost(item_id: int, warehouse_id: int, qty) -> tuple:
    """Колку БИ чинело ова издавање по FIFO, без ништо да се смени.

    Враќа (вредност, недостасува). Служи за жив приказ во работниот налог,
    пред документот да е зачуван.
    """
    need = q(qty, 3)
    if need <= 0:
        return q2(0), q(0, 3)
    if not is_tracked(item_id):
        cost = q(db().scalar("SELECT purchase_price FROM items WHERE id = ?",
                             (item_id,), default=0) or 0, 4)
        return q2(need * cost), q(0, 3)

    total = D(0)
    for batch in db().query(
        "SELECT qty_left, unit_cost FROM stock_batches WHERE item_id = ? "
        "AND warehouse_id = ? AND qty_left > ? ORDER BY date, id",
        (item_id, warehouse_id, EPS),
    ):
        if need <= 0:
            break
        use = min(D(batch["qty_left"]), need)
        total += use * D(batch["unit_cost"])
        need = q(need - use, 3)
    if need > 0:
        # нема доволно — остатокот се проценува по последната набавна цена
        cost = q(db().scalar("SELECT purchase_price FROM items WHERE id = ?",
                             (item_id,), default=0) or 0, 4)
        total += need * cost
    return q2(total), q(need, 3)


def value_on_hand(item_id: int, warehouse_id: int | None = None):
    sql = ("SELECT COALESCE(SUM(qty_left * unit_cost), 0) FROM stock_batches "
           "WHERE item_id = ?")
    params: list = [item_id]
    if warehouse_id:
        sql += " AND warehouse_id = ?"
        params.append(warehouse_id)
    return q2(db().scalar(sql, params, default=0) or 0)


def lager(search: str = "", warehouse_id: int | None = None,
          only_with_stock: bool = False, only_below_min: bool = False) -> list[sqlite3.Row]:
    """Лагер листа: количина и вредност по артикл."""
    params: list = []
    where_batch = "b.item_id = i.id"
    if warehouse_id:
        where_batch += " AND b.warehouse_id = :wh"

    sql = [
        "SELECT i.id, i.code, i.name, i.unit, i.min_stock, i.price_retail, i.tax_rate,",
        "       COALESCE(br.name, '') AS brand_name,",
        "       (SELECT COALESCE(SUM(b.qty_left), 0) FROM stock_batches b",
        f"        WHERE {where_batch}) AS qty,",
        "       (SELECT COALESCE(SUM(b.qty_left * b.unit_cost), 0) FROM stock_batches b",
        f"        WHERE {where_batch}) AS value",
        "FROM items i LEFT JOIN brands br ON br.id = i.brand_id",
        "WHERE i.is_service = 0",       # услугите не се на лагер
    ]
    named: dict = {}
    if warehouse_id:
        named["wh"] = warehouse_id
    text = search.strip()
    if text:
        sql.append("AND (i.code LIKE :q OR i.name LIKE :q OR i.barcode LIKE :q "
                   "OR br.name LIKE :q)")
        named["q"] = f"%{text}%"
    sql.append("ORDER BY i.code COLLATE NOCASE")

    rows = db().query(" ".join(sql), named)
    result = []
    for row in rows:
        qty = float(row["qty"] or 0)
        if only_with_stock and abs(qty) <= EPS:
            continue
        if only_below_min and qty > float(row["min_stock"] or 0) + EPS:
            continue
        result.append(row)
    return result


def moves(item_id: int, warehouse_id: int | None = None, limit: int = 500) -> list[sqlite3.Row]:
    """Картица на артикл — сите движења, најново прво."""
    sql = ["SELECT * FROM stock_moves WHERE item_id = ?"]
    params: list = [item_id]
    if warehouse_id:
        sql.append("AND warehouse_id = ?")
        params.append(warehouse_id)
    sql.append("ORDER BY date DESC, id DESC LIMIT ?")
    params.append(limit)
    return db().query(" ".join(sql), params)


def totals(warehouse_id: int | None = None) -> tuple:
    """(вкупна вредност на залихата, број на артикли со залиха)."""
    sql = ["SELECT COALESCE(SUM(qty_left * unit_cost), 0) AS value,",
           "COUNT(DISTINCT item_id) AS items FROM stock_batches WHERE qty_left > :eps"]
    named = {"eps": EPS}
    if warehouse_id:
        sql.append("AND warehouse_id = :wh")
        named["wh"] = warehouse_id
    row = db().one(" ".join(sql), named)
    return q2(row["value"] or 0), int(row["items"] or 0)
