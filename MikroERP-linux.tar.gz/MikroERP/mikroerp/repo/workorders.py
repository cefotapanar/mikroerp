# -*- coding: utf-8 -*-
"""Работни налози — материјали → готов производ.

Два чекора, зашто тоа се два вистински настани:

  1. **Зачувај** — материјалите излегуваат од магацинот-извор по FIFO.
     Налогот е `започнат`; лагерот е оптоварен, производот сè уште го нема.
  2. **Произведи** — готовиот производ влегува во магацинот-примач по цена на
     чинење = вкупната вредност на вложените материјали / произведената
     количина. Налогот е `произведен`.

Изворниот и примачкиот магацин смеат да бидат ист.
Излез од налог може да биде само артикл означен како **производ**.
"""

from __future__ import annotations

import sqlite3
from datetime import date as _date

from ..db import db
from ..money import D, q, q2
from . import docnum, items, stock, warehouses

DOC_TYPE = "raboten_nalog"
OUT_TYPE = "raboten_nalog_izlez"     # материјалите излегуваат
IN_TYPE = "raboten_nalog_vlez"       # производот влегува

STATUS_STARTED = "започнат"
STATUS_DONE = "произведен"


class ValidationError(ValueError):
    pass


# ------------------------------------------------------------------- листа
def list_all(search: str = "", year: int | None = None) -> list[sqlite3.Row]:
    sql = [
        "SELECT n.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit,",
        "       COALESCE(wf.name, '') AS from_name, COALESCE(wt.name, '') AS to_name,",
        "       (SELECT COUNT(*) FROM work_order_items l WHERE l.order_id = n.id) AS lines_count",
        "FROM work_orders n",
        "JOIN items i ON i.id = n.item_id",
        "LEFT JOIN warehouses wf ON wf.id = n.from_warehouse_id",
        "LEFT JOIN warehouses wt ON wt.id = n.to_warehouse_id",
        "WHERE 1 = 1",
    ]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(n.doc_no, '') || ' ' || COALESCE(i.code, '') "
                   "|| ' ' || COALESCE(i.name, '') || ' ' || COALESCE(n.note, ''), ?)")
        params.append(text)
    if year:
        sql.append("AND n.doc_year = ?")
        params.append(year)
    sql.append("ORDER BY n.doc_year DESC, n.doc_seq DESC")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT n.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit, "
        "       COALESCE(wf.name, '') AS from_name, COALESCE(wt.name, '') AS to_name "
        "FROM work_orders n JOIN items i ON i.id = n.item_id "
        "LEFT JOIN warehouses wf ON wf.id = n.from_warehouse_id "
        "LEFT JOIN warehouses wt ON wt.id = n.to_warehouse_id WHERE n.id = ?",
        (rec_id,),
    )


def lines(rec_id: int) -> list[sqlite3.Row]:
    return db().query(
        "SELECT l.*, i.code AS item_code, i.name AS item_name, i.unit AS item_unit "
        "FROM work_order_items l JOIN items i ON i.id = l.item_id "
        "WHERE l.order_id = ? ORDER BY l.line_no, l.id",
        (rec_id,),
    )


def header_of(record) -> dict:
    return {
        "id": record["id"], "doc_no": record["doc_no"], "date": record["date"],
        "item_id": record["item_id"], "qty": D(record["qty"]),
        "from_warehouse_id": record["from_warehouse_id"],
        "to_warehouse_id": record["to_warehouse_id"],
        "status": record["status"], "note": record["note"],
    }


def blank(when: str | None = None) -> dict:
    when = when or _date.today().isoformat()
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    default = warehouses.default_id()
    return {
        "id": None,
        "doc_no": docnum.peek(DOC_TYPE, year)[1],
        "date": when,
        "item_id": None,
        "qty": D(1),
        "from_warehouse_id": default,
        "to_warehouse_id": default,
        "status": STATUS_STARTED,
        "note": "",
    }


def is_done(record) -> bool:
    return str(record["status"]) == STATUS_DONE


def clean_line(data: dict) -> dict:
    if not data.get("item_id"):
        raise ValidationError("Избери материјал.")
    qty = q(data.get("qty"), 3)
    if qty <= 0:
        raise ValidationError("Количината мора да е поголема од нула.")
    return {"item_id": int(data["item_id"]), "qty": float(qty)}


def estimate(header: dict, doc_lines: list[dict]) -> tuple:
    """Проценка пред зачувување: (вредност на материјалите, цена по единица)."""
    from_wh = int(header.get("from_warehouse_id") or warehouses.default_id())
    total = D(0)
    for line in doc_lines:
        cost, _short = stock.estimate_cost(int(line["item_id"]), from_wh, line["qty"])
        total += cost
    qty = q(header.get("qty") or 0, 3)
    return q2(total), (q(total / qty, 4) if qty else D(0))


# ------------------------------------------------------------------ снимање
def save_document(rec_id: int | None, header: dict, doc_lines: list[dict],
                  produce: bool | None = None) -> int:
    """`produce=None` значи „задржи ја тековната состојба“."""
    if not header.get("item_id"):
        raise ValidationError("Избери производ што се изработува.")
    product = items.get(int(header["item_id"]))
    if product is None:
        raise ValidationError("Производот не постои.")
    if not items.is_manufactured(product):
        raise ValidationError(
            f"„{product['name']}“ не е означен како производ.\n\n"
            "Во ШИФРАРНИК → Артикли постави Вид = производ за артиклите што се "
            "изработуваат со работен налог."
        )
    qty = q(header.get("qty") or 0, 3)
    if qty <= 0:
        raise ValidationError("Внеси количина што се произведува.")
    if not doc_lines:
        raise ValidationError("Работниот налог нема ниту еден материјал.")
    clean = [clean_line(line) for line in doc_lines]
    if any(line["item_id"] == int(header["item_id"]) for line in clean):
        raise ValidationError("Производот не може да биде и материјал во истиот налог.")

    when = str(header.get("date") or _date.today().isoformat())
    year = int(when[:4]) if when[:4].isdigit() else _date.today().year
    from_wh = int(header.get("from_warehouse_id") or warehouses.default_id())
    to_wh = int(header.get("to_warehouse_id") or from_wh)

    database = db()
    with database.tx():
        if rec_id:
            existing = database.one("SELECT * FROM work_orders WHERE id = ?", (rec_id,))
            if existing is None:
                raise ValidationError("Работниот налог не постои.")
            if produce is None:
                produce = str(existing["status"]) == STATUS_DONE
            # прво се поништува произведеното, па вратените материјали
            stock.revert_document(IN_TYPE, rec_id)
            stock.revert_document(OUT_TYPE, rec_id)
            database.execute("DELETE FROM work_order_items WHERE order_id = ?", (rec_id,))
            doc_no = existing["doc_no"]
            database.execute(
                "UPDATE work_orders SET date = ?, item_id = ?, qty = ?, "
                "from_warehouse_id = ?, to_warehouse_id = ?, note = ?, "
                "updated_at = datetime('now','localtime') WHERE id = ?",
                (when, int(header["item_id"]), float(qty), from_wh, to_wh,
                 str(header.get("note") or "").strip(), rec_id),
            )
        else:
            produce = bool(produce)
            seq, doc_no, doc_year = docnum.take(DOC_TYPE, year)
            rec_id = database.insert("work_orders", {
                "doc_no": doc_no, "doc_year": doc_year, "doc_seq": seq,
                "date": when, "item_id": int(header["item_id"]), "qty": float(qty),
                "from_warehouse_id": from_wh, "to_warehouse_id": to_wh,
                "status": STATUS_STARTED,
                "note": str(header.get("note") or "").strip(),
            })

        # 1) материјалите излегуваат по FIFO
        material_cost = D(0)
        for index, line in enumerate(clean, start=1):
            taken = stock.issue(
                item_id=line["item_id"], warehouse_id=from_wh, date=when,
                doc_type=OUT_TYPE, doc_id=rec_id, doc_no=doc_no, qty=line["qty"],
            )
            if taken:
                cost = q2(sum((t["qty"] * t["unit_cost"] for t in taken), D(0)))
            else:
                # услуга (не се води на залиха) — по последната набавна цена
                unit = q(database.scalar("SELECT purchase_price FROM items WHERE id = ?",
                                         (line["item_id"],), default=0) or 0, 4)
                cost = q2(D(line["qty"]) * unit)
            material_cost += cost
            database.insert("work_order_items",
                            dict(line, order_id=rec_id, line_no=index, cost=float(cost)))

        unit_cost = q(material_cost / qty, 4) if qty else D(0)

        # 2) готовиот производ влегува (само кога се произведува)
        if produce:
            stock.receive(
                item_id=int(header["item_id"]), warehouse_id=to_wh, date=when,
                doc_type=IN_TYPE, doc_id=rec_id, doc_no=doc_no,
                qty=qty, unit_cost=unit_cost,
            )
            items.set_purchase_price(int(header["item_id"]), unit_cost)

        database.execute(
            "UPDATE work_orders SET material_cost = ?, unit_cost = ?, status = ?, "
            "produced_at = ? WHERE id = ?",
            (float(q2(material_cost)), float(unit_cost),
             STATUS_DONE if produce else STATUS_STARTED,
             _date.today().isoformat() if produce else "", rec_id),
        )
    return int(rec_id)


def delete(rec_id: int) -> None:
    rec = get(rec_id)
    if rec is None:
        return
    database = db()
    with database.tx():
        stock.revert_document(IN_TYPE, rec_id)      # ќе фрли ако производот е потрошен
        stock.revert_document(OUT_TYPE, rec_id)     # материјалите се враќаат
        database.delete("work_orders", rec_id)
