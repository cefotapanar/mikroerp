# -*- coding: utf-8 -*-
"""Артикли.

Вид на артикл:
  * **стока**    — се купува и се продава (стандардно);
  * **производ** — се ИЗРАБОТУВА со работен налог; само вакви артикли ќе може
    да се произведуваат. Може и да се купува како стока;
  * **услуга**   — не се води на залиха, може да се додава во документи, но
    нема никаков ефект врз лагерот.

Цени: малопродажната и партнерската се чуваат и **без ДДВ** и **со ДДВ**.
Која и да се внесе, другата се пресметува — и во формата и тука во слојот
за податоци, за да не може да се разидат.

Набавната цена НЕ се внесува рачно — ја запишува приемницата при проведување.
"""

from __future__ import annotations

import sqlite3

from ..db import db
from ..money import D, q, q2, with_vat, without_vat

TABLE = "items"

UNITS = ["ком", "кг", "г", "л", "м", "м2", "м3", "пар", "сет", "пак", "час"]
TAX_RATES = ["18", "10", "5", "0"]

KIND_GOODS = "стока"
KIND_PRODUCT = "производ"
KIND_SERVICE = "услуга"
KINDS = [KIND_GOODS, KIND_PRODUCT, KIND_SERVICE]


class ValidationError(ValueError):
    pass


def list_all(search: str = "", brand_id: int | None = None, only_active: bool = False,
             only_products: bool = False, only_manufactured: bool = False,
             kind: str = "") -> list[sqlite3.Row]:
    sql = [
        "SELECT i.*, COALESCE(b.name, '') AS brand_name",
        "FROM items i LEFT JOIN brands b ON b.id = i.brand_id",
        "WHERE 1 = 1",
    ]
    params: list = []
    text = search.strip()
    if text:
        sql.append("AND mkmatch(COALESCE(i.code, '') || ' ' || COALESCE(i.name, '') || ' ' || COALESCE(i.barcode, '') || ' ' || COALESCE(b.name, ''), ?)")
        params.append(text)
    if brand_id:
        sql.append("AND i.brand_id = ?")
        params.append(brand_id)
    if only_active:
        sql.append("AND i.active = 1")
    if only_products:                 # сè што оди на лагер (стока + производ)
        sql.append("AND i.is_service = 0")
    if only_manufactured:             # само тоа што може да се изработува
        sql.append("AND i.kind = ?")
        params.append(KIND_PRODUCT)
    if kind:
        sql.append("AND i.kind = ?")
        params.append(kind)
    sql.append("ORDER BY i.code COLLATE NOCASE")
    return db().query(" ".join(sql), params)


def get(rec_id: int) -> sqlite3.Row | None:
    return db().one(
        "SELECT i.*, COALESCE(b.name, '') AS brand_name "
        "FROM items i LEFT JOIN brands b ON b.id = i.brand_id WHERE i.id = ?",
        (rec_id,),
    )


def by_code(code: str) -> sqlite3.Row | None:
    return db().one("SELECT * FROM items WHERE code = ? COLLATE NOCASE", (code.strip(),))


def kind_of(row) -> str:
    try:
        return str(row["kind"] or KIND_GOODS)
    except (KeyError, IndexError):
        return KIND_SERVICE if row["is_service"] else KIND_GOODS


def is_service(row) -> bool:
    return kind_of(row) == KIND_SERVICE


def is_manufactured(row) -> bool:
    """Дали артиклот може да биде излез од работен налог."""
    return kind_of(row) == KIND_PRODUCT


def kind_label(row) -> str:
    return kind_of(row).capitalize()


# ------------------------------------------------------------------- цени
# Продажните цени се водат по цената СО ДДВ, заокружена на цел денар (.00).
# Цената без ДДВ секогаш се изведува од неа, за да нема разидување.
def round_gross(gross):
    return q2(q(gross, 0))


def net_from_gross(gross, rate):
    return without_vat(round_gross(gross), rate)


def gross_from_net(net, rate):
    return round_gross(with_vat(net, rate))


def _price_pair(data: dict, current, net_key: str, gross_key: str, rate):
    """Враќа (без ДДВ, со ДДВ). Водечка е цената со ДДВ, заокружена на .00."""
    def given(key):
        return key in data and str(data[key]).strip() != ""

    if given(gross_key):
        gross = round_gross(D(data[gross_key]))
    elif given(net_key):
        gross = gross_from_net(D(data[net_key]), rate)
    elif current is not None:
        gross = round_gross(D(current[gross_key]))
    else:
        return q2(0), q2(0)
    return without_vat(gross, rate), gross


def _clean(data: dict, current: sqlite3.Row | None = None) -> dict:
    def keep(key, default=0):
        if key in data and data[key] not in ("", None):
            return data[key]
        if current is not None:
            return current[key]
        return default

    rate = D(keep("tax_rate", 18))
    retail_net, retail_gross = _price_pair(data, current, "price_retail_net", "price_retail", rate)
    partner_net, partner_gross = _price_pair(data, current, "price_partner",
                                             "price_partner_gross", rate)

    brand_id = data.get("brand_id", current["brand_id"] if current is not None else None)
    kind = data.get("kind")
    if not kind and "is_service" in data:
        # постар облик на повикот: is_service=True значи услуга
        kind = KIND_SERVICE if data["is_service"] else KIND_GOODS
    if not kind:
        kind = kind_of(current) if current is not None else KIND_GOODS
    kind = str(kind)
    if kind not in KINDS:
        kind = KIND_GOODS
    service = kind == KIND_SERVICE
    return {
        "kind": kind,
        "code": str(keep("code", "")).strip(),
        "barcode": str(data.get("barcode", keep("barcode", "")) or "").strip(),
        "name": str(keep("name", "")).strip(),
        "brand_id": int(brand_id) if brand_id else None,
        "unit": str(keep("unit", "ком")).strip() or "ком",
        "tax_rate": float(q2(rate)),
        "purchase_price": float(q2(D(keep("purchase_price", 0)))),
        "price_retail_net": float(retail_net),
        "price_retail": float(retail_gross),
        "price_partner": float(partner_net),
        "price_partner_gross": float(partner_gross),
        "min_stock": float(D(keep("min_stock", 0))),
        "is_service": 1 if service else 0,
        "allow_negative": 0 if service else (
            1 if data.get("allow_negative", current["allow_negative"] if current is not None else 0)
            else 0),
        "note": str(data.get("note", keep("note", "")) or "").strip(),
        "active": 1 if data.get("active", current["active"] if current is not None else True) else 0,
    }


def _validate(payload: dict, rec_id: int | None = None) -> None:
    if not payload["code"]:
        raise ValidationError("Внеси шифра на артиклот.")
    if not payload["name"]:
        raise ValidationError("Внеси назив на артиклот.")
    exists = db().one(
        "SELECT id FROM items WHERE code = ? COLLATE NOCASE AND id IS NOT ?",
        (payload["code"], rec_id),
    )
    if exists:
        raise ValidationError(f"Шифрата „{payload['code']}“ е веќе зафатена.")
    if payload["tax_rate"] < 0 or payload["tax_rate"] > 100:
        raise ValidationError("ДДВ стапката мора да е помеѓу 0 и 100.")
    for field, name in (("price_retail", "Малопродажна цена"),
                        ("price_partner", "Партнерска цена")):
        if payload[field] < 0:
            raise ValidationError(f"{name} не може да биде негативна.")


def create(data: dict) -> int:
    payload = _clean(data)
    _validate(payload)
    database = db()
    with database.tx():
        return database.insert(TABLE, payload)


def update(rec_id: int, data: dict) -> None:
    current = get(rec_id)
    if current is None:
        raise ValidationError("Артиклот не постои.")
    payload = _clean(data, current)
    _validate(payload, rec_id)
    database = db()
    with database.tx():
        database.update(TABLE, rec_id, payload)
        database.execute(
            "UPDATE items SET updated_at = datetime('now','localtime') WHERE id = ?", (rec_id,)
        )


def set_purchase_price(rec_id: int, price) -> None:
    """Го користи приемницата при проведување."""
    db().execute(
        "UPDATE items SET purchase_price = ?, updated_at = datetime('now','localtime') "
        "WHERE id = ?", (float(q2(price)), rec_id),
    )


def delete(rec_id: int) -> None:
    used = db().scalar(
        "SELECT COUNT(*) FROM goods_receipt_items WHERE item_id = ?", (rec_id,), default=0)
    if used:
        raise ValidationError(
            f"Артиклот е употребен во {used} документ(и) и не може да се избрише.\n\n"
            "Означи го како неактивен ако не сакаш повеќе да се нуди."
        )
    database = db()
    with database.tx():
        database.delete(TABLE, rec_id)


def next_code() -> str:
    rows = db().query("SELECT code FROM items WHERE code GLOB '[0-9]*'")
    numbers = []
    for row in rows:
        try:
            numbers.append(int(row["code"]))
        except (TypeError, ValueError):
            continue
    return f"{(max(numbers) + 1) if numbers else 1:04d}"


def margin(row: sqlite3.Row | dict) -> tuple:
    """(разлика во цена без ДДВ, маржа во %) од набавна кон малопродажна."""
    purchase = D(row["purchase_price"])
    retail_net = D(row["price_retail_net"])
    diff = q2(retail_net - purchase)
    percent = q2(diff / purchase * 100) if purchase else D(0)
    return diff, percent
