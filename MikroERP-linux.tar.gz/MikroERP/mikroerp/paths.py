# -*- coding: utf-8 -*-
"""Патеки на апликацијата.

Сè живее ВО папката на апликацијата (portable) — базата, логовите,
резервните копии и config.ini.  Ништо не се пишува во AppData или
во системски папки, за да може целата апликација да се копира/зипува.
"""

from __future__ import annotations

import sys
from pathlib import Path


def app_dir() -> Path:
    """Папката во која се наоѓа апликацијата.

    Кога е спакувана со PyInstaller (onedir) тоа е папката со .exe,
    инаку е коренот на изворниот код.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resolve(path_str: str) -> Path:
    """Релативните патеки од config.ini се однесуваат на папката на апликацијата."""
    text = str(path_str).strip()
    if sys.platform != "win32":
        # config.ini напишан на Windows („data\\mikroerp.db“) мора да работи и
        # на Linux, каде „\“ е обичен знак во името на фајлот.
        text = text.replace("\\", "/")
    p = Path(text)
    if not p.is_absolute():
        p = app_dir() / p
    return p


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


CONFIG_FILE = app_dir() / "config.ini"
DATA_DIR = app_dir() / "data"
LOGS_DIR = app_dir() / "logs"
BACKUPS_DIR = app_dir() / "backups"
