# -*- coding: utf-8 -*-
"""Логирање во logs\\mikroerp.log + глобален фаќач на неочекувани грешки."""

from __future__ import annotations

import logging
import logging.handlers
import sys
import traceback
import types

from . import paths

log = logging.getLogger("mikroerp")


def setup(level: int = logging.INFO) -> None:
    paths.ensure_dir(paths.LOGS_DIR)
    log.setLevel(level)
    log.handlers.clear()

    file_handler = logging.handlers.RotatingFileHandler(
        paths.LOGS_DIR / "mikroerp.log",
        maxBytes=1_000_000,
        backupCount=5,
        encoding="utf-8",
    )
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s  %(levelname)-7s  %(name)s  %(message)s")
    )
    log.addHandler(file_handler)

    # Кога има конзола (развој) — пишувај и таму.
    if sys.stderr is not None:
        stream = logging.StreamHandler(sys.stderr)
        stream.setFormatter(logging.Formatter("%(levelname)-7s %(message)s"))
        log.addHandler(stream)


def install_excepthook() -> None:
    """Неуловена грешка → лог + порака до корисникот, наместо тивко паѓање."""

    def handler(exc_type, exc_value, exc_tb: types.TracebackType | None) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        log.error("НЕОЧЕКУВАНА ГРЕШКА:\n%s", text)
        try:
            from tkinter import messagebox

            messagebox.showerror(
                "Неочекувана грешка",
                "Се случи неочекувана грешка:\n\n"
                f"{exc_type.__name__}: {exc_value}\n\n"
                f"Деталите се запишани во:\n{paths.LOGS_DIR / 'mikroerp.log'}",
            )
        except Exception:  # noqa: BLE001 — ако и GUI-то падне, барем логот е тука
            pass

    sys.excepthook = handler
