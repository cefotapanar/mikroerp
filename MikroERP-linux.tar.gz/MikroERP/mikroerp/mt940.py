# -*- coding: utf-8 -*-
"""Парсер за банкарски изводи во MT940 (SWIFT) формат.

Пренесен од работниот парсер на големиот ЕРП (`app/Support/Mt940Parser.php`),
проверен на вистински НЛБ изводи (`DpsStatement*.txt`).

Една датотека = една или повеќе пораки `{1:…}{2:…}{4: … }`. Тука има само
читање на форматот — никаква логика за поврзување со клиенти или документи.

Тагови:
  :20  референца
  :25  наша сметка
  :28C број на изводот
  :60F/:60M почетна состојба
  :62F/:62M завршна состојба
  :61  ставка (YYMMDD + D/C + износ + Nxxx + сметка на другата страна + //реф)
  :86  /BENM|ORDP/сметка /BNAME/име /PRPD/намена /CODE/шифра
"""

from __future__ import annotations

import re
from decimal import Decimal

from .money import D, q2

TAG_RE = re.compile(r"^:(\d{2}[A-Z]?):(.*)$")
BALANCE_RE = re.compile(r"^([DC])(\d{6})([A-Z]{3})([\d.,]+)")
ENTRY_RE = re.compile(r"^(\d{6})(\d{4})?([DC]|RC|RD)([\d.,]+)N[A-Z]{3}([^/]*)//(.*)$")
ACCT_RE = re.compile(r"/(?:BENM|ORDP)/(\d+)")
NAME_RE = re.compile(r"/BNAME/(.*?)(?=/PRPD/|/CODE/|$)")
PURPOSE_RE = re.compile(r"/PRPD/(.*?)(?=/CODE/|$)")
CODE_RE = re.compile(r"/CODE/(\d+)")
DIGITS_RE = re.compile(r"\D")


class Mt940Error(ValueError):
    pass


def _date6(yymmdd: str) -> str:
    return f"20{yymmdd[0:2]}-{yymmdd[2:4]}-{yymmdd[4:6]}"


def _amount(text: str) -> Decimal:
    """Македонски запис: 7.635,00 → 7635.00"""
    return q2(D(text.replace(".", "").replace(",", ".")))


def parse(raw: str) -> list[dict]:
    """Враќа список изводи со ставки."""
    raw = raw.replace("\r\n", "\n").replace("\r", "\n").strip()
    messages = [m for m in re.split(r"(?=\{1:)", raw) if m.strip()]
    statements = []
    for message in messages:
        statement = _parse_message(message)
        if statement:
            statements.append(statement)
    return statements


def _parse_message(message: str) -> dict | None:
    start = message.find("{4:")
    if start < 0:
        return None
    body = message[start + 3:]
    body = re.sub(r"-?\}\s*$", "", body)

    # Продолжените линии (оние што не почнуваат со :NN:) се лепат на претходниот
    # таг — така се поправа прекршено `/CO\nDE/220`.
    tags: list[tuple[str, str]] = []
    current: list | None = None
    for line in body.split("\n"):
        match = TAG_RE.match(line)
        if match:
            if current:
                tags.append((current[0], current[1]))
            current = [match.group(1), match.group(2)]
        elif current:
            current[1] += line
    if current:
        tags.append((current[0], current[1]))

    statement: dict = {
        "ref": None, "izvod_broj": None, "account": None, "date": None,
        "opening": None, "closing": None, "entries": [],
    }

    for tag, value in tags:
        if tag == "20":
            statement["ref"] = value.strip()
        elif tag == "25":
            statement["account"] = DIGITS_RE.sub("", value)
        elif tag == "28C":
            cleaned = value.strip()
            statement["izvod_broj"] = cleaned.lstrip("0") or cleaned
        elif tag in ("60F", "60M"):
            balance = _parse_balance(value)
            statement["opening"] = balance["amount"]
            statement["date"] = statement["date"] or balance["date"]
        elif tag in ("62F", "62M"):
            statement["closing"] = _parse_balance(value)["amount"]
        elif tag == "61":
            entry = _parse_entry(value)
            if entry:
                statement["entries"].append(entry)
        elif tag == "86":
            if statement["entries"]:
                statement["entries"][-1].update(_parse_info(value))

    return statement if statement["izvod_broj"] else None


def _parse_balance(value: str) -> dict:
    match = BALANCE_RE.match(value.strip())
    if not match:
        return {"dc": None, "date": None, "amount": None}
    return {"dc": match.group(1), "date": _date6(match.group(2)),
            "amount": _amount(match.group(4))}


def _parse_entry(value: str) -> dict | None:
    match = ENTRY_RE.match(value.strip())
    if not match:
        return None
    dc = match.group(3)
    credit = dc in ("C", "RD")
    return {
        "date": _date6(match.group(1)),
        "dc": "C" if credit else "D",
        "amount": _amount(match.group(4)),
        "cp_account": DIGITS_RE.sub("", match.group(5)) or "",
        "bank_ref": match.group(6).strip(),
        "cp_name": "",
        "purpose": "",
        "code": "",
    }


def _parse_info(value: str) -> dict:
    out: dict = {}
    match = ACCT_RE.search(value)
    if match:
        out["cp_account"] = match.group(1)
    match = NAME_RE.search(value)
    if match:
        out["cp_name"] = match.group(1).strip()
    match = PURPOSE_RE.search(value)
    if match:
        out["purpose"] = match.group(1).strip()
    match = CODE_RE.search(value)
    if match:
        out["code"] = match.group(1)
    return out


def balanced(statement: dict) -> bool:
    """Почетна + приливи − одливи = завршна состојба."""
    if statement.get("opening") is None or statement.get("closing") is None:
        return False
    total = D(statement["opening"])
    for entry in statement["entries"]:
        total += entry["amount"] if entry["dc"] == "C" else -entry["amount"]
    return q2(total) == q2(statement["closing"])


def read_file(path) -> list[dict]:
    """Изводите доаѓаат како .txt; кодирањето варира, па се проба по ред."""
    with open(path, "rb") as handle:
        data = handle.read()
    for encoding in ("utf-8-sig", "utf-8", "cp1251", "cp1252", "latin-1"):
        try:
            return parse(data.decode(encoding))
        except UnicodeDecodeError:
            continue
    raise Mt940Error("Датотеката не може да се прочита (непознато кодирање).")
