# -*- coding: utf-8 -*-
"""Пресметки со пари и количини.

Во ERP никогаш не се пресметува со float — сè оди преку Decimal, а во
базата се чува како REAL само за складирање/сортирање.  Секое собирање,
множење и заокружување поминува од тука за да нема „1 денар разлика“.
"""

from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

ZERO = Decimal("0")


def D(value) -> Decimal:
    """Претвора било што (текст од поле, None, int, float) во Decimal."""
    if isinstance(value, Decimal):
        return value
    if value is None:
        return ZERO
    if isinstance(value, float):
        return Decimal(repr(value))
    if isinstance(value, int):
        return Decimal(value)
    text = str(value).strip().replace(" ", "").replace(" ", "")
    if not text:
        return ZERO
    # Прифати и „1.234,56“ и „1234.56“
    if "," in text and "." in text:
        text = text.replace(".", "").replace(",", ".")
    else:
        text = text.replace(",", ".")
    try:
        return Decimal(text)
    except InvalidOperation as exc:
        raise ValueError(f"Невалиден број: {value!r}") from exc


def q(value, places: int = 2) -> Decimal:
    """Заокружување на зададен број децимали (пола нагоре, како во сметководство)."""
    exp = Decimal(1).scaleb(-places)
    return D(value).quantize(exp, rounding=ROUND_HALF_UP)


def q2(value) -> Decimal:
    return q(value, 2)


def fmt(value, places: int = 2, thousands: bool = True) -> str:
    """Форматирање за приказ: 1.234,56 (македонски стил)."""
    dec = q(value, places)
    negative = dec < 0
    text = f"{abs(dec):,.{places}f}"
    # ',' → тисјачник, '.' → децимална запирка
    text = text.replace(",", "\x00").replace(".", ",").replace("\x00", "." if thousands else "")
    return ("-" + text) if negative else text


def fmt_qty(value, places: int = 3) -> str:
    """Количините се прикажуваат без непотребни нули: 2 наместо 2,000."""
    dec = q(value, places).normalize()
    if dec == dec.to_integral_value():
        dec = dec.to_integral_value()
    text = f"{dec:f}".replace(".", ",")
    return text


def vat_amount(base, rate) -> Decimal:
    """ДДВ од основица (rate е процент, пр. 18)."""
    return q2(D(base) * D(rate) / Decimal(100))


def without_vat(gross, rate) -> Decimal:
    """Основица од цена со ДДВ."""
    return q2(D(gross) / (Decimal(1) + D(rate) / Decimal(100)))


def with_vat(net, rate) -> Decimal:
    """Цена со ДДВ од основица."""
    return q2(D(net) * (Decimal(1) + D(rate) / Decimal(100)))
