# -*- coding: utf-8 -*-
"""Запис во Excel (.xlsx) без надворешна библиотека.

Еден .xlsx е ZIP со неколку XML-и. Тука се пишуваат само оние што му се
потребни на Excel за да отвори чист лист: типови, врски, работна книга,
стилови и еден лист. Броевите одат како броеви (за да може да се собираат),
текстот како текст, а заглавието е задебелено и замрзнато.

Зошто вака, а не CSV: кирилицата и децималната запирка во CSV прават проблем
кај локализиран Excel, а овде нема никаква двосмисленост.
"""

from __future__ import annotations

import datetime as _dt
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
</Types>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
</Relationships>"""

WORKBOOK_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

# 0 обичен · 1 заглавие (задебелено, сиво) · 2 број со 2 децимали
# 3 количина со 3 децимали · 4 задебелен ред (збир)
STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="2">
<numFmt numFmtId="164" formatCode="#,##0.00"/>
<numFmt numFmtId="165" formatCode="#,##0.000"/>
</numFmts>
<fonts count="2">
<font><sz val="11"/><name val="Calibri"/></font>
<font><b/><sz val="11"/><name val="Calibri"/></font>
</fonts>
<fills count="3">
<fill><patternFill patternType="none"/></fill>
<fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFE8E8E8"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2">
<border><left/><right/><top/><bottom/><diagonal/></border>
<border><left/><right/><top/><bottom style="thin"><color rgb="FF999999"/></bottom><diagonal/></border>
</borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="5">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="164" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>
</cellXfs>
</styleSheet>"""

STYLE_PLAIN, STYLE_HEAD, STYLE_MONEY, STYLE_QTY, STYLE_TOTAL = 0, 1, 2, 3, 4


def _column_name(index: int) -> str:
    name = ""
    index += 1
    while index:
        index, rest = divmod(index - 1, 26)
        name = chr(65 + rest) + name
    return name


def _cell(row: int, col: int, value, style: int) -> str:
    ref = f"{_column_name(col)}{row}"
    css = f' s="{style}"' if style else ""
    if value is None or value == "":
        return f'<c r="{ref}"{css}/>'
    if isinstance(value, bool):
        value = "да" if value else ""
    if isinstance(value, (int, float)):
        return f'<c r="{ref}"{css}><v>{value}</v></c>'
    text = escape(str(value)).replace("\r", "").replace("\n", "&#10;")
    return f'<c r="{ref}" t="inlineStr"{css}><is><t xml:space="preserve">{text}</t></is></c>'


def write(path, columns: list[dict], rows: list[dict], title: str = "Лист",
          info: list[str] | None = None) -> Path:
    """Прави .xlsx од колони и редови.

    `columns`: [{"key", "text", "kind": ""|"money"|"qty", "width": знаци}]
    `rows`:    [{клуч: вредност}] — броевите нека бидат int/float, не текст.
    `info`:    редови текст над табелата (наслов, филтри, период).
    """
    path = Path(path)
    info = info or []
    body: list[str] = []
    line = 1

    for text in info:
        body.append(f'<row r="{line}">{_cell(line, 0, text, STYLE_HEAD if line == 1 else STYLE_PLAIN)}</row>')
        line += 1
    if info:
        line += 1

    head = "".join(_cell(line, index, col.get("text", col["key"]), STYLE_HEAD)
                   for index, col in enumerate(columns))
    body.append(f'<row r="{line}">{head}</row>')
    header_line = line
    line += 1

    for row in rows:
        cells = []
        for index, col in enumerate(columns):
            value = row.get(col["key"], "")
            kind = col.get("kind", "")
            style = STYLE_PLAIN
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                style = STYLE_QTY if kind == "qty" else (
                    STYLE_MONEY if kind == "money" else STYLE_PLAIN)
            if row.get("_total"):
                style = STYLE_TOTAL if style in (STYLE_MONEY, STYLE_PLAIN) else style
            cells.append(_cell(line, index, value, style))
        body.append(f'<row r="{line}">{"".join(cells)}</row>')
        line += 1

    cols_xml = "".join(
        f'<col min="{i + 1}" max="{i + 1}" width="{max(8, min(60, col.get("width", 16)))}" customWidth="1"/>'
        for i, col in enumerate(columns))
    last = f"{_column_name(max(len(columns) - 1, 0))}{max(line - 1, 1)}"
    sheet = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        f'<dimension ref="A1:{last}"/>'
        '<sheetViews><sheetView workbookViewId="0" tabSelected="1">'
        f'<pane ySplit="{header_line}" topLeftCell="A{header_line + 1}" activePane="bottomLeft" state="frozen"/>'
        "</sheetView></sheetViews>"
        '<sheetFormatPr defaultRowHeight="15"/>'
        f"<cols>{cols_xml}</cols>"
        f'<sheetData>{"".join(body)}</sheetData>'
        f'<autoFilter ref="A{header_line}:{last}"/>'
        "</worksheet>"
    )

    safe_title = "".join(ch for ch in str(title) if ch not in "[]:*?/\\")[:31] or "Лист"
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f'<sheets><sheet name="{escape(safe_title)}" sheetId="1" r:id="rId1"/></sheets>'
        "</workbook>"
    )
    core = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        f"<dc:title>{escape(str(title))}</dc:title><dc:creator>MikroERP</dc:creator>"
        f'<dcterms:created xsi:type="dcterms:W3CDTF">'
        f"{_dt.datetime.now().replace(microsecond=0).isoformat()}Z</dcterms:created>"
        "</cp:coreProperties>"
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", CONTENT_TYPES)
        zf.writestr("_rels/.rels", ROOT_RELS)
        zf.writestr("docProps/core.xml", core)
        zf.writestr("xl/workbook.xml", workbook)
        zf.writestr("xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
        zf.writestr("xl/styles.xml", STYLES)
        zf.writestr("xl/worksheets/sheet1.xml", sheet)
    return path
