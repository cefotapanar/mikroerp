# -*- coding: utf-8 -*-
"""Главен прозорец: лева навигација + површина за екраните + статусна лента.

Изгледот е системски (Windows тема), исто како WSTG600: групи во `LabelFrame`,
обични копчиња на цела ширина, sunken статусна лента долу.
"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import ttk

from ..config import config
from ..db import db
from ..logging_setup import log
from ..repo import settings
from ..version import APP_NAME, VERSION
from . import navigation, theme, widgets
from .views.base import PlaceholderView

NAV_BUTTON_WIDTH = 22


class NavPanel(ttk.Frame):
    """Групи копчиња лево (ФАКТУРИ, МАТЕРИЈАЛНО, ШИФРАРНИК, …)."""

    def __init__(self, master, on_select):
        super().__init__(master, padding=(8, 8, 4, 8))
        self.on_select = on_select
        self.buttons: dict[str, ttk.Button] = {}
        self._build()

    def _build(self) -> None:
        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0, 8))
        ttk.Label(header, text=APP_NAME, style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="верзија " + VERSION, style="Small.TLabel").pack(anchor="w")

        for group_title, entries in navigation.MENU:
            box = ttk.Labelframe(self, text=group_title, padding=(6, 4, 6, 6))
            box.pack(fill="x", pady=(0, 8))
            for key, label in entries:
                button = ttk.Button(box, text=label, width=NAV_BUTTON_WIDTH,
                                    command=lambda k=key: self.on_select(k))
                button.pack(fill="x", pady=1)
                self.buttons[key] = button

    def mark_update(self, available: bool) -> None:
        """Кога има нова верзија, копчето Update се вика поинаку."""
        button = self.buttons.get("update")
        if button is not None:
            button.configure(text="Update  ●" if available else "Update")

    def set_active(self, key: str) -> None:
        """Копчето на тековниот екран е исклучено — така се гледа каде си."""
        for button_key, button in self.buttons.items():
            button.state(["disabled"] if button_key == key else ["!disabled"])


class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        cfg = config()
        self.withdraw()                      # без трепкање додека се гради

        theme.apply(self, cfg.get("izgled", "tema"), cfg.get("izgled", "font"),
                    cfg.get_int("izgled", "golemina_font", 0))

        self.title(APP_NAME + " " + VERSION)
        self.minsize(1060, 640)
        self.geometry(cfg.get("izgled", "prozorec") or "1280x780")
        self._set_icon()
        if cfg.get_bool("izgled", "polnekran", True):
            self._maximize()

        self.views: dict[str, tk.Widget] = {}
        self.view_factories = navigation.build_views()
        self.current_key: str | None = None
        self._status_after: str | None = None

        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self.nav = NavPanel(self, self.show)
        self.nav.grid(row=0, column=0, sticky="ns")

        ttk.Separator(self, orient="vertical").grid(row=0, column=0, sticky="nse")

        self.content = ttk.Frame(self, padding=(6, 8, 8, 0))
        self.content.grid(row=0, column=1, sticky="nsew")
        self.content.columnconfigure(0, weight=1)
        self.content.rowconfigure(0, weight=1)

        self._build_statusbar()
        self.refresh_title()

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.bind("<Control-q>", lambda _e: self.on_close())

        self.show(navigation.DEFAULT_VIEW)
        self.deiconify()
        self.after(2500, self._check_update)

    # ------------------------------------------------------- нова верзија
    def _check_update(self) -> None:
        """Тивка проверка при стартување — ако нема врска, не се јавува.

        Проверката оди во посебна нишка за да не го задржи прозорецот; на
        екранот се пишува само ако навистина има поновa верзија.
        """
        from .. import registracija, updater

        updater.cleanup()          # ѓубрето од претходното ажурирање

        def work() -> None:
            # Проверката на регистрацијата НИКОГАШ не пречи: молчи при секаква
            # грешка и не го задржува отворањето на апликацијата.
            try:
                registracija.proveri()
            except Exception:      # noqa: BLE001
                pass
            if not updater.enabled():
                return
            try:
                release = updater.check()
            except Exception:      # noqa: BLE001 — нема интернет? не пречи никому
                return
            if release is not None and release.newer:
                self.after(0, lambda: self._announce_update(release))

        threading.Thread(target=work, daemon=True).start()

    def _announce_update(self, release) -> None:
        self.set_status(f"Има нова верзија {release.version} — "
                        "ПОДЕСУВАЊА → Update за да се симне.", seconds=30)
        try:
            self.nav.mark_update(True)
        except AttributeError:
            pass

    # ------------------------------------------------------------- изглед
    def _maximize(self) -> None:
        """Стартување на цел екран (Windows: zoomed, Linux: -zoomed)."""
        try:
            self.state("zoomed")
            return
        except tk.TclError:
            pass
        try:
            self.attributes("-zoomed", True)
        except tk.TclError:
            self.geometry(f"{self.winfo_screenwidth()}x{self.winfo_screenheight() - 60}+0+0")

    def _set_icon(self) -> None:
        from ..paths import app_dir

        icon = app_dir() / "assets" / "mikroerp.ico"
        if icon.exists():
            try:
                self.iconbitmap(str(icon))
            except tk.TclError:
                pass

    def _build_statusbar(self) -> None:
        bar = ttk.Frame(self, padding=(8, 4, 8, 6))
        bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        bar.columnconfigure(0, weight=1)

        self.status_label = ttk.Label(bar, text="Спремно", anchor="w",
                                      relief="sunken", padding=(6, 3))
        self.status_label.grid(row=0, column=0, sticky="ew")

        self.info_label = ttk.Label(bar, text="", anchor="e", relief="sunken",
                                    padding=(6, 3), width=46)
        self.info_label.grid(row=0, column=1, sticky="e", padx=(6, 0))

    def refresh_title(self) -> None:
        company = settings.company_name()
        self.title(f"{APP_NAME} {VERSION}  —  {company}")
        try:
            self.info_label.configure(text=f"{company}   •   {db().path.name}")
        except AttributeError:
            pass

    def set_status(self, text: str, seconds: int = 8) -> None:
        self.status_label.configure(text=text)
        if self._status_after:
            try:
                self.after_cancel(self._status_after)
            except tk.TclError:
                pass
        self._status_after = self.after(seconds * 1000,
                                        lambda: self.status_label.configure(text="Спремно"))

    # ------------------------------------------------------------- екрани
    def show(self, key: str) -> None:
        if key == self.current_key:
            self.views[key].on_show()
            return

        view = self.views.get(key)
        if view is None:
            view = self._create_view(key)
            self.views[key] = view

        for other_key, other in self.views.items():
            if other_key != key:
                other.grid_remove()
        view.grid(row=0, column=0, sticky="nsew")
        self.nav.set_active(key)
        self.current_key = key
        try:
            view.on_show()
        except Exception as exc:  # noqa: BLE001
            log.exception("Грешка при отворање на екранот %s", key)
            widgets.error(self, f"Екранот „{navigation.title_for(key)}“ не може да се отвори:\n{exc}")

    def _create_view(self, key: str):
        factory = self.view_factories.get(key)
        if factory is None:
            return PlaceholderView(self.content, self, navigation.title_for(key),
                                   navigation.NOTES.get(key, ""))
        try:
            return factory(self.content, self)
        except Exception as exc:  # noqa: BLE001
            log.exception("Не може да се создаде екранот %s", key)
            return PlaceholderView(self.content, self, navigation.title_for(key),
                                   f"Екранот не може да се вчита: {exc}")

    # ------------------------------------------------------------- затворање
    def on_close(self) -> None:
        cfg = config()
        try:
            if self.state() == "normal":
                cfg.set("izgled", "prozorec", f"{self.winfo_width()}x{self.winfo_height()}")
                cfg.save()
        except tk.TclError:
            pass
        log.info("Затворање на апликацијата")
        self.destroy()
