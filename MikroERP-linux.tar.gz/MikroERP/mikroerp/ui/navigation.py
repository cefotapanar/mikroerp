﻿# -*- coding: utf-8 -*-
"""Структура на менито и регистар на екрани.

Кога се додава нов модул, тука се менуваат само две работи:
  1) ставка во MENU
  2) фабрика во VIEWS
"""

from __future__ import annotations

from typing import Callable

# (наслов на групата, [(клуч, наслов на ставка)])
# Намерно без емоџи-икони: не се исцртуваат исто на секој Windows.
MENU: list[tuple[str, list[tuple[str, str]]]] = [
    ("ФАКТУРИ", [
        ("vlezni_fakturi", "Влезни фактури"),
        ("izlezni_fakturi", "Излезни фактури"),
        ("profakturi", "Профактури"),
        ("izvodi", "Изводи"),
    ]),
    ("МАТЕРИЈАЛНО", [
        ("lager", "Лагер листа"),
        ("priemnici", "Приемници"),
        ("ispratnici", "Испратници"),
        ("raboten_nalog", "Работен налог"),
    ]),
    ("ШИФРАРНИК", [
        ("artikli", "Артикли"),
        ("klienti", "Клиенти"),
        ("brendovi", "Брендови"),
    ]),
    ("ИЗВЕШТАИ", [
        ("kartichki", "Картички"),
        ("trosoci", "Трошоци"),
        ("izvestai", "Извештаи"),
    ]),
    ("ПОДЕСУВАЊА", [
        ("firma", "Фирма"),
        ("magacini", "Магацини"),
        ("sifri", "Шифри на плаќање"),
        ("update", "Update"),
    ]),
]

DEFAULT_VIEW = "artikli"

# Појаснување што ќе содржи модулот кога ќе биде готов.
NOTES: dict[str, str] = {
    "vlezni_fakturi": "Фактури од добавувачи: врзување со приемница, рокови на плаќање и пресметка на влезен ДДВ.",
    "izlezni_fakturi": "Фактури кон купувачи: ставки, рабат, ДДВ, статус на наплата и печатење.",
    "profakturi": "Понуди/профактури со можност за претворање во фактура или испратница.",
    "lager": "Моментална залиха по артикл со набавна вредност, резервации и минимални количини.",
    "priemnici": "Влез на стока во магацин со набавни цени и зависни трошоци.",
    "ispratnici": "Излез на стока од магацин и раздолжување на залихата.",
    "raboten_nalog": "Работни налози: од материјали кон готов производ.",
    "izvestai": "Извештаи по промет, залиха, ДДВ и клиенти.",
}


def build_views() -> dict[str, Callable]:
    """Фабрики за екраните. Клучевите што недостасуваат добиваат „во изработка“."""
    from .views.artikli import ArtikliView
    from .views.brendovi import BrendoviView
    from .views.firma import FirmaView
    from .views.klienti import KlientiView
    from .views.ispratnici import IspratniciView
    from .views.izvodi import IzvodiView
    from .views.lager import LagerView
    from .views.magacini import MagaciniView
    from .views.nabavka import VlezniFakturiView
    from .views.nalozi import NaloziView
    from .views.priemnici import PriemniciView
    from .views.prodazba import IzlezniFakturiView, ProfakturiView
    from .views.kartichki import KartichkiView
    from .views.sifri import SifriView
    from .views.trosoci import TrosociView
    from .views.update import UpdateView

    return {
        "vlezni_fakturi": VlezniFakturiView,
        "izlezni_fakturi": IzlezniFakturiView,
        "profakturi": ProfakturiView,
        "izvodi": IzvodiView,
        "artikli": ArtikliView,
        "klienti": KlientiView,
        "brendovi": BrendoviView,
        "lager": LagerView,
        "priemnici": PriemniciView,
        "ispratnici": IspratniciView,
        "raboten_nalog": NaloziView,
        "trosoci": TrosociView,
        "kartichki": KartichkiView,
        "sifri": SifriView,
        "firma": FirmaView,
        "magacini": MagaciniView,
        "update": UpdateView,
    }


def title_for(key: str) -> str:
    for _group, entries in MENU:
        for item_key, label in entries:
            if item_key == key:
                return label
    return key
