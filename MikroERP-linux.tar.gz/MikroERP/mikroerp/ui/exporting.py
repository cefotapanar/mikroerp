# -*- coding: utf-8 -*-
"""Печати / PDF / Viber / Excel — заедничките дејства за екраните.

Тука е сето „каде да се сними“, „да се отвори ли сега“ и справувањето со
грешки, за да не се повторува во секој екран.
"""

from __future__ import annotations

import os
import subprocess
import sys
from datetime import date as _date
from pathlib import Path
from tkinter import filedialog

from .. import docprint, paper, xlsx
from . import preview, widgets


def _safe(name: str) -> str:
    keep = "".join(ch if ch.isalnum() or ch in "-_. " else "-" for ch in str(name))
    return keep.strip(" -.") or "dokument"


def open_file(path: Path) -> None:
    """Го отвора создадениот фајл со стандардната програма."""
    try:
        if sys.platform == "win32":
            os.startfile(path)  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except OSError:
        pass


def ask_path(parent, default_name: str, suffix: str, title: str) -> Path | None:
    path = filedialog.asksaveasfilename(
        parent=parent, title=title, defaultextension=suffix,
        initialfile=_safe(default_name) + suffix,
        filetypes=[("PDF документ", "*.pdf")] if suffix == ".pdf"
        else [("Excel табела", "*.xlsx")],
    )
    return Path(path) if path else None


# ---------------------------------------------------------------- документи
def _app_of(parent):
    return getattr(parent, "app", parent)


def print_document(parent, kind: str, rec_id: int) -> None:
    """Го отвора прегледот на документот — печатењето е оттаму."""
    try:
        doc = docprint.build(kind, rec_id)
    except Exception as exc:  # noqa: BLE001
        widgets.error(parent, f"Документот не може да се подготви:\n{exc}")
        return
    preview.show(parent, _app_of(parent), doc)


def pdf_document(parent, kind: str, rec_id: int) -> None:
    try:
        doc = docprint.build(kind, rec_id)
        html = paper.document_html(doc)
    except Exception as exc:  # noqa: BLE001
        widgets.error(parent, f"Документот не може да се подготви:\n{exc}")
        return
    target = ask_path(parent, doc.file_name, ".pdf", "Зачувај PDF")
    if target is None:
        return
    try:
        paper.save_pdf(html, target, doc.file_name)
    except paper.PdfError as exc:
        widgets.error(parent, f"{exc}\n\nДокументот сепак може да се испечати "
                              "преку копчето „Печати“.", title="PDF")
        return
    open_file(target)


# ------------------------------------------------------------------- листи
def _cell_value(row: dict, key: str):
    """Бројот оди како број во Excel; текстот како текст."""
    raw = row.get(key + "_raw")
    if isinstance(raw, (int, float)) and not isinstance(raw, bool):
        return float(raw)
    if raw is not None and isinstance(raw, str) and raw.strip():
        text = row.get(key, "")
        return text if text != "" else raw
    return row.get(key, "")


def _kind_of(row_values: list, key: str, rows: list[dict]) -> str:
    """Пари или количина — по бројот на децимали во она што се гледа."""
    for row in rows:
        shown = str(row.get(key, ""))
        if "," in shown:
            decimals = len(shown.split(",")[-1])
            return "qty" if decimals >= 3 else "money"
    return ""


def export_rows(parent, columns, rows: list[dict], title: str,
                info: list[str] | None = None) -> None:
    """Ги снима редовите какви што се на екранот во .xlsx."""
    if not rows:
        widgets.info(parent, "Нема редови за извоз.")
        return
    spec = []
    for col in columns:
        key = col["key"]
        spec.append({
            "key": key,
            "text": col.get("text", key),
            "kind": col.get("excel") or _kind_of([], key, rows),
            "width": max(10, int(col.get("width", 110)) // 7),
        })
    data = []
    for row in rows:
        item = {col["key"]: _cell_value(row, col["key"]) for col in spec}
        item["_total"] = bool(row.get("_total"))
        data.append(item)

    default = f"{title}-{_date.today().isoformat()}"
    target = ask_path(parent, default, ".xlsx", "Извези во Excel")
    if target is None:
        return
    header = [title] + list(info or [])
    try:
        xlsx.write(target, spec, data, title=title, info=header)
    except OSError as exc:
        widgets.error(parent, f"Табелата не може да се сними:\n{exc}\n\n"
                              "Ако е отворена во Excel, затвори ја и пробај пак.")
        return
    open_file(target)


def print_rows(parent, columns, rows: list[dict], title: str,
               info: list[str] | None = None, totals: list[tuple] | None = None) -> None:
    """Ја покажува листата во преглед, онака како што ќе се испечати."""
    if not rows:
        widgets.info(parent, "Нема редови за печатење.")
        return
    doc = docprint.list_doc(title, columns, rows, info, totals)
    doc.doc_no = _date.today().strftime("%d.%m.%Y")
    preview.show(parent, _app_of(parent), doc)
