# -*- coding: utf-8 -*-
"""Изглед на апликацијата.

Намерно се користи **стандардната Windows тема** на ttk (vista), исто како во
WSTG600: обични системски копчиња, обични полиња, sunken статусна лента.
Тука не се пребојува ништо од виџетите — се дефинираат само:
  * неколку помошни стилови за етикети (сиво/задебелено), што не го менуваат
    native изгледот на копчињата и полињата,
  * бои за означување редови во табелите.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

# Бои што се користат САМО за текст и за означени редови во табела.
C = {
    "fg": "#000000",
    "muted": "#606060",
    "accent": "#00468C",     # темносино, како „Type:“ во WSTG600
    "danger": "#B00020",
    "ok": "#0A6B0A",
    "warn": "#8A5A00",
    "row_alt": "#F5F7FA",    # блага пруга во табелите
    "row_sel": "#D2E2F8",
    "mark": "#FFDC96",       # жолто — променето / внимание
    "light": "#FFF2B0",
    "required": "#FFE9E9",   # најбледо црвено — задолжително празно поле
    "required_edge": "#E0AEAE",
    # бледи позадини за состојба во листите — да се препознае, а да не дречи
    "pale_ok": "#E8F5E9",
    "pale_warn": "#FFF6DF",
    "pale_bad": "#FDECEC",
}

# Стил за празно задолжително поле. Windows темата (vista) не дозволува да се
# обои полето — затоа елементот се позајмува од темата „clam“, само за овој
# стил. Останатите полиња си остануваат системски.
REQUIRED_STYLE = "Req.TEntry"
_required_ready = False

FONTS: dict[str, tkfont.Font] = {}


def _pick_theme(style: ttk.Style, wanted: str) -> None:
    names = set(style.theme_names())
    wanted = (wanted or "").strip().lower()
    order = []
    if wanted in names:
        order.append(wanted)
    order += ["vista", "winnative", "xpnative", "clam", "default"]
    for name in order:
        if name in names:
            style.theme_use(name)
            return


def apply(root: tk.Misc, tema: str = "windows", family: str = "", size: int = 0) -> ttk.Style:
    """`family`/`size` се применуваат само ако се зададени во config.ini;
    празно/0 значи „системски“ (како во WSTG600)."""
    style = ttk.Style(root)
    _pick_theme(style, tema)

    base = tkfont.nametofont("TkDefaultFont")
    if family and family in set(tkfont.families(root)):
        base.configure(family=family)
    if size:
        for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont", "TkHeadingFont"):
            try:
                tkfont.nametofont(name).configure(size=size)
            except tk.TclError:
                pass

    spec = base.actual()
    FONTS["base"] = base
    FONTS["bold"] = tkfont.Font(family=spec["family"], size=spec["size"], weight="bold")
    FONTS["small"] = tkfont.Font(family=spec["family"], size=max(spec["size"] - 1, 7))
    FONTS["title"] = tkfont.Font(family=spec["family"], size=spec["size"] + 3, weight="bold")

    # Само етикети — копчињата и полињата остануваат системски.
    style.configure("Muted.TLabel", foreground=C["muted"])
    style.configure("Small.TLabel", foreground=C["muted"], font=FONTS["small"])
    style.configure("Head.TLabel", font=FONTS["bold"])
    style.configure("Title.TLabel", font=FONTS["title"])
    style.configure("Path.TLabel", foreground=C["accent"], font=FONTS["bold"])
    style.configure("Error.TLabel", foreground=C["danger"])
    style.configure("Ok.TLabel", foreground=C["ok"])

    # Табелите: малку повисоки редови и задебелени заглавија.
    style.configure("Treeview", rowheight=base.metrics("linespace") + 8)
    style.configure("Treeview.Heading", font=FONTS["bold"])

    _make_required_style(style)
    return style


def _make_required_style(style: ttk.Style) -> None:
    """Го подготвува стилот за празно задолжително поле."""
    global _required_ready
    if not _required_ready:
        try:
            style.element_create("Required.field", "from", "clam", "Entry.field")
            _required_ready = True
        except tk.TclError:
            # темата „clam“ ја нема или елементот веќе е создаден
            _required_ready = "Required.field" in style.element_names()
    if not _required_ready:
        return
    style.layout(REQUIRED_STYLE, [
        ("Required.field", {"sticky": "nswe", "border": "1", "children": [
            ("Entry.padding", {"sticky": "nswe", "children": [
                ("Entry.textarea", {"sticky": "nswe"}),
            ]}),
        ]}),
    ])
    style.configure(REQUIRED_STYLE, fieldbackground=C["required"],
                    bordercolor=C["required_edge"], foreground=C["fg"],
                    insertcolor=C["fg"], padding=3)
