# -*- coding: utf-8 -*-
"""ШИФРАРНИК → Артикли."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, fmt_qty
from ...repo import brands, items
from ..widgets import Field, FormDialog, FormPanel
from .base import CrudView


def item_form_fields(brand_options) -> list[Field]:
    """Полињата на артиклот — се користат и од другите екрани („Креирај артикл“)."""

    def apply_pair(panel: FormPanel, key_net: str, key_gross: str, gross) -> None:
        """Цената со ДДВ е водечка и оди на цел денар; без ДДВ се изведува."""
        rate = D(panel.get_values().get("tax_rate") or 0)
        gross = items.round_gross(gross)
        panel.set_values({key_gross: gross, key_net: items.net_from_gross(gross, rate)})

    def recalc(panel: FormPanel, _value=None) -> None:
        """Смената на ДДВ стапката ги преcметува двата пара одново."""
        data = panel.get_values()
        apply_pair(panel, "price_retail_net", "price_retail", D(data.get("price_retail") or 0))
        apply_pair(panel, "price_partner", "price_partner_gross",
                   D(panel.get_values().get("price_partner_gross") or 0))

    def from_net(key_net: str, key_gross: str):
        def handler(panel: FormPanel, _value=None) -> None:
            rate = D(panel.get_values().get("tax_rate") or 0)
            net = D(panel.get_values().get(key_net) or 0)
            apply_pair(panel, key_net, key_gross, items.gross_from_net(net, rate))
        return handler

    def from_gross(key_net: str, key_gross: str):
        def handler(panel: FormPanel, _value=None) -> None:
            apply_pair(panel, key_net, key_gross,
                       D(panel.get_values().get(key_gross) or 0))
        return handler

    return [
        Field("code", "Шифра", col=2, required=True, chars=9),
        Field("name", "Назив", col=7, required=True),
        Field("barcode", "Баркод", col=3, chars=16),

        Field("brand_id", "Бренд", kind="picker", col=4, values=brand_options, chars=22),
        Field("unit", "ЕМ", kind="combo_edit", col=2, values=items.UNITS, chars=7),
        Field("tax_rate", "ДДВ %", kind="combo_edit", col=2, values=items.TAX_RATES,
              chars=5, on_change=recalc),
        Field("min_stock", "Мин. залиха", kind="dec", col=2, chars=8),

        Field("heading_prices", "Продажни цени", kind="heading"),
        Field("price_retail_net", "МПЦ без ДДВ", kind="money", col=3, chars=12,
              on_change=from_net("price_retail_net", "price_retail")),
        Field("price_retail", "МПЦ со ДДВ", kind="money", col=3, chars=12,
              on_change=from_gross("price_retail_net", "price_retail")),

        Field("price_partner", "Партнерска без ДДВ", kind="money", col=3, chars=12,
              on_change=from_net("price_partner", "price_partner_gross")),
        Field("price_partner_gross", "Партнерска со ДДВ", kind="money", col=3, chars=12,
              on_change=from_gross("price_partner", "price_partner_gross")),

        Field("sep", "", kind="sep"),
        Field("kind", "Вид", kind="combo", col=3, values=items.KINDS, chars=12,
              help="производ = се изработува со работен налог"),
        Field("allow_negative", "Смее да оди во минус", kind="check", col=5),
        Field("active", "Активен", kind="check", col=3),

        Field("note", "Забелешка", kind="memo", col=12, height=3),
    ]


def item_values(record=None) -> dict:
    if record is None:
        return {
            "code": items.next_code(), "unit": "ком", "tax_rate": "18",
            "active": True, "kind": items.KIND_GOODS, "allow_negative": False,
            "price_retail_net": "0", "price_retail": "0",
            "price_partner": "0", "price_partner_gross": "0", "min_stock": "0",
        }
    values = dict(record)
    values["kind"] = items.kind_of(record)
    values["brand_id"] = str(record["brand_id"] or "")
    return values


def save_item(rec_id: int | None, data: dict) -> int:
    if rec_id:
        items.update(rec_id, data)
        return rec_id
    return items.create(data)


def new_item_dialog(master, kind: str = "") -> int | None:
    """„Креирај артикл“ од друг екран. Враќа id на новиот артикл."""
    options = [("", "— без бренд —")] + [(str(i), n) for i, n in brands.options(only_active=False)]
    holder: dict = {}
    values = item_values()
    if kind:
        values["kind"] = kind

    def save(data: dict):
        holder["id"] = save_item(None, data)
        return holder["id"]

    title = "Нов производ" if kind == items.KIND_PRODUCT else "Нов артикл"
    FormDialog(master, title, item_form_fields(options), values,
               on_save=save, width=760).show()
    return holder.get("id")


class ArtikliView(CrudView):
    title = "Артикли"
    subtitle = "пребарува по шифра, назив, баркод и бренд"
    empty_text = "Нема внесени артикли."
    search_placeholder = "Барај:"

    columns = (
        {"key": "code", "text": "Шифра", "width": 75},
        {"key": "name", "text": "Назив", "width": 235, "stretch": True},
        {"key": "brand_name", "text": "Бренд", "width": 105},
        {"key": "kind", "text": "Вид", "width": 70},
        {"key": "unit", "text": "ЕМ", "width": 45, "anchor": "center"},
        {"key": "tax_rate", "text": "ДДВ %", "width": 55, "anchor": "e", "sort": "num"},
        {"key": "purchase_price", "text": "Набавна", "width": 85, "anchor": "e", "sort": "num"},
        {"key": "price_retail_net", "text": "МПЦ без ДДВ", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "price_retail", "text": "МПЦ со ДДВ", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "price_partner", "text": "Партнерска", "width": 90, "anchor": "e", "sort": "num"},
        {"key": "margin", "text": "Маржа %", "width": 70, "anchor": "e", "sort": "num"},
        {"key": "active", "text": "Активен", "width": 65, "anchor": "center"},
    )

    def build_filters(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Бренд:", style="Muted.TLabel").pack(side="left", padx=(0, 4))
        self.brand_var = tk.StringVar(value="Сите брендови")
        self.brand_combo = ttk.Combobox(parent, textvariable=self.brand_var, state="readonly",
                                        width=18)
        self.brand_combo.pack(side="left")
        self.brand_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self._brand_map: dict[str, int | None] = {}

    def _reload_brand_filter(self) -> None:
        pairs = brands.options(only_active=False)
        self._brand_map = {"Сите брендови": None}
        self._brand_map.update({name: bid for bid, name in pairs})
        current = self.brand_var.get()
        self.brand_combo.configure(values=list(self._brand_map.keys()))
        if current not in self._brand_map:
            self.brand_var.set("Сите брендови")

    def on_show(self) -> None:
        self._reload_brand_filter()
        super().on_show()

    def fetch(self, search: str) -> list[dict]:
        brand_id = self._brand_map.get(self.brand_var.get()) if hasattr(self, "brand_var") else None
        rows = []
        for row in items.list_all(search, brand_id=brand_id):
            _diff, percent = items.margin(row)
            service = items.is_service(row)
            rows.append({
                "id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "brand_name": row["brand_name"],
                "kind": items.kind_label(row),
                "unit": row["unit"],
                "tax_rate": fmt(row["tax_rate"], 0), "tax_rate_raw": row["tax_rate"],
                "purchase_price": "—" if service else fmt(row["purchase_price"]),
                "purchase_price_raw": row["purchase_price"],
                "price_retail_net": fmt(row["price_retail_net"]),
                "price_retail_net_raw": row["price_retail_net"],
                "price_retail": fmt(row["price_retail"]),
                "price_retail_raw": row["price_retail"],
                "price_partner": fmt(row["price_partner"]),
                "price_partner_raw": row["price_partner"],
                "margin": "—" if service else fmt(percent, 1),
                "margin_raw": float(percent),
                "min_stock": fmt_qty(row["min_stock"]),
                "active": "Да" if row["active"] else "Не",
                "_tags": () if row["active"] else ("neaktiven",),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['code']} — {row['name']}"

    def delete_record(self, rec_id: int) -> None:
        items.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        record = items.get(rec_id) if rec_id else None
        options = [("", "— без бренд —")] + [
            (str(bid), name) for bid, name in brands.options(only_active=False)
        ]

        def save(data: dict):
            new_id = save_item(rec_id, data)
            self.status(f"Зачуван артикл: {data['code']} — {data['name']}")
            return new_id

        title = "Нов артикл" if not rec_id else f"Артикл — {record['code']}"
        dialog = FormDialog(self, title, item_form_fields(options), item_values(record),
                            on_save=save, width=780)
        return dialog.show() is not None
