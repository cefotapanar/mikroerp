﻿# -*- coding: utf-8 -*-
"""ФАКТУРИ → Изводи (банкарски изводи).

Изводот се внесува рачно или се увезува од **MT940** датотека (НЛБ
`DpsStatement*.txt`). При увозот секоја ставка се обидува сама да го погоди
клиентот по сметка или по име; она што ќе се избере рачно се памети за
следниот пат.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, ttk

from ... import mt940
from ...money import D, fmt, q2
from ...repo import (bank_accounts, expenses, partners, paycodes, payments,
                     statements)
from ...util import fmt_date, parse_date, today
from .. import theme, widgets
from ..widgets import DataTable, SearchPicker, Toolbar
from .base import CrudView
from .izvod_link import LinkWindow
from .klienti import new_partner_dialog

ALL_ACCOUNTS = "сите сметки"

LINE_COLUMNS = (
    {"key": "line_no", "text": "Р.бр", "width": 38, "anchor": "e"},
    {"key": "date", "text": "Датум", "width": 76},
    {"key": "direction", "text": "Насока", "width": 58},
    {"key": "amount", "text": "Износ", "width": 81, "anchor": "e", "sort": "num"},
    {"key": "cp_account", "text": "Сметка", "width": 118},
    {"key": "cp_name", "text": "Назив во извод", "width": 150},
    {"key": "partner_name", "text": "Клиент", "width": 150},
    {"key": "purpose", "text": "Намена", "width": 75},
    {"key": "code", "text": "Шифра", "width": 52, "anchor": "center"},
    {"key": "closed", "text": "Затворено со", "width": 145, "stretch": True},
)

PREVIEW_COLUMNS = (
    {"key": "doc_no", "text": "Извод", "width": 70, "anchor": "e"},
    {"key": "date", "text": "Датум", "width": 85},
    {"key": "account", "text": "Сметка", "width": 130},
    {"key": "lines", "text": "Ставки", "width": 60, "anchor": "e", "sort": "num"},
    {"key": "total_in", "text": "Приливи", "width": 105, "anchor": "e", "sort": "num"},
    {"key": "total_out", "text": "Одливи", "width": 105, "anchor": "e", "sort": "num"},
    {"key": "closing", "text": "Завршна", "width": 105, "anchor": "e", "sort": "num"},
    {"key": "balanced", "text": "Салдо", "width": 65, "anchor": "center"},
    {"key": "matched", "text": "Клиенти", "width": 70, "anchor": "e", "sort": "num"},
    {"key": "duplicate", "text": "Дупликат", "width": 80},
)


class IzvodWindow(tk.Toplevel):
    """Внес и измена на еден извод."""

    def __init__(self, master, app, doc_id: int | None = None,
                 prepared: dict | None = None, account: str = ""):
        super().__init__(master)
        self.app = app
        self.doc_id = doc_id
        self.account = account
        self.saved = False
        self.editing: int | None = None

        if prepared is not None:
            self.header_data = dict(prepared["header"])
            self.lines_data = [dict(line) for line in prepared["lines"]]
        else:
            self.header_data, self.lines_data = self._load()
        self._start = self._snapshot()

        self.title("Извод " + (self.header_data["doc_no"] or "(нов)"))
        self.transient(master.winfo_toplevel())
        self.geometry("1420x800")
        self.minsize(1300, 640)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        self._build_header()
        self._build_lines()
        self._build_footer()

        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.bind("<Escape>", lambda _e: self.cancel())
        self.refresh_lines()
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()

    # ------------------------------------------------------------- податоци
    def _load(self):
        if self.doc_id is None:
            # Новиот извод не почнува празен: сметка и банка од последниот,
            # следниот број по ред, а почетна состојба = неговата завршна.
            return statements.propose_new(today(), getattr(self, "account", "")), []
        record = statements.get(self.doc_id)
        if record is None:
            raise ValueError("Изводот не постои.")
        header = {
            "id": record["id"], "account": record["account"],
            "bank_name": record["bank_name"], "doc_no": record["doc_no"],
            "year": record["year"], "date": record["date"],
            "opening": q2(record["opening"]), "closing": q2(record["closing"]),
            "ref": record["ref"], "source": record["source"],
            "file_name": record["file_name"], "note": record["note"],
        }
        rows = []
        for line in statements.lines(self.doc_id):
            data = {
                "date": line["date"], "direction": line["direction"],
                "amount": q2(line["amount"]), "cp_account": line["cp_account"],
                "cp_name": line["cp_name"], "purpose": line["purpose"],
                "code": line["code"], "bank_ref": line["bank_ref"],
                "partner_id": line["partner_id"], "matched_by": line["matched_by"],
                "note": line["note"], "expense_id": line["expense_id"],
            }
            if line["expense_id"]:
                expense = expenses.get(int(line["expense_id"]))
                if expense is not None:
                    data["expense"] = {
                        "category": expense["category"],
                        "description": expense["description"],
                        "vat_rate": expense["vat_rate"],
                    }
            data["targets"] = [
                {"kind": row["target_kind"], "id": int(row["target_id"]),
                 "amount": q2(row["amount"])}
                for row in payments.for_line(int(line["id"]))
                if not (row["target_kind"] == payments.KIND_EXPENSE
                        and line["expense_id"]
                        and int(row["target_id"]) == int(line["expense_id"]))
            ]
            rows.append(data)
        return header, rows

    def _snapshot(self) -> str:
        return repr((sorted((k, str(v)) for k, v in self.header_data.items()),
                     [sorted((k, str(v)) for k, v in l.items()) for l in self.lines_data]))

    def _is_dirty(self) -> bool:
        self._pull_header()
        return self._snapshot() != self._start

    # -------------------------------------------------------------- заглавие
    def _build_header(self) -> None:
        box = ttk.Labelframe(self, text="Заглавие", padding=(10, 6, 10, 8))
        box.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 4))

        row1 = ttk.Frame(box)
        row1.pack(fill="x")
        ttk.Label(row1, text="Извод бр.:").pack(side="left")
        self.no_var = tk.StringVar(value=self.header_data["doc_no"])
        no_entry = ttk.Entry(row1, textvariable=self.no_var, width=8)
        no_entry.pack(side="left", padx=(4, 14))
        widgets.require(no_entry, self.no_var)
        no_entry.bind("<FocusOut>", lambda _e: self._check_duplicate(), add="+")

        ttk.Label(row1, text="Датум:").pack(side="left")
        self.date_var = tk.StringVar(value=fmt_date(self.header_data["date"]))
        date_entry = ttk.Entry(row1, textvariable=self.date_var, width=11)
        date_entry.pack(side="left", padx=(4, 14))
        widgets.require(date_entry, self.date_var)

        ttk.Label(row1, text="Сметка:").pack(side="left")
        self.account_var = tk.StringVar(value=self.header_data["account"])
        ttk.Entry(row1, textvariable=self.account_var, width=17).pack(side="left", padx=(4, 14))

        ttk.Label(row1, text="Банка:").pack(side="left")
        self.bank_var = tk.StringVar(value=self.header_data["bank_name"])
        ttk.Entry(row1, textvariable=self.bank_var, width=18).pack(side="left", padx=(4, 14))

        source = self.header_data.get("source") or statements.SOURCE_MANUAL
        text = source + (f" · {self.header_data['file_name']}"
                         if self.header_data.get("file_name") else "")
        ttk.Label(row1, text=text, style="Muted.TLabel").pack(side="left")

        row2 = ttk.Frame(box)
        row2.pack(fill="x", pady=(8, 0))
        ttk.Label(row2, text="Почетна состојба:").pack(side="left")
        self.opening_var = tk.StringVar(value=fmt(self.header_data["opening"]))
        opening = ttk.Entry(row2, textvariable=self.opening_var, width=13, justify="right")
        opening.pack(side="left", padx=(4, 14))
        opening.bind("<FocusOut>", lambda _e: self.refresh_lines())

        ttk.Label(row2, text="Завршна состојба:").pack(side="left")
        self.closing_var = tk.StringVar(value=fmt(self.header_data["closing"]))
        closing = ttk.Entry(row2, textvariable=self.closing_var, width=13, justify="right")
        closing.pack(side="left", padx=(4, 14))
        closing.bind("<FocusOut>", lambda _e: self.refresh_lines())

        ttk.Label(row2, text="Забелешка:").pack(side="left")
        self.note_var = tk.StringVar(value=self.header_data["note"])
        ttk.Entry(row2, textvariable=self.note_var, width=40).pack(side="left", padx=(4, 0))

    def _check_duplicate(self) -> bool:
        """Два изводи со ист број на иста сметка не смеат да постојат."""
        self._pull_header()
        number = str(self.header_data["doc_no"]).strip()
        if not number:
            return False
        existing = statements.find(self.header_data["account"],
                                   self.header_data["year"], number)
        if existing is None or (self.doc_id and int(existing["id"]) == int(self.doc_id)):
            return False
        widgets.error(
            self,
            f"Извод бр. {number} за {self.header_data['year']} на сметка "
            f"{self.header_data['account'] or '—'} веќе постои "
            f"(внесен на {fmt_date(existing['date'])}).\n\n"
            "Промени го бројот или отвори го постоечкиот извод.",
            title="Бројот е зафатен",
        )
        return True

    def _pull_header(self) -> None:
        self.header_data["doc_no"] = self.no_var.get().strip()
        try:
            self.header_data["date"] = parse_date(self.date_var.get())
        except ValueError:
            self.header_data["date"] = self.date_var.get()
        self.header_data["year"] = int(str(self.header_data["date"])[:4] or today()[:4])
        self.header_data["account"] = self.account_var.get().strip()
        self.header_data["bank_name"] = self.bank_var.get().strip()
        for key, var in (("opening", self.opening_var), ("closing", self.closing_var)):
            try:
                self.header_data[key] = q2(D(var.get() or 0))
            except ValueError:
                self.header_data[key] = D(0)
        self.header_data["note"] = self.note_var.get().strip()

    # ---------------------------------------------------------------- ставки
    def _build_lines(self) -> None:
        box = ttk.Labelframe(self, text="Ставки", padding=(10, 6, 10, 8))
        box.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)
        box.columnconfigure(0, weight=1)
        box.rowconfigure(3, weight=1)

        # Ставката се внесува во ЕДЕН ред; под него се опциите за трошок.
        row = ttk.Frame(box)
        row.grid(row=0, column=0, sticky="ew", pady=(0, 4))

        ttk.Label(row, text="Датум:").pack(side="left")
        self.l_date = tk.StringVar(value=fmt_date(self.header_data["date"]))
        ttk.Entry(row, textvariable=self.l_date, width=10).pack(side="left", padx=(4, 10))

        ttk.Label(row, text="Насока:").pack(side="left")
        self.l_dir = tk.StringVar(value=statements.IN)
        ttk.Combobox(row, textvariable=self.l_dir, state="readonly", width=8,
                     values=[statements.IN, statements.OUT]).pack(side="left", padx=(4, 10))

        ttk.Label(row, text="Износ:").pack(side="left")
        self.l_amount = tk.StringVar(value="0")
        amount_entry = ttk.Entry(row, textvariable=self.l_amount, width=11, justify="right")
        amount_entry.pack(side="left", padx=(4, 10))
        widgets.require(amount_entry, self.l_amount,
                        getter=lambda: self.l_amount.get()
                        if D(self.l_amount.get() or 0) > 0 else "")

        ttk.Label(row, text="Шифра:").pack(side="left")
        self.l_code = tk.StringVar(value="")
        code_entry = ttk.Entry(row, textvariable=self.l_code, width=5, justify="right")
        code_entry.pack(side="left", padx=(4, 10))
        code_entry.bind("<FocusOut>", lambda _e: self._show_code())

        ttk.Label(row, text="Сметка:").pack(side="left")
        self.l_account = tk.StringVar(value="")
        ttk.Entry(row, textvariable=self.l_account, width=16).pack(side="left", padx=(4, 10))

        ttk.Label(row, text="Намена:").pack(side="left")
        self.l_purpose = tk.StringVar(value="")
        ttk.Entry(row, textvariable=self.l_purpose, width=22).pack(side="left", padx=(4, 10))

        ttk.Label(row, text="Клиент:").pack(side="left")
        self.l_partner = SearchPicker(row, self._partner_options(), width=22)
        self.l_partner.pack(side="left", padx=(4, 4))
        ttk.Button(row, text="Нов клиент", width=12,
                   command=self.create_partner).pack(side="left", padx=(0, 8))
        self.btn_line = ttk.Button(row, text="Додај", width=9, command=self.commit_line)
        self.btn_line.pack(side="left")

        # „Назив во извод“ го пишува банката — се внесува само со увоз, па тука
        # само се гледа кога се уредува увезена ставка.
        self.l_name = tk.StringVar(value="")

        opts = ttk.Frame(box)
        opts.grid(row=1, column=0, sticky="ew", pady=(0, 4))
        self.l_is_expense = tk.BooleanVar(value=False)
        ttk.Checkbutton(opts, text="Трошок", variable=self.l_is_expense,
                        command=self._toggle_expense_row).pack(side="left", padx=(0, 8))
        self.expense_box = ttk.Frame(opts)
        ttk.Label(self.expense_box, text="Категорија:").pack(side="left")
        self.l_category = tk.StringVar(value=expenses.DEFAULT_BANK_CATEGORY)
        ttk.Combobox(self.expense_box, textvariable=self.l_category, width=22,
                     values=expenses.categories()).pack(side="left", padx=(4, 10))
        ttk.Label(self.expense_box, text="ДДВ %:").pack(side="left")
        self.l_vat = tk.StringVar(value="0")
        ttk.Combobox(self.expense_box, textvariable=self.l_vat, state="readonly", width=4,
                     values=expenses.VAT_RATES).pack(side="left", padx=(4, 10))
        self.code_label = ttk.Label(opts, text="", style="Muted.TLabel")
        self.code_label.pack(side="left", padx=(8, 12))
        self.name_label = ttk.Label(opts, text="", style="Muted.TLabel")
        self.name_label.pack(side="left")

        ttk.Label(box, text="Enter во износот ја додава ставката. "
                            "Delete ја брише избраната.",
                  style="Small.TLabel").grid(row=2, column=0, sticky="w", pady=(0, 4))
        amount_entry.bind("<Return>", lambda _e: self.commit_line())

        self.lines = DataTable(box, LINE_COLUMNS, on_activate=lambda _i: self.link_line(),
                               on_select=lambda _i: self._update_line_buttons(), height=12)
        self.lines.grid(row=3, column=0, sticky="nsew")
        self.lines.tree.bind("<Delete>", lambda _e: self.delete_line())
        self.lines.tree.bind("<ButtonRelease-1>", self._maybe_balloon, add="+")

        tools = Toolbar(box)
        tools.grid(row=4, column=0, sticky="w", pady=(6, 0))
        self.btn_link = tools.button("Поврзи / трошок", self.link_line, width=17)
        self.btn_edit = tools.button("Измени ставка", self.edit_line, width=15)
        self.btn_del = tools.button("Избриши ставка", self.delete_line, width=15)
        self.btn_match = tools.button("Погоди клиенти", self.rematch, width=16)

    def _maybe_balloon(self, event) -> None:
        """Клик врз тесната колона „Намена“ го покажува целиот текст во балон."""
        keys = [c["key"] for c in LINE_COLUMNS]
        column = self.lines.tree.identify_column(event.x)
        try:
            index = int(column.replace("#", "")) - 1
        except ValueError:
            return
        if index < 0 or index >= len(keys) or keys[index] != "purpose":
            return
        row = self.lines.selected_row()
        if row is None:
            return
        line = self.lines_data[int(row["id"])]
        widgets.balloon(self, line.get("purpose") or "(нема намена)",
                        event.x_root, event.y_root)

    def link_line(self) -> None:
        """Отвора поврзување со фактури или означување како трошок."""
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = dict(self.lines_data[index])
        window = LinkWindow(self, self.app, line)
        if window.show():
            self.lines_data[index] = line
            self.refresh_lines()

    def _partner_options(self):
        return [(str(r["id"]), r["name"], f"{r['code']} {r['city']} {r['bank_account']}")
                for r in partners.list_all(only_active=True)]

    def create_partner(self) -> None:
        new_id = new_partner_dialog(self)
        if new_id:
            self.l_partner.set_options(self._partner_options())
            self.l_partner.set(str(new_id))

    def _show_code(self) -> None:
        code = self.l_code.get().strip()
        self.code_label.configure(text=paycodes.label(code))
        # Шифра што по правило е трошок сама го штиклира трошокот — исто како
        # при увоз. Штиклирањето може да се тргне рачно.
        if (code and self.editing is None and not self.l_is_expense.get()
                and paycodes.is_bank_fee(code)):
            self.l_is_expense.set(True)
            self.l_category.set(paycodes.expense_category(
                code, expenses.DEFAULT_BANK_CATEGORY))
            self._toggle_expense_row()

    def _toggle_expense_row(self) -> None:
        """Категоријата и ДДВ-то се гледаат само кога ставката е трошок."""
        if self.l_is_expense.get():
            self.expense_box.pack(side="left", before=self.code_label)
        else:
            self.expense_box.pack_forget()

    def commit_line(self) -> None:
        try:
            amount = q2(D(self.l_amount.get() or 0))
        except ValueError:
            widgets.error(self, "Невалиден износ.")
            return
        if amount <= 0:
            widgets.error(self, "Износот мора да е поголем од нула.")
            return
        try:
            when = parse_date(self.l_date.get())
        except ValueError as exc:
            widgets.error(self, str(exc))
            return
        data = {
            "date": when, "direction": self.l_dir.get(), "amount": amount,
            "cp_account": self.l_account.get().strip(),
            "cp_name": self.l_name.get().strip(),
            "purpose": self.l_purpose.get().strip(),
            "code": self.l_code.get().strip(), "bank_ref": "",
            "partner_id": int(self.l_partner.get()) if self.l_partner.get() else None,
            "matched_by": "рачно" if self.l_partner.get() else "",
            "note": "",
        }
        old = self.lines_data[self.editing] if self.editing is not None else {}
        if self.editing is not None:
            # Она што не се внесува во редот мора да преживее измена:
            # врзаните уплати и веќе создадениот трошок.
            data["expense_id"] = old.get("expense_id")
            data["targets"] = list(old.get("targets") or [])
            data["matched_by"] = (old.get("matched_by")
                                  if data["partner_id"] == old.get("partner_id")
                                  else data["matched_by"])

        if self.l_is_expense.get():
            previous = old.get("expense") or {}
            data["expense"] = {
                "category": self.l_category.get().strip()
                or expenses.DEFAULT_BANK_CATEGORY,
                "description": previous.get("description") or data["purpose"]
                or data["cp_name"],
                "vat_rate": self.l_vat.get() or 0,
            }

        if self.editing is None:
            self.lines_data.append(data)
        else:
            self.lines_data[self.editing] = data
            self.editing = None
            self.btn_line.configure(text="Додај")
        self._clear_entry_row()
        self.refresh_lines()

    def _clear_entry_row(self) -> None:
        self.l_amount.set("0")
        self.l_account.set("")
        self.l_name.set("")
        self.l_purpose.set("")
        self.l_code.set("")
        self.l_partner.clear()
        self.l_is_expense.set(False)
        self.l_category.set(expenses.DEFAULT_BANK_CATEGORY)
        self.l_vat.set("0")
        self._toggle_expense_row()
        self.name_label.configure(text="")
        self._show_code()

    def edit_line(self) -> None:
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = self.lines_data[index]
        self.editing = index
        self.l_date.set(fmt_date(line["date"]))
        self.l_dir.set(line["direction"])
        self.l_amount.set(fmt(line["amount"]))
        self.l_account.set(line.get("cp_account") or "")
        self.l_name.set(line.get("cp_name") or "")
        self.l_purpose.set(line.get("purpose") or "")
        self.l_code.set(line.get("code") or "")
        self.l_partner.set(str(line.get("partner_id") or ""))
        expense = line.get("expense") or {}
        self.l_is_expense.set(bool(expense))
        self.l_category.set(expense.get("category") or expenses.DEFAULT_BANK_CATEGORY)
        self.l_vat.set(fmt(expense.get("vat_rate") or 0, 0))
        self._toggle_expense_row()
        self.name_label.configure(
            text=("Назив во извод: " + line["cp_name"]) if line.get("cp_name") else "")
        self._show_code()
        self.btn_line.configure(text="Зачувај")

    def delete_line(self) -> None:
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = self.lines_data[index]
        if not widgets.confirm(self, "Да се избрише ставката?\n\n"
                                     f"{fmt(line['amount'])} — {line.get('cp_name') or ''}",
                               title="Избриши ставка"):
            return
        self.lines_data.pop(index)
        if self.editing is not None:
            self.editing = None
            self.btn_line.configure(text="Додај")
            self._clear_entry_row()
        self.refresh_lines()

    def rematch(self) -> None:
        """Повторно погодување на клиенти за ставките што се без клиент."""
        found = 0
        for line in self.lines_data:
            if line.get("partner_id"):
                continue
            partner_id, how = statements.suggest_partner(line)
            if partner_id:
                line["partner_id"] = partner_id
                line["matched_by"] = how
                found += 1
        self.refresh_lines()
        widgets.info(self, f"Погодени се уште {found} ставки." if found
                     else "Нема нови погодоци.", title="Погоди клиенти")

    def refresh_lines(self) -> None:
        self._pull_header()
        names = {int(r["id"]): r["name"] for r in partners.list_all()}
        rows = []
        for index, line in enumerate(self.lines_data):
            partner_id = line.get("partner_id")
            parts = []
            if line.get("expense"):
                parts.append("трошок: " + (line["expense"].get("category") or ""))
            for target in line.get("targets") or []:
                parts.append(payments.LABEL.get(target["kind"], target["kind"]).lower())
            closed = ", ".join(parts)
            purpose = line.get("purpose") or ""
            rows.append({
                "id": index,
                "line_no": index + 1,
                "date": fmt_date(line["date"]), "date_raw": line["date"],
                "direction": line["direction"],
                "amount": fmt(line["amount"]), "amount_raw": float(D(line["amount"])),
                "cp_account": line.get("cp_account") or "",
                "cp_name": line.get("cp_name") or "",
                "partner_name": names.get(int(partner_id)) if partner_id else "",
                "purpose": (purpose[:9] + "…") if len(purpose) > 10 else purpose,
                "purpose_raw": purpose,
                "code": line.get("code") or "",
                "closed": closed,
                "_tags": ("done",) if closed else (
                    () if partner_id else ("vnimanie",)),
            })
        self.lines.set_rows(rows)

        computed, ok = statements.balance_check(self.header_data, self.lines_data)
        total_in = q2(sum((D(l["amount"]) for l in self.lines_data
                          if l["direction"] == statements.IN), D(0)))
        total_out = q2(sum((D(l["amount"]) for l in self.lines_data
                           if l["direction"] == statements.OUT), D(0)))
        self.sum_labels["in"].configure(text=fmt(total_in))
        self.sum_labels["out"].configure(text=fmt(total_out))
        self.sum_labels["computed"].configure(text=fmt(computed))
        self.balance_label.configure(
            text="✔ салдото се совпаѓа" if ok else "✗ салдото не се совпаѓа",
            foreground=theme.C["ok"] if ok else theme.C["danger"],
        )
        without = sum(1 for l in self.lines_data
                      if not l.get("partner_id") and not l.get("expense"))
        self.match_label.configure(
            text=(f"{without} ставки без клиент" if without
                  else "сите ставки се распоредени"),
            foreground=theme.C["warn"] if without else theme.C["ok"],
        )
        self._update_line_buttons()

    def _update_line_buttons(self) -> None:
        state = ["!disabled"] if self.lines.selected_id() is not None else ["disabled"]
        self.btn_edit.state(state)
        self.btn_del.state(state)
        self.btn_link.state(state)

    # --------------------------------------------------------------- збирови
    def _build_footer(self) -> None:
        footer = ttk.Frame(self, padding=(8, 0, 8, 6))
        footer.grid(row=2, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)

        sums = ttk.Frame(footer)
        sums.grid(row=0, column=1, sticky="e")
        self.sum_labels: dict[str, ttk.Label] = {}
        for index, (key, text) in enumerate((("in", "Приливи:"), ("out", "Одливи:"),
                                             ("computed", "Пресметана завршна:"))):
            ttk.Label(sums, text=text).grid(row=index, column=0, sticky="e", padx=(0, 10))
            style = "Path.TLabel" if key == "computed" else "TLabel"
            value = ttk.Label(sums, text="0,00", anchor="e", width=14, style=style)
            value.grid(row=index, column=1, sticky="e")
            self.sum_labels[key] = value

        left = ttk.Frame(footer)
        left.grid(row=0, column=0, sticky="w")
        self.balance_label = ttk.Label(left, text="", style="Head.TLabel")
        self.balance_label.pack(anchor="w")
        self.match_label = ttk.Label(left, text="", style="Small.TLabel")
        self.match_label.pack(anchor="w")

        buttons = ttk.Frame(self, padding=(8, 0, 8, 10))
        buttons.grid(row=3, column=0, sticky="ew")
        ttk.Button(buttons, text="Откажи", width=12, command=self.cancel).pack(side="right")
        ttk.Button(buttons, text="Зачувај", width=14, command=self.save).pack(
            side="right", padx=(0, 6))

    # -------------------------------------------------------------- дејства
    def save(self) -> None:
        try:
            self._pull_header()
            self.header_data["date"] = parse_date(self.header_data["date"])
        except ValueError as exc:
            widgets.error(self, str(exc))
            return
        if self._check_duplicate():
            return
        try:
            self.doc_id = statements.save_document(self.doc_id, self.header_data,
                                                   self.lines_data)
        except (ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc), title="Зачувувањето не успеа")
            return
        self.saved = True
        self.app.set_status(f"Зачуван извод бр. {self.header_data['doc_no']}")
        self.destroy()

    def cancel(self) -> None:
        if self._is_dirty() and not widgets.confirm(
            self, "Има промени што не се зачувани.\n\nДа се затвори без зачувување?",
            title="Незачувани промени",
        ):
            return
        self.destroy()

    def show(self) -> bool:
        self.wait_window(self)
        return self.saved


class ImportPreviewWindow(tk.Toplevel):
    """Преглед пред увоз: што е прочитано, што се совпаѓа, што е дупликат."""

    def __init__(self, master, app, prepared: list[dict]):
        super().__init__(master)
        self.app = app
        self.prepared = prepared
        self.imported = 0

        self.title("Увоз на изводи (MT940)")
        self.transient(master.winfo_toplevel())
        self.geometry("1060x620")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        head = ttk.Frame(self, padding=(10, 8, 10, 4))
        head.grid(row=0, column=0, sticky="ew")
        ttk.Label(head, text=f"Прочитани {len(prepared)} изводи. "
                             "Означи ги оние што сакаш да се увезат.",
                  style="Head.TLabel").pack(side="left")

        self.table = DataTable(self, PREVIEW_COLUMNS, height=14, selectmode="extended",
                               on_activate=lambda _i: self.open_one())
        self.table.grid(row=1, column=0, sticky="nsew", padx=10)

        legend = ttk.Labelframe(self, text="Шифри на намена во овие изводи",
                                padding=(10, 6, 10, 8))
        legend.grid(row=2, column=0, sticky="ew", padx=10, pady=(8, 0))
        codes = sorted({line["code"] for item in prepared for line in item["lines"]
                        if line["code"]})
        text = "   ".join(paycodes.describe(code) for code in codes) or "—"
        ttk.Label(legend, text=text, wraplength=1000, justify="left",
                  style="Small.TLabel").pack(anchor="w")

        buttons = ttk.Frame(self, padding=(10, 8, 10, 10))
        buttons.grid(row=3, column=0, sticky="ew")
        ttk.Button(buttons, text="Затвори", width=12, command=self.destroy).pack(side="right")
        self.btn_import = ttk.Button(buttons, text="Увези ги избраните", width=22,
                                     command=self.do_import)
        self.btn_import.pack(side="right", padx=(0, 6))
        ttk.Button(buttons, text="Отвори го избраниот", width=20,
                   command=self.open_one).pack(side="right", padx=(0, 6))

        self._fill()
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()

    def _fill(self) -> None:
        rows = []
        preselect = []
        for index, item in enumerate(self.prepared):
            header = item["header"]
            total_in = q2(sum((D(l["amount"]) for l in item["lines"]
                              if l["direction"] == statements.IN), D(0)))
            total_out = q2(sum((D(l["amount"]) for l in item["lines"]
                               if l["direction"] == statements.OUT), D(0)))
            if not item["duplicate"]:
                preselect.append(index)
            rows.append({
                "id": index,
                "doc_no": header["doc_no"],
                "date": fmt_date(header["date"]), "date_raw": header["date"],
                "account": header["account"],
                "lines": len(item["lines"]), "lines_raw": len(item["lines"]),
                "total_in": fmt(total_in), "total_in_raw": float(total_in),
                "total_out": fmt(total_out), "total_out_raw": float(total_out),
                "closing": fmt(header["closing"]), "closing_raw": float(header["closing"]),
                "balanced": "✔" if item["balanced"] else "✗",
                "matched": f"{item['matched']}/{len(item['lines'])}",
                "matched_raw": item["matched"],
                "duplicate": item["duplicate"],
                "_tags": ("neaktiven",) if item["duplicate"] else
                         (() if item["balanced"] else ("vnimanie",)),
            })
        self.table.set_rows(rows)
        self.table.select_ids(preselect)

    def open_one(self) -> None:
        ids = self.table.selected_ids()
        if not ids:
            return
        item = self.prepared[ids[0]]
        window = IzvodWindow(self, self.app, None, prepared=item)
        if window.show():
            self.imported += 1
            self.prepared.pop(ids[0])
            self._fill()

    def do_import(self) -> None:
        ids = sorted(self.table.selected_ids(), reverse=True)
        if not ids:
            widgets.info(self, "Ниту еден извод не е означен.")
            return
        done, failed = 0, []
        for index in ids:
            item = self.prepared[index]
            try:
                statements.save_document(None, item["header"], item["lines"])
                done += 1
                self.prepared.pop(index)
            except (ValueError, RuntimeError) as exc:
                failed.append(f"извод {item['header']['doc_no']}: {exc}")
        self.imported += done
        self._fill()
        message = f"Увезени се {done} изводи."
        if failed:
            message += "\n\nНе поминаа:\n" + "\n".join(failed[:8])
        widgets.info(self, message, title="Увоз")
        self.app.set_status(f"Увезени {done} изводи од MT940.")
        if not self.prepared:
            self.destroy()

    def show(self) -> int:
        self.wait_window(self)
        return self.imported


class IzvodiView(CrudView):
    title = "Изводи"
    subtitle = "банкарски изводи — рачно или увоз од MT940"
    empty_text = "Нема изводи. Внеси рачно или увези MT940 датотека."
    new_text = "Нов"

    columns = (
        {"key": "doc_no", "text": "Извод", "width": 70, "anchor": "e"},
        {"key": "date", "text": "Датум", "width": 90},
        {"key": "account", "text": "Сметка", "width": 140},
        {"key": "bank_name", "text": "Банка", "width": 130},
        {"key": "lines_count", "text": "Ставки", "width": 60, "anchor": "e", "sort": "num"},
        {"key": "total_in", "text": "Приливи", "width": 105, "anchor": "e", "sort": "num"},
        {"key": "total_out", "text": "Одливи", "width": 105, "anchor": "e", "sort": "num"},
        {"key": "closing", "text": "Завршна", "width": 105, "anchor": "e", "sort": "num"},
        {"key": "unmatched", "text": "Без клиент", "width": 80, "anchor": "e", "sort": "num"},
        {"key": "source", "text": "Извор", "width": 70},
    )

    def build_filters(self, parent: ttk.Frame) -> None:
        """Сметка: секоја трансакциска сметка си има свои изводи."""
        ttk.Label(parent, text="Сметка:", style="Muted.TLabel").pack(side="left",
                                                                     padx=(0, 4))
        self.account_var = tk.StringVar(value=ALL_ACCOUNTS)
        self.account_combo = ttk.Combobox(parent, textvariable=self.account_var,
                                          state="readonly", width=34)
        self.account_combo.pack(side="left")
        self.account_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

    def on_show(self) -> None:
        self._accounts = dict(bank_accounts.options(only_active=True))
        values = [ALL_ACCOUNTS] + [label for _no, label in
                                   bank_accounts.options(only_active=True)]
        self.account_combo.configure(values=values)
        if self.account_var.get() not in values:
            self.account_var.set(ALL_ACCOUNTS)
        super().on_show()

    def selected_account(self) -> str:
        """Бројот на избраната сметка; празно = сите."""
        label = getattr(self, "account_var", None)
        if label is None or label.get() == ALL_ACCOUNTS:
            return ""
        for number, text in self._accounts.items():
            if text == label.get():
                return number
        return ""

    def export_info(self) -> list[str]:
        info = super().export_info()
        if self.selected_account():
            info.append("Сметка: " + self.account_var.get())
        return info

    def extra_buttons(self, toolbar: Toolbar) -> None:
        toolbar.button("Увези MT940", self.action_import, width=15)

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for rec in statements.list_all(search, account=self.selected_account()):
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "account": rec["account"],
                "bank_name": rec["bank_name"],
                "lines_count": rec["lines_count"], "lines_count_raw": rec["lines_count"],
                "total_in": fmt(rec["total_in"]), "total_in_raw": rec["total_in"],
                "total_out": fmt(rec["total_out"]), "total_out_raw": rec["total_out"],
                "closing": fmt(rec["closing"]), "closing_raw": rec["closing"],
                "unmatched": rec["unmatched"] or "", "unmatched_raw": rec["unmatched"],
                "source": rec["source"],
                "_tags": ("vnimanie",) if rec["unmatched"] else (),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"извод бр. {row['doc_no']} од {row['date']}"

    def delete_warning(self, row: dict) -> str:
        count = len(statements.expense_ids(int(row["id"])))
        if not count:
            return ""
        return (f"Изводот создал {count} трошок(ци) — тие се бришат заедно со него, "
                "за да не останат сами и да не се удвојат при повторен увоз.")

    def delete_record(self, rec_id: int) -> None:
        statements.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        # Новиот извод се отвора за избраната сметка.
        return IzvodWindow(self, self.app, rec_id,
                           account=self.selected_account()).show()

    # ----------------------------------------------------------------- увоз
    def action_import(self) -> None:
        paths = filedialog.askopenfilenames(
            parent=self, title="Избери MT940 датотеки",
            filetypes=[("MT940 извод", "*.txt"), ("Сите датотеки", "*.*")],
        )
        if not paths:
            return
        prepared: list[dict] = []
        problems: list[str] = []
        for path in paths:
            try:
                parsed = mt940.read_file(path)
            except (OSError, ValueError) as exc:
                problems.append(f"{path}: {exc}")
                continue
            if not parsed:
                problems.append(f"{path}: не е препознаен MT940 запис")
                continue
            import os
            prepared += statements.prepare_import(parsed, os.path.basename(path))

        if problems:
            widgets.error(self, "Некои датотеки не поминаа:\n\n" + "\n".join(problems[:8]))
        if not prepared:
            return
        if ImportPreviewWindow(self, self.app, prepared).show():
            self.refresh()
