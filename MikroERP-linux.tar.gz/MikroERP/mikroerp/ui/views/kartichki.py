# -*- coding: utf-8 -*-
"""ИЗВЕШТАИ → Картички.

Две картички во ист екран, се менуваат со јазичиња:

* **Клиент** — класична картица: задолжување, побарување и салдо по ставка.
  Може да се гледа **по датум** (сè хронолошки) или **по уплата** — тогаш
  документот и неговите уплати одат заедно, а редоследот го одредува она што
  дошло прво: ако уплатата е прва, таа е горе, а фактурата под неа.
* **Артикл** — движење на залихата: влез, излез, состојба и вредност.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, fmt_qty, q2
from ...repo import cards, items, partners, warehouses
from ...util import fmt_date, parse_date
from .. import exporting, theme, widgets
from ..widgets import DataTable, SearchPicker
from .base import View

PARTNER_COLUMNS = (
    {"key": "date", "text": "Датум", "width": 90},
    {"key": "what", "text": "Ставка", "width": 145},
    {"key": "doc_no", "text": "Документ", "width": 130},
    {"key": "debit", "text": "Задолжување", "width": 115, "anchor": "e", "sort": "num"},
    {"key": "credit", "text": "Побарување", "width": 115, "anchor": "e", "sort": "num"},
    {"key": "balance", "text": "Салдо", "width": 120, "anchor": "e", "sort": "num"},
)

ITEM_COLUMNS = (
    {"key": "date", "text": "Датум", "width": 90},
    {"key": "doc_type", "text": "Документ", "width": 145},
    {"key": "doc_no", "text": "Број", "width": 110},
    {"key": "in_qty", "text": "Влез", "width": 90, "anchor": "e", "sort": "num"},
    {"key": "out_qty", "text": "Излез", "width": 90, "anchor": "e", "sort": "num"},
    {"key": "balance", "text": "Состојба", "width": 95, "anchor": "e", "sort": "num"},
    {"key": "unit_cost", "text": "Цена", "width": 95, "anchor": "e", "sort": "num"},
    {"key": "value", "text": "Вредност", "width": 105, "anchor": "e", "sort": "num"},
    {"key": "stock_value", "text": "Вредност на залиха", "width": 130, "anchor": "e",
     "sort": "num"},
)

DOC_LABEL = {
    "priemnica": "Приемница", "ispratnica": "Испратница",
    "izlezna_faktura": "Излезна фактура", "vlezna_faktura": "Влезна фактура",
    "raboten_nalog_izlez": "Работен налог (материјал)",
    "raboten_nalog_vlez": "Работен налог (производ)",
}


class KartichkiView(View):
    title = "Картички"
    subtitle = "картица на клиент и картица на артикл"

    def build(self) -> None:
        self.rowconfigure(2, weight=1)
        notebook = ttk.Notebook(self)
        notebook.grid(row=2, column=0, sticky="nsew")

        self.partner_tab = ttk.Frame(notebook, padding=(0, 8, 0, 0))
        self.item_tab = ttk.Frame(notebook, padding=(0, 8, 0, 0))
        notebook.add(self.partner_tab, text="  Клиент  ")
        notebook.add(self.item_tab, text="  Артикл  ")
        notebook.bind("<<NotebookTabChanged>>", lambda _e: self.refresh())

        self._build_partner_tab()
        self._build_item_tab()

    # ------------------------------------------------------- картица клиент
    def _build_partner_tab(self) -> None:
        tab = self.partner_tab
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        bar = ttk.Frame(tab)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(bar, text="Клиент:").pack(side="left")
        self.partner_picker = SearchPicker(
            bar, [(str(r["id"]), r["name"], f"{r['code']} {r['city']}")
                  for r in partners.list_all()], width=32,
            on_select=lambda _v: self.refresh())
        self.partner_picker.pack(side="left", padx=(4, 16))

        ttk.Label(bar, text="Групирање:").pack(side="left")
        self.group_var = tk.StringVar(value="по датум")
        combo = ttk.Combobox(bar, textvariable=self.group_var, state="readonly", width=12,
                             values=["по датум", "по уплата"])
        combo.pack(side="left", padx=(4, 16))
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        ttk.Label(bar, text="Од:").pack(side="left")
        self.p_from = tk.StringVar()
        ttk.Entry(bar, textvariable=self.p_from, width=11).pack(side="left", padx=(4, 8))
        ttk.Label(bar, text="До:").pack(side="left")
        self.p_to = tk.StringVar()
        ttk.Entry(bar, textvariable=self.p_to, width=11).pack(side="left", padx=(4, 8))
        ttk.Button(bar, text="Прикажи", width=11, command=self.refresh).pack(side="left")
        ttk.Button(bar, text="Excel", width=8,
                   command=lambda: self._export("partner")).pack(side="right")
        ttk.Button(bar, text="Печати", width=10,
                   command=lambda: self._print("partner")).pack(side="right", padx=(0, 6))

        self.partner_table = DataTable(tab, PARTNER_COLUMNS, height=18)
        self.partner_table.grid(row=1, column=0, sticky="nsew")

        self.partner_totals = ttk.Label(tab, text="", style="Head.TLabel")
        self.partner_totals.grid(row=2, column=0, sticky="e", pady=(6, 0))

    def _refresh_partner(self) -> None:
        partner_id = self.partner_picker.get()
        if not partner_id:
            self.partner_table.set_rows([])
            self.partner_totals.configure(text="Избери клиент.")
            return
        try:
            date_from = parse_date(self.p_from.get()) if self.p_from.get().strip() else ""
            date_to = parse_date(self.p_to.get()) if self.p_to.get().strip() else ""
        except ValueError as exc:
            widgets.error(self, str(exc))
            return

        rows = cards.partner_card(int(partner_id), date_from, date_to)
        if self.group_var.get() == "по уплата":
            rows = cards.group_by_document(rows)
        rows, debit, credit, balance = cards.with_balance(rows)

        table_rows = []
        for index, row in enumerate(rows):
            prefix = "    ↳ " if row.get("indent") else ""
            table_rows.append({
                "id": index,
                "date": fmt_date(row["date"]), "date_raw": row["date"],
                "what": prefix + row["what"],
                "doc_no": row["doc_no"],
                "debit": fmt(row["debit"]) if row["debit"] else "",
                "debit_raw": float(row["debit"]),
                "credit": fmt(row["credit"]) if row["credit"] else "",
                "credit_raw": float(row["credit"]),
                "balance": fmt(row["balance"]), "balance_raw": float(row["balance"]),
                "_tags": ("neaktiven",) if row.get("indent") else (),
            })
        self.partner_table.set_rows(table_rows)
        self.partner_totals.configure(
            text=f"Задолжување: {fmt(debit)}     Побарување: {fmt(credit)}     "
                 f"Салдо: {fmt(balance)}",
            foreground=theme.C["danger"] if balance > 0 else theme.C["ok"],
        )

    # ------------------------------------------------------- картица артикл
    def _build_item_tab(self) -> None:
        tab = self.item_tab
        tab.columnconfigure(0, weight=1)
        tab.rowconfigure(1, weight=1)

        bar = ttk.Frame(tab)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(bar, text="Артикл:").pack(side="left")
        self.item_picker = SearchPicker(
            bar, [(str(r["id"]), f"{r['code']} — {r['name']}", r["barcode"])
                  for r in items.list_all()], width=34,
            on_select=lambda _v: self.refresh())
        self.item_picker.pack(side="left", padx=(4, 16))

        if warehouses.many():
            ttk.Label(bar, text="Магацин:").pack(side="left")
            self.wh_picker = SearchPicker(
                bar, [("", "сите")] + [(str(i), n) for i, n in warehouses.options()],
                width=18, on_select=lambda _v: self.refresh())
            self.wh_picker.pack(side="left", padx=(4, 16))
            self.wh_picker.set("")
        else:
            self.wh_picker = None

        ttk.Label(bar, text="Од:").pack(side="left")
        self.i_from = tk.StringVar()
        ttk.Entry(bar, textvariable=self.i_from, width=11).pack(side="left", padx=(4, 8))
        ttk.Label(bar, text="До:").pack(side="left")
        self.i_to = tk.StringVar()
        ttk.Entry(bar, textvariable=self.i_to, width=11).pack(side="left", padx=(4, 8))
        ttk.Button(bar, text="Прикажи", width=11, command=self.refresh).pack(side="left")
        ttk.Button(bar, text="Excel", width=8,
                   command=lambda: self._export("item")).pack(side="right")
        ttk.Button(bar, text="Печати", width=10,
                   command=lambda: self._print("item")).pack(side="right", padx=(0, 6))

        self.item_table = DataTable(tab, ITEM_COLUMNS, height=18)
        self.item_table.grid(row=1, column=0, sticky="nsew")

        self.item_totals = ttk.Label(tab, text="", style="Head.TLabel")
        self.item_totals.grid(row=2, column=0, sticky="e", pady=(6, 0))

    def _refresh_item(self) -> None:
        item_id = self.item_picker.get()
        if not item_id:
            self.item_table.set_rows([])
            self.item_totals.configure(text="Избери артикл.")
            return
        try:
            date_from = parse_date(self.i_from.get()) if self.i_from.get().strip() else ""
            date_to = parse_date(self.i_to.get()) if self.i_to.get().strip() else ""
        except ValueError as exc:
            widgets.error(self, str(exc))
            return
        warehouse = None
        if self.wh_picker is not None and self.wh_picker.get():
            warehouse = int(self.wh_picker.get())

        rows = cards.item_card(int(item_id), warehouse, date_from, date_to)
        table_rows = []
        for index, row in enumerate(rows):
            table_rows.append({
                "id": index,
                "date": fmt_date(row["date"]), "date_raw": row["date"],
                "doc_type": DOC_LABEL.get(row["doc_type"], row["doc_type"]),
                "doc_no": row["doc_no"],
                "in_qty": fmt_qty(row["in_qty"]) if row["in_qty"] else "",
                "in_qty_raw": float(row["in_qty"]),
                "out_qty": fmt_qty(row["out_qty"]) if row["out_qty"] else "",
                "out_qty_raw": float(row["out_qty"]),
                "balance": fmt_qty(row["balance"]), "balance_raw": float(row["balance"]),
                "unit_cost": fmt(row["unit_cost"]), "unit_cost_raw": float(row["unit_cost"]),
                "value": fmt(row["value"]), "value_raw": float(row["value"]),
                "stock_value": fmt(row["stock_value"]),
                "stock_value_raw": float(row["stock_value"]),
                "_tags": () if row["in_qty"] else ("neaktiven",),
            })
        self.item_table.set_rows(table_rows)
        last = rows[-1] if rows else None
        self.item_totals.configure(
            text=(f"Состојба: {fmt_qty(last['balance'])}     "
                  f"Вредност: {fmt(last['stock_value'])}") if last else "Нема движења.",
            foreground=theme.C["fg"],
        )

    # ---------------------------------------------------------- печат и извоз
    def _card(self, which: str) -> tuple:
        """(наслов, колони, редови, контекст) за тековната картица."""
        if which == "partner":
            name = self.partner_picker.get_text() or ""
            info = [f"Клиент: {name}" if name else "Сите клиенти",
                    "Групирање: " + self.group_var.get()]
            period = self._period(self.p_from, self.p_to)
            return ("Картица на клиент", PARTNER_COLUMNS,
                    list(self.partner_table._rows), info + period)
        name = self.item_picker.get_text() or ""
        info = [f"Артикл: {name}" if name else "Сите артикли"]
        if self.wh_picker is not None and self.wh_picker.get_text():
            info.append("Магацин: " + self.wh_picker.get_text())
        return ("Картица на артикл", ITEM_COLUMNS,
                list(self.item_table._rows), info + self._period(self.i_from, self.i_to))

    @staticmethod
    def _period(var_from, var_to) -> list[str]:
        text = " ".join(x for x in (
            f"од {var_from.get().strip()}" if var_from.get().strip() else "",
            f"до {var_to.get().strip()}" if var_to.get().strip() else "") if x)
        return [f"Период: {text}"] if text else []

    def _export(self, which: str) -> None:
        title, columns, rows, info = self._card(which)
        exporting.export_rows(self, columns, rows, title, info)

    def _print(self, which: str) -> None:
        title, columns, rows, info = self._card(which)
        totals = None
        if which == "partner" and rows:
            last = rows[-1]
            totals = [("Салдо", last.get("balance", ""), True)]
        exporting.print_rows(self, columns, rows, title, info, totals)

    # ------------------------------------------------------------- освежување
    def on_show(self) -> None:
        self.refresh()

    def refresh(self) -> None:
        try:
            self._refresh_partner()
            self._refresh_item()
        except Exception as exc:  # noqa: BLE001
            widgets.error(self, f"Картицата не може да се состави:\n{exc}")
