# -*- coding: utf-8 -*-
"""Поврзување на документи — избор на фактура и приказ на врските.

Испратницата се фактурира со излезна фактура, приемницата со влезна. Освен
„Фактурирај“ (прави нова), постои и **„Поврзи со фактура“** — кога фактурата
веќе е внесена, па само треба да се знае која испратница ја покрива.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import fmt
from ...repo import issues, links, reversals, sales
from ...util import fmt_date
from .. import widgets
from ..widgets import DataTable

CHOOSE_COLUMNS = (
    {"key": "doc_no", "text": "Број", "width": 110},
    {"key": "date_text", "text": "Датум", "width": 90},
    {"key": "partner_name", "text": "Клиент", "width": 230, "stretch": True},
    {"key": "total", "text": "Вкупно", "width": 110, "anchor": "e", "sort": "num"},
    {"key": "linked", "text": "Поврзана со", "width": 150},
)

LINK_COLUMNS = (
    {"key": "doc_no", "text": "Документ", "width": 110},
    {"key": "date_text", "text": "Датум", "width": 85},
    {"key": "total", "text": "Вкупно", "width": 100, "anchor": "e", "sort": "num"},
)


def choose_document(parent, title: str, rows: list[dict], hint: str = "") -> dict | None:
    """Избор на еден документ од листа. Враќа го избраниот ред или None."""
    if not rows:
        widgets.info(parent, "Нема документи за поврзување на овој клиент.",
                     title=title)
        return None
    window = tk.Toplevel(parent)
    window.title(title)
    window.transient(parent.winfo_toplevel())
    window.geometry("780x460")
    window.columnconfigure(0, weight=1)
    window.rowconfigure(1, weight=1)
    chosen: dict = {}

    ttk.Label(window, text=hint or "Избери документ и кликни „Поврзи“.",
              padding=(10, 8)).grid(row=0, column=0, sticky="w")

    def take(*_a):
        index = table.selected_id()
        if index is not None and index < len(rows):
            chosen.update(rows[index])
            window.destroy()

    table = DataTable(window, CHOOSE_COLUMNS, height=13, on_activate=lambda _i: take())
    table.grid(row=1, column=0, sticky="nsew", padx=10)
    table.set_rows([
        {"id": index, "doc_no": row["doc_no"],
         "date_text": row.get("date_text") or fmt_date(row["date"]),
         "date_text_raw": row["date"],
         "partner_name": row.get("partner_name", ""),
         "total": fmt(row.get("total") or 0), "total_raw": float(row.get("total") or 0),
         "linked": row.get("linked", "")}
        for index, row in enumerate(rows)])
    table.select_first()

    buttons = ttk.Frame(window, padding=(10, 8, 10, 10))
    buttons.grid(row=2, column=0, sticky="ew")
    ttk.Button(buttons, text="Откажи", width=12,
               command=window.destroy).pack(side="right")
    ttk.Button(buttons, text="Поврзи", width=12, command=take).pack(side="right",
                                                                    padx=(0, 6))
    window.bind("<Escape>", lambda _e: window.destroy())
    widgets.center_on(window, parent.winfo_toplevel())
    window.grab_set()
    parent.wait_window(window)
    return chosen or None


def link_to_invoice(view, source_kind: str, row: dict) -> bool:
    """„Поврзи со фактура“ за избраната испратница/приемница."""
    target_kind = links.PAIR[source_kind]
    partner_id = row.get("partner_id")
    already = [item["id"] for item in links.targets_of(source_kind, int(row["id"]))]
    candidates = links.open_targets(target_kind, partner_id, exclude=already)
    for candidate in candidates:
        others = links.sources_of(target_kind, candidate["id"])
        candidate["linked"] = links.numbers(others)
    label = links.TARGETS[target_kind][1]
    chosen = choose_document(
        view, f"Поврзи со {label.lower()}", candidates,
        hint=f"{links.SOURCES[source_kind][1]} {row['doc_no']} — избери "
             f"{label.lower()} што ја покрива. Една фактура може да покрие "
             "повеќе документи.")
    if not chosen:
        return False
    links.link(source_kind, int(row["id"]), target_kind, int(chosen["id"]))
    view.status(f"{links.SOURCES[source_kind][1]} {row['doc_no']} е поврзана со "
                f"{chosen['doc_no']}.")
    return True


def reversal_lines(kind: str, doc_id: int) -> list[str]:
    """Сторно/повратница врски за овој документ, како краток текст."""
    out = []
    if kind == links.FAKTURA:
        record = sales.get(doc_id)
        if record is not None and record["is_storno"] and record["storno_of_id"]:
            original = sales.get(int(record["storno_of_id"]))
            if original is not None:
                out.append("Сторно на фактура " + original["doc_no"])
        storno = reversals.storno_of(doc_id)
        if storno is not None:
            out.append("Сторнирана со " + storno["doc_no"])
    elif kind == links.ISPRATNICA:
        record = issues.get(doc_id)
        if record is not None and record["is_return"] and record["return_of_id"]:
            original = issues.get(int(record["return_of_id"]))
            if original is not None:
                out.append("Повратница по испратница " + original["doc_no"])
        back = reversals.return_of(doc_id)
        if back is not None:
            out.append("Има повратница " + back["doc_no"])
    return out


def links_panel(parent, kind: str, doc_id: int):
    """Кутија со поврзаните документи — стои до забелешката во документот."""
    if kind in links.TARGETS:
        items = links.sources_of(kind, doc_id)
        title = links.SOURCES[links.BACK[kind]][2].capitalize()
        empty = links.EMPTY_SOURCE[links.BACK[kind]]
    else:
        items = links.targets_of(kind, doc_id)
        title = "Фактури"
        empty = links.EMPTY_TARGET[links.PAIR[kind]]

    box = ttk.Labelframe(parent, text=title, padding=(10, 6, 10, 8))
    for text in reversal_lines(kind, doc_id):
        ttk.Label(box, text=text, style="Head.TLabel").pack(anchor="w")
    if not items:
        ttk.Label(box, text=empty, style="Muted.TLabel").pack(anchor="w")
        return box
    table = DataTable(box, LINK_COLUMNS, height=min(4, max(2, len(items))))
    table.pack(fill="both", expand=True)
    table.set_rows([
        {"id": index, "doc_no": item["doc_no"], "date_text": fmt_date(item["date"]),
         "date_text_raw": item["date"], "total": fmt(item["total"] or 0),
         "total_raw": float(item["total"] or 0)}
        for index, item in enumerate(items)])
    return box
