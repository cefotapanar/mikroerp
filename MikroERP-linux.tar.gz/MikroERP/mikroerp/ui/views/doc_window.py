# -*- coding: utf-8 -*-
"""Заедничка основа за документите со ставки (приемница, испратница, фактури).

Документот целиот се држи во меморија додека се уредува:
  * ставките се додаваат во **еден ред**, со Enter/Tab — без посебен дијалог;
  * **Зачувај** го запишува документот и го спроведува движењето на залихата;
  * **Откажи** не менува ништо (и предупредува ако има незачувани промени).

Конкретните документи само кажуваат кој слој за податоци го користат и што е
поинакво во заглавието (види `PriemnicaWindow` / `IspratnicaWindow`).
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, fmt_qty, with_vat, without_vat
from ...repo import items, partners, warehouses
from ...util import fmt_date, parse_date, today
from .. import exporting, theme, widgets
from ..widgets import DataTable, SearchPicker, Toolbar
from .artikli import new_item_dialog
from .klienti import new_partner_dialog

LINE_COLUMNS = (
    {"key": "line_no", "text": "Р.бр", "width": 45, "anchor": "e"},
    {"key": "code", "text": "Шифра", "width": 75},
    {"key": "name", "text": "Артикл", "width": 210, "stretch": True},
    {"key": "unit", "text": "ЕМ", "width": 45, "anchor": "center"},
    {"key": "qty", "text": "Количина", "width": 80, "anchor": "e", "sort": "num"},
    {"key": "price", "text": "Цена", "width": 85, "anchor": "e", "sort": "num"},
    {"key": "discount", "text": "Рабат %", "width": 65, "anchor": "e", "sort": "num"},
    {"key": "net", "text": "Основица", "width": 95, "anchor": "e", "sort": "num"},
    {"key": "tax_rate", "text": "ДДВ %", "width": 55, "anchor": "e", "sort": "num"},
    {"key": "vat", "text": "ДДВ", "width": 85, "anchor": "e", "sort": "num"},
    {"key": "gross", "text": "Вкупно", "width": 95, "anchor": "e", "sort": "num"},
)


class DocumentWindow(tk.Toplevel):
    # --- што го разликува документот (се задава во подкласите) --------------
    doc_label = "Документ"
    partner_label = "Клиент"
    partner_as_supplier = False
    save_hint = ""
    line_columns = LINE_COLUMNS
    repo = None                 # модул со blank/get/lines/save_document/…
    print_kind = ""             # вид за печатење (docprint.KINDS)

    def __init__(self, master, app, doc_id: int | None = None):
        super().__init__(master)
        self.app = app
        self.doc_id = doc_id
        self.saved = False
        self.editing: int | None = None       # индекс на ставка што се менува

        self.header_data, self.lines_data = self._load()
        self._start = self._snapshot()

        self.title(f"{self.doc_label} {self.header_data['doc_no']}" if doc_id
                   else f"{self.doc_label} {self.header_data['doc_no']} (нова)")
        self.transient(master.winfo_toplevel())
        self.geometry("1200x760")
        self.minsize(1040, 620)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        self._build_header()
        self._build_lines()
        self._build_note()
        self._build_footer()

        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.bind("<Escape>", lambda _e: self.cancel())
        self.refresh_lines()
        self._show_full_name()
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()
        self.after(50, self.partner_picker.focus)

    # ---------------------------------------------------- за преклопување
    def build_header_extra(self, parent: ttk.Frame) -> None:
        """Дополнителни полиња во вториот ред од заглавието."""

    def pull_header_extra(self) -> None:
        """Читање на тие полиња назад во `self.header_data`."""

    def default_price(self, item_row):
        """Која цена да се понуди кога ќе се избере артикл."""
        return item_row["purchase_price"]

    # ------------------------------------------------------------- податоци
    def _load(self):
        if self.doc_id is None:
            return self.repo.blank(today()), []
        record = self.repo.get(self.doc_id)
        if record is None:
            raise ValueError(f"{self.doc_label} не постои.")
        header = self.repo.header_of(record)
        rows = []
        for line in self.repo.lines(self.doc_id):
            rows.append({
                "item_id": int(line["item_id"]), "code": line["item_code"],
                "name": line["item_name"], "unit": line["item_unit"],
                "qty": D(line["qty"]), "price": D(line["price"]),
                "discount": D(line["discount"]), "tax_rate": D(line["tax_rate"]),
            })
        return header, rows

    def _snapshot(self) -> str:
        header = {k: v for k, v in self.header_data.items() if k != "doc_no"}
        return repr((sorted(header.items()), [sorted(l.items()) for l in self.lines_data]))

    def _is_dirty(self) -> bool:
        self._pull_header()
        return self._snapshot() != self._start

    # -------------------------------------------------------------- заглавие
    def _build_header(self) -> None:
        box = ttk.Labelframe(self, text="Заглавие", padding=(10, 6, 10, 8))
        box.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 4))

        row1 = ttk.Frame(box)
        row1.pack(fill="x")

        ttk.Label(row1, text="Број:").pack(side="left")
        ttk.Label(row1, text=self.header_data["doc_no"], style="Path.TLabel",
                  width=13).pack(side="left", padx=(4, 16))

        ttk.Label(row1, text="Датум:").pack(side="left")
        self.date_var = tk.StringVar(value=fmt_date(self.header_data["date"]))
        date_entry = ttk.Entry(row1, textvariable=self.date_var, width=11)
        date_entry.pack(side="left", padx=(4, 16))
        widgets.require(date_entry, self.date_var)

        ttk.Label(row1, text=self.partner_label + ":").pack(side="left")
        self.partner_picker = SearchPicker(row1, self._partner_options(), width=32)
        self.partner_picker.pack(side="left", padx=(4, 4))
        self.partner_picker.set(str(self.header_data["partner_id"] or ""))
        widgets.require(self.partner_picker)
        ttk.Button(row1, text="Нов клиент", width=12,
                   command=self.create_partner).pack(side="left", padx=(0, 10))

        # Полниот назив се печати само ако документот го побара.
        self.full_name_var = tk.BooleanVar(
            value=bool(self.header_data.get("use_full_name")))
        ttk.Checkbutton(row1, text="Користи полн назив",
                        variable=self.full_name_var,
                        command=self._show_full_name).pack(side="left", padx=(0, 8))
        self.full_name_label = ttk.Label(row1, text="", style="Small.TLabel")
        self.full_name_label.pack(side="left", padx=(0, 12))

        if warehouses.many():
            ttk.Label(row1, text="Магацин:").pack(side="left")
            self.warehouse_picker = SearchPicker(
                row1, [(str(i), n) for i, n in warehouses.options()], width=18)
            self.warehouse_picker.pack(side="left", padx=(4, 0))
            self.warehouse_picker.set(str(self.header_data["warehouse_id"]))
        else:
            self.warehouse_picker = None

        row2 = ttk.Frame(box)
        row2.pack(fill="x", pady=(8, 0))
        self.build_header_extra(row2)

    def _partner_options(self):
        return [(str(r["id"]), r["name"], f"{r['code']} {r['city']} {r['tax_number']}")
                for r in partners.list_all(only_active=True)]

    def _show_full_name(self) -> None:
        partner_id = self.partner_picker.get()
        text = ""
        if self.full_name_var.get() and partner_id:
            record = partners.get(int(partner_id))
            if record is not None:
                text = partners.display_name(record, full=True)
        self.full_name_label.configure(text=text)

    def create_partner(self) -> None:
        new_id = new_partner_dialog(self, as_supplier=self.partner_as_supplier)
        if new_id:
            self.partner_picker.set_options(self._partner_options())
            self.partner_picker.set(str(new_id))

    def _pull_header(self) -> None:
        self.header_data["date"] = self._norm_date(self.date_var.get())
        self.header_data["partner_id"] = (int(self.partner_picker.get())
                                          if self.partner_picker.get() else None)
        self.header_data["note"] = self.note_widget.get("1.0", "end-1c").strip()
        self.header_data["use_full_name"] = bool(self.full_name_var.get())
        if self.warehouse_picker is not None and self.warehouse_picker.get():
            self.header_data["warehouse_id"] = int(self.warehouse_picker.get())
        self.pull_header_extra()

    @staticmethod
    def _norm_date(text) -> str:
        # Датумите се нормализираат веднаш, за споредбата „има ли промени“
        # да не се лаже од различниот запис (12.08.2026 vs 2026-08-12).
        try:
            return parse_date(text) if str(text).strip() else ""
        except ValueError:
            return str(text)

    # ---------------------------------------------------------------- ставки
    def _build_lines(self) -> None:
        box = ttk.Labelframe(self, text="Ставки", padding=(10, 6, 10, 8))
        box.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)
        box.columnconfigure(0, weight=1)
        box.rowconfigure(2, weight=1)

        entry_row = ttk.Frame(box)
        entry_row.grid(row=0, column=0, sticky="ew", pady=(0, 6))

        ttk.Label(entry_row, text="Артикл:").pack(side="left")
        self.item_picker = SearchPicker(entry_row, self._item_options(), width=34,
                                        on_select=self._on_item_chosen)
        self.item_picker.pack(side="left", padx=(4, 4))
        ttk.Button(entry_row, text="Креирај артикл", width=15,
                   command=self.create_item).pack(side="left", padx=(0, 14))

        self.qty_var = tk.StringVar(value="1")
        self.price_var = tk.StringVar(value="0")        # без ДДВ
        self.gross_var = tk.StringVar(value="0")        # со ДДВ
        self.discount_var = tk.StringVar(value="0")
        self.rate_var = tk.StringVar(value="18")
        chain: list = [self.item_picker.entry]
        for text, var, width in (("Кол.:", self.qty_var, 8),
                                 ("Без ДДВ:", self.price_var, 10),
                                 ("Со ДДВ:", self.gross_var, 10),
                                 ("Рабат %:", self.discount_var, 6),
                                 ("ДДВ %:", self.rate_var, 5)):
            ttk.Label(entry_row, text=text).pack(side="left")
            entry = ttk.Entry(entry_row, textvariable=var, width=width, justify="right")
            entry.pack(side="left", padx=(4, 8))
            chain.append(entry)
        widgets.require(chain[1], self.qty_var)

        # Која и да ја внесеш — другата се пресметува сама.
        self._syncing = False
        self.price_var.trace_add("write", lambda *_a: self._sync_price(from_net=True))
        self.gross_var.trace_add("write", lambda *_a: self._sync_price(from_net=False))
        self.rate_var.trace_add("write", lambda *_a: self._sync_price(from_net=True))

        # Enter оди на следното поле; на последното — ја додава ставката.
        for index, widget in enumerate(chain):
            if index + 1 < len(chain):
                widget.bind("<Return>", self._next_field(chain[index + 1]), add="+")
            else:
                widget.bind("<Return>", lambda _e: self.commit_line(), add="+")

        self.btn_line = ttk.Button(entry_row, text="Додај", width=10, command=self.commit_line)
        self.btn_line.pack(side="left")

        ttk.Label(box, text="Enter оди на следното поле; на последното ја додава "
                            "ставката. Tab исто оди напред.",
                  style="Small.TLabel").grid(row=1, column=0, sticky="w", pady=(0, 4))

        self.lines = DataTable(box, self.line_columns, on_activate=lambda _i: self.edit_line(),
                               on_select=lambda _i: self._update_line_buttons(), height=11)
        self.lines.grid(row=2, column=0, sticky="nsew")
        self.lines.tree.bind("<Delete>", lambda _e: self.delete_line())

        tools = Toolbar(box)
        tools.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.btn_edit = tools.button("Измени ставка", self.edit_line, width=15)
        self.btn_del = tools.button("Избриши ставка", self.delete_line, width=15)
        ttk.Label(box, text="Delete ја брише избраната ставка.",
                  style="Small.TLabel").grid(row=4, column=0, sticky="w", pady=(4, 0))

    def _sync_price(self, from_net: bool) -> None:
        """Цената без ДДВ и цената со ДДВ се држат усогласени."""
        if self._syncing:
            return
        self._syncing = True
        try:
            rate = D(self.rate_var.get() or 0)
            if from_net:
                net = D(self.price_var.get() or 0)
                self.gross_var.set(fmt(with_vat(net, rate)))
            else:
                gross = D(self.gross_var.get() or 0)
                self.price_var.set(fmt(without_vat(gross, rate)))
        except ValueError:
            pass                      # додека се пишува може да е недовршен број
        finally:
            self._syncing = False

    @staticmethod
    def _next_field(widget):
        def handler(_event=None):
            widget.focus_set()
            try:
                widget.select_range(0, "end")
            except tk.TclError:
                pass
            return "break"
        return handler

    def _item_options(self):
        return [(str(r["id"]), f"{r['code']} — {r['name']}",
                 f"{r['barcode']} {r['brand_name']}")
                for r in items.list_all(only_active=True)]

    def create_item(self) -> None:
        new_id = new_item_dialog(self)
        if new_id:
            self.item_picker.set_options(self._item_options())
            self.item_picker.set(str(new_id), fire=True)

    def _on_item_chosen(self, value) -> None:
        if not value:
            return
        row = items.get(int(value))
        if row is None:
            return
        self.rate_var.set(fmt(row["tax_rate"], 0))
        if not D(self.price_var.get() or 0):
            self.price_var.set(fmt(self.default_price(row)))     # gross се пресметува сам

    def commit_line(self) -> None:
        item_id = self.item_picker.get()
        if not item_id:
            widgets.info(self, "Избери артикл.")
            self.item_picker.focus()
            return
        row = items.get(int(item_id))
        data = {
            "item_id": int(item_id), "code": row["code"], "name": row["name"],
            "unit": row["unit"],
            "qty": self.qty_var.get(), "price": self.price_var.get(),
            "discount": self.discount_var.get(), "tax_rate": self.rate_var.get(),
        }
        try:
            self.repo.clean_line(data)          # само проверка
        except ValueError as exc:
            widgets.error(self, str(exc))
            return
        amounts = self.repo.line_amounts(data["qty"], data["price"],
                                         data["discount"], data["tax_rate"])
        data.update({k: amounts[k] for k in ("qty", "price", "discount", "tax_rate")})

        if self.editing is None:
            self.lines_data.append(data)
        else:
            self.lines_data[self.editing] = data
            self.editing = None
            self.btn_line.configure(text="Додај")
        self._clear_entry_row()
        self.refresh_lines()

    def _clear_entry_row(self) -> None:
        self.item_picker.clear()
        self.qty_var.set("1")
        self.discount_var.set("0")
        self.rate_var.set("18")
        self.price_var.set("0")
        self.item_picker.focus()

    def edit_line(self) -> None:
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = self.lines_data[index]
        self.editing = index
        self.item_picker.set(str(line["item_id"]))
        self.qty_var.set(fmt_qty(line["qty"]))
        self.discount_var.set(fmt(line["discount"], 1))
        self.rate_var.set(fmt(line["tax_rate"], 0))
        self.price_var.set(fmt(line["price"]))
        self.btn_line.configure(text="Зачувај")
        self.item_picker.focus()

    def delete_line(self) -> None:
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = self.lines_data[index]
        if not widgets.confirm(self, f"Да се избрише ставката?\n\n"
                                     f"{line['code']} — {line['name']}",
                               title="Избриши ставка"):
            return
        self.lines_data.pop(index)
        if self.editing is not None:
            self.editing = None
            self.btn_line.configure(text="Додај")
            self._clear_entry_row()
        self.refresh_lines()

    def refresh_lines(self) -> None:
        rows = []
        for index, line in enumerate(self.lines_data):
            amounts = self.repo.line_amounts(line["qty"], line["price"],
                                             line["discount"], line["tax_rate"])
            rows.append({
                "id": index,                    # индексот е идентитет во меморија
                "line_no": index + 1,
                "code": line["code"], "name": line["name"], "unit": line["unit"],
                "qty": fmt_qty(amounts["qty"]), "qty_raw": float(amounts["qty"]),
                "price": fmt(amounts["price"]), "price_raw": float(amounts["price"]),
                "discount": fmt(amounts["discount"], 1),
                "discount_raw": float(amounts["discount"]),
                "net": fmt(amounts["net"]), "net_raw": float(amounts["net"]),
                "tax_rate": fmt(amounts["tax_rate"], 0),
                "tax_rate_raw": float(amounts["tax_rate"]),
                "vat": fmt(amounts["vat"]), "vat_raw": float(amounts["vat"]),
                "gross": fmt(amounts["gross"]), "gross_raw": float(amounts["gross"]),
            })
        self.lines.set_rows(rows)

        net, vat, gross = self.repo.totals_of(
            [self.repo.line_amounts(l["qty"], l["price"], l["discount"], l["tax_rate"])
             for l in self.lines_data]
        )
        self.sum_labels["net"].configure(text=fmt(net))
        self.sum_labels["vat"].configure(text=fmt(vat))
        self.sum_labels["gross"].configure(text=fmt(gross))
        self._update_line_buttons()

    def _update_line_buttons(self) -> None:
        state = ["!disabled"] if self.lines.selected_id() is not None else ["disabled"]
        self.btn_edit.state(state)
        self.btn_del.state(state)

    # -------------------------------------------------------------- забелешка
    def _build_note(self) -> None:
        holder = ttk.Frame(self)
        holder.grid(row=2, column=0, sticky="ew", padx=8, pady=4)
        holder.columnconfigure(0, weight=1)

        box = ttk.Labelframe(holder, text="Забелешка", padding=(10, 6, 10, 8))
        box.grid(row=0, column=0, sticky="ew")
        self.note_widget = tk.Text(box, height=2, wrap="word", relief="sunken",
                                   borderwidth=1, font=theme.FONTS["base"])
        self.note_widget.pack(fill="x")
        if self.header_data["note"]:
            self.note_widget.insert("1.0", self.header_data["note"])

        panel = self.build_payments(holder)
        if panel is not None:
            panel.grid(row=0, column=1, sticky="nsew", padx=(8, 0))

        # Поврзаните документи (испратници кај фактурата, фактури кај
        # испратницата…) стојат веднаш до забелешката.
        from ...repo import links
        if self.doc_id and self.print_kind in {**links.SOURCES, **links.TARGETS}:
            from . import links_ui
            links_ui.links_panel(holder, self.print_kind, int(self.doc_id)).grid(
                row=0, column=2, sticky="nsew", padx=(8, 0))

    def build_payments(self, parent):
        """Документите што се плаќаат го покажуваат списокот уплати тука."""
        return None

    # --------------------------------------------------------------- збирови
    def _build_footer(self) -> None:
        footer = ttk.Frame(self, padding=(8, 0, 8, 6))
        footer.grid(row=3, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)

        sums = ttk.Frame(footer)
        sums.grid(row=0, column=1, sticky="e")
        self.sum_labels: dict[str, ttk.Label] = {}
        for index, (key, text) in enumerate((("net", "Основица:"), ("vat", "ДДВ:"),
                                             ("gross", "Вкупно:"))):
            ttk.Label(sums, text=text).grid(row=index, column=0, sticky="e", padx=(0, 10))
            style = "Path.TLabel" if key == "gross" else "TLabel"
            value = ttk.Label(sums, text="0,00", anchor="e", width=14, style=style)
            value.grid(row=index, column=1, sticky="e")
            self.sum_labels[key] = value

        ttk.Label(footer, text=self.save_hint, style="Small.TLabel").grid(
            row=0, column=0, sticky="w")

        buttons = ttk.Frame(self, padding=(8, 0, 8, 10))
        buttons.grid(row=4, column=0, sticky="ew")
        ttk.Button(buttons, text="Откажи", width=12, command=self.cancel).pack(side="right")
        ttk.Button(buttons, text="Зачувај", width=14,
                   command=self.save).pack(side="right", padx=(0, 6))

        # Печатење на ЗАЧУВАНАТА верзија — затоа копчињата ги нема кај нов документ.
        if self.print_kind and self.doc_id:
            ttk.Button(buttons, text="Печати", width=10,
                       command=self.print_document).pack(side="left")
            ttk.Button(buttons, text="PDF", width=8,
                       command=self.pdf_document).pack(side="left", padx=(6, 0))

    def _printable(self) -> bool:
        if not self.doc_id:
            return False
        if self._is_dirty() and not widgets.confirm(
            self, "Има измени што не се зачувани — ќе се печати зачуваната верзија.\n\n"
                  "Да продолжам?", title="Незачувани промени"):
            return False
        return True

    def print_document(self) -> None:
        if self._printable():
            exporting.print_document(self, self.print_kind, int(self.doc_id))

    def pdf_document(self) -> None:
        if self._printable():
            exporting.pdf_document(self, self.print_kind, int(self.doc_id))

    # -------------------------------------------------------------- зачувај
    def save(self) -> None:
        try:
            self._pull_header()
            header = dict(self.header_data)
            header["date"] = parse_date(header["date"])
        except ValueError as exc:
            widgets.error(self, str(exc))
            return
        try:
            new_id = self.repo.save_document(self.doc_id, header, self.lines_data)
        except (ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc), title="Зачувувањето не успеа")
            return
        self.doc_id = new_id
        self.saved = True
        record = self.repo.get(new_id)
        self.app.set_status(f"Зачувано: {self.doc_label} {record['doc_no']}")
        self.destroy()

    def cancel(self) -> None:
        if self._is_dirty() and not widgets.confirm(
            self,
            "Има промени што не се зачувани.\n\nДа се затвори без зачувување?",
            title="Незачувани промени",
        ):
            return
        self.destroy()

    def show(self) -> bool:
        self.wait_window(self)
        return self.saved
