# -*- coding: utf-8 -*-
"""МАТЕРИЈАЛНО → Лагер листа (моментална залиха)."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, fmt_qty, q2
from ...repo import stock, warehouses
from ...util import fmt_date
from .. import widgets
from ..widgets import DataTable, Toolbar
from .base import CrudView

ALL_WAREHOUSES = "сите магацини"

MOVE_COLUMNS = (
    {"key": "date", "text": "Датум", "width": 90},
    {"key": "doc_no", "text": "Документ", "width": 110},
    {"key": "doc_type", "text": "Тип", "width": 110},
    {"key": "qty", "text": "Количина", "width": 90, "anchor": "e", "sort": "num"},
    {"key": "unit_cost", "text": "Цена на чинење", "width": 110, "anchor": "e", "sort": "num"},
    {"key": "value", "text": "Вредност", "width": 110, "anchor": "e", "sort": "num"},
)


class LagerView(CrudView):
    title = "Лагер листа"
    printable_list = True
    subtitle = "моментална залиха по артикл"
    empty_text = "Нема залиха. Внеси приемница за да влезе стока."
    readonly = True

    columns = (
        {"key": "code", "text": "Шифра", "width": 80},
        {"key": "name", "text": "Назив", "width": 250, "stretch": True},
        {"key": "brand_name", "text": "Бренд", "width": 110},
        {"key": "unit", "text": "ЕМ", "width": 50, "anchor": "center"},
        {"key": "qty", "text": "Залиха", "width": 85, "anchor": "e", "sort": "num"},
        {"key": "min_stock", "text": "Минимум", "width": 80, "anchor": "e", "sort": "num"},
        {"key": "avg_cost", "text": "Пр. набавна", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "value", "text": "Вредност", "width": 110, "anchor": "e", "sort": "num"},
        {"key": "price_retail", "text": "МПЦ со ДДВ", "width": 100, "anchor": "e", "sort": "num"},
    )

    # ------------------------------------------------------------- филтри
    def build_filters(self, parent: ttk.Frame) -> None:
        # Магацин: по стандард СИТЕ магацини заедно.
        self.wh_var = tk.StringVar(value=ALL_WAREHOUSES)
        self.wh_combo = ttk.Combobox(parent, textvariable=self.wh_var, state="readonly",
                                     width=20)
        if warehouses.many():
            ttk.Label(parent, text="Магацин:", style="Muted.TLabel").pack(
                side="left", padx=(0, 4))
            self.wh_combo.pack(side="left", padx=(0, 14))
            self.wh_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        self.only_stock = tk.BooleanVar(value=True)
        self.below_min = tk.BooleanVar(value=False)
        ttk.Checkbutton(parent, text="Само со залиха", variable=self.only_stock,
                        command=self.refresh).pack(side="left", padx=(0, 12))
        ttk.Checkbutton(parent, text="Под минимум", variable=self.below_min,
                        command=self.refresh).pack(side="left", padx=(0, 12))

    def extra_buttons(self, toolbar: Toolbar) -> None:
        self.btn_card = toolbar.button("Картица", self.action_card, width=12)

    def update_extra_buttons(self, row: dict | None) -> None:
        button = getattr(self, "btn_card", None)
        if button is not None:
            button.state(["!disabled"] if row is not None else ["disabled"])

    def on_activate(self, rec_id: int) -> None:
        self.action_card()

    def selected_warehouse(self) -> int | None:
        """None = сите магацини заедно."""
        options = getattr(self, "_wh_map", {})
        return options.get(self.wh_var.get()) if hasattr(self, "wh_var") else None

    def on_show(self) -> None:
        if hasattr(self, "wh_combo"):
            self._wh_map = {name: int(wid) for wid, name in warehouses.options()}
            values = [ALL_WAREHOUSES] + list(self._wh_map)
            self.wh_combo.configure(values=values)
            if self.wh_var.get() not in values:
                self.wh_var.set(ALL_WAREHOUSES)
        super().on_show()

    def export_info(self) -> list[str]:
        info = super().export_info()
        info.append("Магацин: " + (self.wh_var.get() if hasattr(self, "wh_var")
                                   else ALL_WAREHOUSES))
        return info

    # -------------------------------------------------------------- податоци
    def fetch(self, search: str) -> list[dict]:
        rows = []
        total_value = D(0)
        for item in stock.lager(
            search,
            warehouse_id=self.selected_warehouse(),
            only_with_stock=bool(getattr(self, "only_stock", None) and self.only_stock.get()),
            only_below_min=bool(getattr(self, "below_min", None) and self.below_min.get()),
        ):
            qty = D(item["qty"] or 0)
            value = q2(item["value"] or 0)
            avg = q2(value / qty) if qty else D(0)
            total_value += value
            below = qty <= D(item["min_stock"] or 0)
            rows.append({
                "id": item["id"],
                "code": item["code"],
                "name": item["name"],
                "brand_name": item["brand_name"],
                "unit": item["unit"],
                "qty": fmt_qty(qty), "qty_raw": float(qty),
                "min_stock": fmt_qty(item["min_stock"]), "min_stock_raw": item["min_stock"],
                "avg_cost": fmt(avg), "avg_cost_raw": float(avg),
                "value": fmt(value), "value_raw": float(value),
                "price_retail": fmt(item["price_retail"]),
                "price_retail_raw": item["price_retail"],
                "_tags": ("vnimanie",) if below else (),
            })
        self.set_subtitle(f"моментална залиха  •  вкупна вредност "
                          f"{fmt(total_value)} ден.")
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['code']} — {row['name']}"

    # --------------------------------------------------------------- картица
    def action_card(self) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        StockCardWindow(self, int(row["id"]), self.describe(row))


class StockCardWindow(tk.Toplevel):
    """Сите движења на еден артикл."""

    def __init__(self, master, item_id: int, title: str):
        super().__init__(master)
        self.title("Картица — " + title)
        self.transient(master.winfo_toplevel())
        self.geometry("760x460")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        head = ttk.Frame(self, padding=(10, 8, 10, 4))
        head.grid(row=0, column=0, sticky="ew")
        ttk.Label(head, text=title, style="Head.TLabel").pack(side="left")
        balance = stock.on_hand(item_id)
        ttk.Label(head, text=f"Залиха: {fmt_qty(balance)}", style="Path.TLabel").pack(side="right")

        table = DataTable(self, MOVE_COLUMNS, height=14)
        table.grid(row=1, column=0, sticky="nsew", padx=10)

        rows = []
        for move in stock.moves(item_id):
            rows.append({
                "id": move["id"],
                "date": fmt_date(move["date"]), "date_raw": move["date"],
                "doc_no": move["doc_no"],
                "doc_type": move["doc_type"],
                "qty": fmt_qty(move["qty"]), "qty_raw": move["qty"],
                "unit_cost": fmt(move["unit_cost"]), "unit_cost_raw": move["unit_cost"],
                "value": fmt(move["value"]), "value_raw": move["value"],
                "_tags": () if float(move["qty"]) > 0 else ("neaktiven",),
            })
        table.set_rows(rows)
        if not rows:
            ttk.Label(self, text="Нема движења за овој артикл.",
                      style="Muted.TLabel").grid(row=1, column=0)

        footer = ttk.Frame(self, padding=(10, 8, 10, 10))
        footer.grid(row=2, column=0, sticky="ew")
        ttk.Button(footer, text="Затвори", width=12, command=self.destroy).pack(side="right")
        self.bind("<Escape>", lambda _e: self.destroy())
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()
