# -*- coding: utf-8 -*-
"""ШИФРАРНИК → Клиенти (купувачи и добавувачи)."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...repo import partners
from .base import CrudView
from .klient_form import KlientWindow

ROLES = [("site", "Сите"), ("kupuvaci", "Купувачи"), ("dobavuvaci", "Добавувачи")]


def new_partner_dialog(master, as_supplier: bool = False) -> int | None:
    """„Нов клиент“ повикан од друг екран. Враќа id на новиот клиент."""
    app = master.winfo_toplevel()
    app = getattr(master, "app", app)
    return KlientWindow(master, app, None, as_supplier=as_supplier).show()


class KlientiView(CrudView):
    title = "Клиенти"
    subtitle = "пребарува по назив, шифра, ЕДБ, град, телефон и е-пошта"
    empty_text = "Нема внесени клиенти."
    search_placeholder = "Барај:"

    columns = (
        {"key": "code", "text": "Шифра", "width": 60},
        {"key": "name", "text": "Назив", "width": 190, "stretch": True},
        {"key": "full_name", "text": "Полн назив", "width": 250},
        {"key": "kind", "text": "Вид", "width": 70},
        {"key": "tax_number", "text": "ЕДБ", "width": 110},
        {"key": "city", "text": "Град", "width": 100},
        {"key": "phone", "text": "Телефон", "width": 105},
        {"key": "contacts", "text": "Контакти", "width": 70, "anchor": "e", "sort": "num"},
        {"key": "role", "text": "Тип", "width": 130},
        {"key": "active", "text": "Активен", "width": 65, "anchor": "center"},
    )

    def build_filters(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Прикажи:", style="Muted.TLabel").pack(side="left", padx=(0, 4))
        self.role_var = tk.StringVar(value="Сите")
        combo = ttk.Combobox(parent, textvariable=self.role_var, state="readonly", width=13,
                             values=[label for _v, label in ROLES])
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

    def _role(self) -> str:
        label = getattr(self, "role_var", None)
        if label is None:
            return "site"
        return next((v for v, text in ROLES if text == label.get()), "site")

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for row in partners.list_all(search, role=self._role()):
            if row["is_customer"] and row["is_supplier"]:
                role = "Купувач + Добавувач"
            elif row["is_supplier"]:
                role = "Добавувач"
            else:
                role = "Купувач"
            count = len(partners.contacts(int(row["id"])))
            rows.append({
                "id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "full_name": row["full_name"],
                "kind": partners.kind_of(row).capitalize(),
                "tax_number": row["tax_number"],
                "city": row["city"],
                "phone": row["phone"],
                "contacts": count or "", "contacts_raw": count,
                "role": role,
                "active": "Да" if row["active"] else "Не",
                "_tags": () if row["active"] else ("neaktiven",),
            })
        return rows

    def describe(self, row: dict) -> str:
        return row["name"]

    def delete_record(self, rec_id: int) -> None:
        partners.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        return KlientWindow(self, self.app, rec_id).show() is not None
