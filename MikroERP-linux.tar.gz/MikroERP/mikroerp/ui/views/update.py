# -*- coding: utf-8 -*-
"""ПОДЕСУВАЊА → Update.

Верзијата, состојбата на базата, **дневникот на промени** (CHANGELOG.md што се
пакува покрај .exe) и **ажурирањето**.

Изворот на новите верзии е вграден (`updater.DEFAULT_SOURCE`) — на екранот нема
што да се поставува. Кој сака друго место или сака да ја изгаси проверката, го
менува `config.ini` → `[update] izvor`; тоа е за посебни случаи, не за секој ден.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ... import updater
from ...db import db
from ...migrations import current_version, target_version
from ...paths import app_dir
from ...version import VERSION
from .. import theme, widgets
from .base import View

CHANGELOG_FILE = "CHANGELOG.md"


def read_changelog() -> str:
    """Дневникот на промени, ако е покрај апликацијата."""
    path = app_dir() / CHANGELOG_FILE
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


class UpdateView(View):
    title = "Update"
    subtitle = "Верзија на апликацијата и што е ново"

    def build(self) -> None:
        self.rowconfigure(2, weight=0)
        self.rowconfigure(3, weight=0)
        self.rowconfigure(4, weight=1)

        box = ttk.Labelframe(self, text="Состојба", padding=(12, 8, 12, 10))
        box.grid(row=2, column=0, sticky="ew")
        box.columnconfigure(1, weight=1)

        self.rows: dict[str, ttk.Label] = {}
        for index, (key, label) in enumerate((
            ("verzija", "Верзија на MikroERP"),
            ("shema", "Верзија на базата"),
            ("baza", "Датотека на базата"),
        )):
            ttk.Label(box, text=label + ":").grid(row=index, column=0, sticky="w",
                                                  padx=(0, 20), pady=3)
            value = ttk.Label(box, text="", style="Path.TLabel")
            value.grid(row=index, column=1, sticky="w", pady=3)
            self.rows[key] = value

        bar = ttk.Frame(box)
        bar.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(10, 0))
        self.btn_check = ttk.Button(bar, text="Провери за нова верзија", width=24,
                                    command=self.check_now)
        self.btn_check.pack(side="left")
        self.btn_get = ttk.Button(bar, text="Симни и ажурирај", width=20,
                                  command=self.download_now)
        self.btn_get.pack(side="left", padx=(6, 0))
        self.btn_get.state(["disabled"])
        self.progress = ttk.Progressbar(bar, length=220, mode="determinate")
        self.state_label = ttk.Label(bar, text="", style="Small.TLabel")
        self.state_label.pack(side="left", padx=(12, 0))

        ttk.Label(
            box,
            text="Ажурирањето ги менува само програмските фајлови.  Папките data, "
                 "backups, logs и config.ini остануваат недопрени, а базата сама се "
                 "надградува при следното стартување, со резервна копија пред тоа.",
            wraplength=760, justify="left", style="Small.TLabel",
        ).grid(row=5, column=0, columnspan=2, sticky="w", pady=(8, 0))

        log = ttk.Labelframe(self, text="Што е ново", padding=(10, 6, 10, 8))
        log.grid(row=4, column=0, sticky="nsew", pady=(10, 0))
        log.columnconfigure(0, weight=1)
        log.rowconfigure(0, weight=1)

        self.text = tk.Text(log, wrap="word", relief="flat", borderwidth=0,
                            padx=6, pady=4, height=12,
                            background=self.winfo_toplevel().cget("background"),
                            font=theme.FONTS["base"], cursor="arrow")
        self.text.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(log, orient="vertical", command=self.text.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.text.configure(yscrollcommand=scroll.set)

        self.text.tag_configure("verzija", font=theme.FONTS["title"],
                                foreground=theme.C["accent"], spacing1=10, spacing3=4)
        self.text.tag_configure("naslov", font=theme.FONTS["bold"], spacing1=6)
        self.text.tag_configure("stavka", lmargin1=14, lmargin2=26)
        self.text.tag_configure("tekovna", foreground=theme.C["ok"])

    def _fill_changelog(self) -> None:
        text = read_changelog()
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        if not text.strip():
            self.text.insert("end", "Дневникот на промени (CHANGELOG.md) не е "
                                    "најден покрај апликацијата.")
            self.text.configure(state="disabled")
            return

        for raw in text.splitlines():
            line = raw.rstrip()
            if line.startswith("# "):
                continue                       # насловот на фајлот е веќе горе
            if line.startswith("## "):
                head = line[3:].strip()
                current = head.startswith(VERSION + " ")
                self.text.insert("end", head + ("   ← оваа верзија" if current else "")
                                 + "\n", ("verzija", "tekovna") if current else "verzija")
            elif line.startswith("**") and line.endswith("**"):
                self.text.insert("end", line.strip("*") + "\n", "naslov")
            elif line.startswith("- "):
                self.text.insert("end", "•  " + _plain(line[2:].strip()) + "\n", "stavka")
            elif line.startswith("  ") and line.strip():
                self.text.insert("end", "   " + _plain(line.strip()) + "\n", "stavka")
            elif line.startswith("|"):
                if set(line) <= set("|-: "):
                    continue               # линијата под заглавието на табела
                self.text.insert("end", "   " + _plain(line.strip("|").replace("|", " · "))
                                 + "\n", "stavka")
            else:
                self.text.insert("end", _plain(line) + "\n")
        self.text.configure(state="disabled")
        self.text.see("1.0")

    # -------------------------------------------------------- ново издание
    def check_now(self) -> None:
        if not updater.enabled():
            widgets.info(
                self,
                "Проверката за нова верзија е исклучена во config.ini "
                "([update] izvor).",
                title="Исклучено")
            return
        self.found = None
        self.btn_get.state(["disabled"])
        self.state_label.configure(text="Се проверува…", foreground=theme.C["muted"])
        self.update_idletasks()
        try:
            release = widgets.run_with_progress(
                self, "Проверка за нова верзија", updater.check,
                message="Се проверува кај " + updater.source())
        except updater.UpdateError as exc:
            self.state_label.configure(text="", foreground=theme.C["muted"])
            widgets.error(self, str(exc), title="Проверка")
            return
        except Exception as exc:  # noqa: BLE001
            self.state_label.configure(text="")
            widgets.error(self, f"Проверката не успеа:\n{exc}", title="Проверка")
            return
        self._show_release(release)

    def _show_release(self, release) -> None:
        if release is None:
            self.state_label.configure(text="")
            return
        if not release.newer:
            self.state_label.configure(
                text=f"Имаш најнова верзија ({VERSION}).", foreground=theme.C["ok"])
            return
        self.found = release
        size = f" · {release.size / 1024 / 1024:.1f} MB" if release.size else ""
        self.state_label.configure(text=f"Има нова верзија {release.version}{size}",
                                   foreground=theme.C["warn"])
        self.btn_get.state(["!disabled"])
        if release.notes:
            self.text.configure(state="normal")
            self.text.insert("1.0", f"НОВО ИЗДАНИЕ {release.version}\n"
                                    f"{release.notes}\n\n", "verzija")
            self.text.configure(state="disabled")

    def download_now(self) -> None:
        release = getattr(self, "found", None)
        if release is None:
            return
        ok, reason = updater.can_apply()
        if not ok and not widgets.confirm(
            self, f"{reason}\n\nДа се симне ZIP-от за рачно отпакување?",
            title="Ажурирање",
        ):
            return

        self.btn_get.state(["disabled"])
        self.progress.pack(side="left", padx=(12, 0))
        self.progress.configure(value=0, maximum=100)

        def report(done: int, total: int) -> None:
            self.progress.configure(value=(done * 100 // total) if total else 0)
            self.state_label.configure(
                text=f"Се симнува… {done / 1024 / 1024:.1f} MB")
            self.update_idletasks()

        try:
            archive = updater.download(release, report)
        except updater.UpdateError as exc:
            self.progress.pack_forget()
            self.state_label.configure(text="")
            widgets.error(self, str(exc), title="Преземање")
            return
        self.progress.pack_forget()

        if not ok:
            self.state_label.configure(text="Симнато: " + str(archive),
                                       foreground=theme.C["ok"])
            from ..exporting import open_file
            open_file(archive.parent)
            return

        try:
            folder = updater.unpack(archive)
        except updater.UpdateError as exc:
            widgets.error(self, str(exc), title="Ажурирање")
            return

        if not widgets.confirm(
            self,
            f"Симната е верзија {release.version}.\n\n"
            "Апликацијата ќе се затвори, ќе се замени и ќе се отвори повторно "
            "за неколку секунди.\n\nПодатоците не се пипаат. Да продолжам?",
            title="Ажурирање",
        ):
            return
        try:
            updater.apply(folder)
        except updater.UpdateError as exc:
            widgets.error(self, str(exc), title="Ажурирање")
            return
        self.app.set_status("Се ажурира…")
        self.after(200, self.winfo_toplevel().destroy)

    def on_show(self) -> None:
        self.rows["verzija"].configure(text=VERSION)
        self.rows["shema"].configure(
            text=f"{current_version(db())} од {target_version()}"
        )
        self.rows["baza"].configure(text=str(db().path))
        self._fill_changelog()
        self.found = None
        self.btn_get.state(["disabled"])
        self.state_label.configure(text="", foreground=theme.C["muted"])


def _plain(text: str) -> str:
    """Markdown ознаките не се прикажуваат како знаци."""
    return text.replace("**", "").replace("`", "")
