# -*- coding: utf-8 -*-
"""Основни класи за екраните.

`View`     — заедничка рамка со наслов.
`CrudView` — готов екран „листа + Нов/Измени/Избриши“; конкретните екрани
             (Артикли, Клиенти, Брендови) само кажуваат КОИ колони и КОЈА
             форма, а сето останато (пребарување, сортирање, кратенки,
             потврди, освежување) е тука.
"""

from __future__ import annotations

from tkinter import ttk
from typing import Sequence

from .. import exporting, widgets
from ..widgets import DataTable, SearchBox, Toolbar


class View(ttk.Frame):
    title = ""
    subtitle = ""

    def __init__(self, master, app):
        super().__init__(master)
        self.app = app
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        self.head = ttk.Frame(self)
        self.head.grid(row=0, column=0, sticky="ew", pady=(0, 2))
        self.title_label = ttk.Label(self.head, text=self.title, style="Title.TLabel")
        self.title_label.pack(side="left")
        self.subtitle_label = ttk.Label(self.head, text=self.subtitle, style="Muted.TLabel")
        self.subtitle_label.pack(side="left", padx=(10, 0))
        self.head_right = ttk.Frame(self.head)
        self.head_right.pack(side="right")

        ttk.Separator(self).grid(row=1, column=0, sticky="ew", pady=(4, 8))
        self.build()

    def build(self) -> None:
        """Се повикува еднаш при креирање на екранот."""

    def on_show(self) -> None:
        """Се повикува секој пат кога екранот се прикажува."""

    def set_subtitle(self, text: str) -> None:
        self.subtitle_label.configure(text=text)

    def status(self, text: str) -> None:
        self.app.set_status(text)


class CrudView(View):
    """Листа со стандардни операции."""

    columns: Sequence[dict] = ()
    empty_text = "Нема записи. Кликни „Нов“ за да додадеш."
    search_placeholder = "Барај:"
    readonly = False          # True = листа само за преглед (без Нов/Измени/Избриши)
    new_text = "Нов"

    # Печатење и извоз
    print_kind = ""           # вид документ (docprint.KINDS) → Печати / PDF
    printable_list = False    # листата може да се испечати каква што е
    exportable = True         # копче „Excel“ за тековната листа

    # ------------------------------------------------------- за преклопување
    def fetch(self, search: str) -> list[dict]:
        raise NotImplementedError

    def open_form(self, rec_id: int | None) -> bool:
        """Отвора форма за нов (rec_id=None) или постоечки запис.
        Враќа True ако е зачувано."""
        raise NotImplementedError

    def delete_record(self, rec_id: int) -> None:
        raise NotImplementedError

    def can_delete(self, row: dict) -> str:
        """Врати текст со причина ако бришењето не е дозволено, инаку ''."""
        return ""

    def describe(self, row: dict) -> str:
        return row.get("name", str(row.get("id", "")))

    def delete_warning(self, row: dict) -> str:
        """Што уште ќе се промени со бришењето — се додава во потврдата."""
        return ""

    def build_filters(self, parent: ttk.Frame) -> None:
        """Место за дополнителни филтри лево од пребарувањето."""

    def extra_buttons(self, toolbar: Toolbar) -> None:
        """Дополнителни копчиња десно од стандардните (пр. Проведи)."""

    def on_activate(self, rec_id: int) -> None:
        """Двоен клик / Enter врз ред. Стандардно отвора форма за измена."""
        self.action_edit()

    # ------------------------------------------------------------ изградба
    def build(self) -> None:
        self.count_label = ttk.Label(self.head_right, text="", style="Muted.TLabel")
        self.count_label.pack(side="right")

        bar = ttk.Frame(self)
        bar.grid(row=2, column=0, sticky="ew", pady=(0, 6))

        self.toolbar = Toolbar(bar)
        self.toolbar.pack(side="left")
        self.btn_edit = self.btn_delete = None
        if not self.readonly:
            self.toolbar.button(self.new_text, self.action_new, width=10)
            self.btn_edit = self.toolbar.button("Измени", self.action_edit, width=10)
            self.btn_delete = self.toolbar.button("Избриши", self.action_delete, width=10)
        self.toolbar.button("Освежи", self.refresh, width=10)
        self.extra_buttons(self.toolbar)
        self._build_print_buttons()

        # Пребарувањето стои веднаш до копчињата (лево), не на другиот крај.
        self.search = SearchBox(bar, on_change=lambda _t: self.refresh(),
                                placeholder=self.search_placeholder)
        self.search.pack(side="left", padx=(10, 0))
        self.filters = ttk.Frame(bar)
        self.filters.pack(side="left", padx=(16, 0))
        self.build_filters(self.filters)

        holder = ttk.Frame(self)
        holder.grid(row=3, column=0, sticky="nsew")
        holder.columnconfigure(0, weight=1)
        holder.rowconfigure(0, weight=1)
        self.rowconfigure(2, weight=0)
        self.rowconfigure(3, weight=1)

        self.table = DataTable(holder, self.columns, on_activate=self.on_activate,
                               on_select=lambda _id: self._update_buttons())
        self.table.grid(row=0, column=0, sticky="nsew")

        self.empty_label = ttk.Label(holder, text=self.empty_text, style="Muted.TLabel")

        hint = ("F5 освежи      Ctrl+F барај" if self.readonly else
                "Ctrl+N нов      F2 измени      Delete бриши      F5 освежи      Ctrl+F барај")
        ttk.Label(self, text="Кратенки:   " + hint, style="Small.TLabel").grid(
            row=4, column=0, sticky="w", pady=(6, 4))

        self._bind_keys()
        self._update_buttons()

    # ------------------------------------------------- печатење и извоз
    def _build_print_buttons(self) -> None:
        """Печати/PDF одат на избраниот документ, Excel на целата листа."""
        self.doc_buttons: list[ttk.Button] = []
        if self.print_kind or self.printable_list or self.exportable:
            self.toolbar.separator()
        if self.print_kind:
            self.doc_buttons.append(
                self.toolbar.button("Печати", self.action_print, width=10))
            self.doc_buttons.append(
                self.toolbar.button("PDF", self.action_pdf, width=8))
        elif self.printable_list:
            self.toolbar.button("Печати", self.action_print_list, width=10)
        if self.exportable:
            self.toolbar.button("Excel", self.action_excel, width=8)

    def export_info(self) -> list[str]:
        """Редови со контекст (филтри, период) што одат над табелата."""
        info = []
        if getattr(self, "search", None) and self.search.get().strip():
            info.append("Барање: " + self.search.get().strip())
        return info

    def export_rows(self) -> list[dict]:
        return list(self.table._rows)

    def action_excel(self, *_a) -> None:
        exporting.export_rows(self, self.columns, self.export_rows(),
                              self.title, self.export_info())

    def action_print_list(self, *_a) -> None:
        exporting.print_rows(self, self.columns, self.export_rows(),
                             self.title, self.export_info())

    def _selected_for_print(self) -> int | None:
        rec_id = self.table.selected_id()
        if rec_id is None:
            widgets.info(self, "Прво избери документ во листата.")
            return None
        return int(rec_id)

    def action_print(self, *_a) -> None:
        rec_id = self._selected_for_print()
        if rec_id is not None:
            exporting.print_document(self, self.print_kind, rec_id)

    def action_pdf(self, *_a) -> None:
        rec_id = self._selected_for_print()
        if rec_id is not None:
            exporting.pdf_document(self, self.print_kind, rec_id)

    def _bind_keys(self) -> None:
        # Кратенките се врзуваат на прозорецот, но реагираат само кога
        # ОВОЈ екран е видлив (види `_if_visible`).
        top = self.winfo_toplevel()
        if not self.readonly:
            self.table.tree.bind("<Delete>", lambda _e: self.action_delete())
            self.table.tree.bind("<F2>", lambda _e: self.action_edit())
            top.bind("<Control-n>", self._if_visible(self.action_new), add="+")
            top.bind("<Control-N>", self._if_visible(self.action_new), add="+")
        top.bind("<F5>", self._if_visible(self.refresh), add="+")
        top.bind("<Control-f>", self._if_visible(lambda: self.search.focus()), add="+")
        top.bind("<Control-F>", self._if_visible(lambda: self.search.focus()), add="+")

    def _if_visible(self, func):
        def handler(_event=None):
            if self.winfo_ismapped():
                func()
                return "break"
            return None
        return handler

    # ------------------------------------------------------------- дејства
    def on_show(self) -> None:
        self.refresh()

    def refresh(self, *_a) -> None:
        try:
            rows = self.fetch(self.search.get())
        except Exception as exc:  # noqa: BLE001 — екранот не смее да ја сруши апликацијата
            widgets.error(self, f"Не можат да се вчитаат податоците:\n{exc}")
            rows = []
        self.table.set_rows(rows)
        total = len(rows)
        self.count_label.configure(text=f"{total} запис(и)")
        if total == 0:
            self.empty_label.place(relx=0.5, rely=0.45, anchor="center")
        else:
            self.empty_label.place_forget()
        self._update_buttons()

    def _update_buttons(self, *_a) -> None:
        state = ["!disabled"] if self.table.selected_id() is not None else ["disabled"]
        for button in (self.btn_edit, self.btn_delete):
            if button is not None:
                button.state(state)
        for button in getattr(self, "doc_buttons", ()):
            button.state(state)
        self.update_extra_buttons(self.table.selected_row())

    def update_extra_buttons(self, row: dict | None) -> None:
        """Овде подкласите ги вклучуваат/исклучуваат своите копчиња."""

    def action_new(self, *_a) -> None:
        if self.open_form(None):
            self.refresh()

    def action_edit(self, *_a) -> None:
        rec_id = self.table.selected_id()
        if rec_id is None:
            return
        if self.open_form(rec_id):
            self.refresh()

    def action_delete(self, *_a) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        reason = self.can_delete(row)
        if reason:
            widgets.info(self, reason, title="Бришењето не е можно")
            return
        warning = self.delete_warning(row)
        if not widgets.confirm(self, f"Дали да се избрише „{self.describe(row)}“?\n\n"
                                     + (warning + "\n\n" if warning else "")
                                     + "Ова дејство е неповратно."):
            return
        try:
            self.delete_record(int(row["id"]))
        except Exception as exc:  # noqa: BLE001
            widgets.error(self, f"Записот не може да се избрише:\n{exc}")
            return
        self.status(f"Избришано: {self.describe(row)}")
        self.refresh()


class PlaceholderView(View):
    """Екран што сè уште не е изработен."""

    def __init__(self, master, app, title: str, note: str = ""):
        self.title = title
        self._note = note
        super().__init__(master, app)

    def build(self) -> None:
        box = ttk.Labelframe(self, text="Во изработка", padding=20)
        box.grid(row=2, column=0, sticky="new")
        text = self._note or "Овој модул ќе биде додаден во следен update на апликацијата."
        ttk.Label(box, text=text, wraplength=620, justify="left").pack(anchor="w")
        self.rowconfigure(2, weight=1)
