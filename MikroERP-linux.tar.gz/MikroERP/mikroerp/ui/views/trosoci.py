# -*- coding: utf-8 -*-
"""ИЗВЕШТАИ → Трошоци.

Тука се и рачно внесените трошоци и оние што сами се создале од изводите
(банкарски провизии и слични одливи без фактура).
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, q2
from ...repo import expenses, partners, payments
from ...util import fmt_date, parse_date, today
from .. import theme
from ..widgets import Field, FormDialog
from .base import CrudView


def expense_fields(with_partner: bool = True) -> list[Field]:
    partner_options = [("", "—")] + [(str(i), n) for i, n in partners.options(role="site")]
    fields = [
        Field("date", "Датум", col=3, chars=12, required=True),
        Field("category", "Категорија", kind="combo_edit", col=5, chars=26,
              values=expenses.categories(), required=True),
        Field("vat_rate", "ДДВ %", kind="combo", col=2, chars=6,
              values=expenses.VAT_RATES, help="празно = без ДДВ"),
        Field("amount", "Износ (со ДДВ)", kind="money", col=2, chars=13, required=True),
        Field("description", "Опис", col=12),
    ]
    if with_partner:
        fields.append(Field("partner_id", "Клиент (по потреба)", kind="picker", col=6,
                            values=partner_options, chars=28))
    fields.append(Field("note", "Забелешка", kind="memo", col=12, height=2))
    return fields


def expense_values(record=None) -> dict:
    if record is None:
        blank = expenses.blank(today())
        blank["date"] = fmt_date(blank["date"])
        blank["vat_rate"] = "0"
        return blank
    values = dict(record)
    values["date"] = fmt_date(record["date"])
    values["vat_rate"] = fmt(record["vat_rate"], 0)
    values["partner_id"] = str(record["partner_id"] or "")
    return values


class TrosociView(CrudView):
    title = "Трошоци"
    printable_list = True
    subtitle = "рачно внесени и автоматски создадени од изводите"
    empty_text = "Нема трошоци."
    new_text = "Нов"

    columns = (
        {"key": "doc_no", "text": "Број", "width": 90},
        {"key": "date", "text": "Датум", "width": 85},
        {"key": "category", "text": "Категорија", "width": 165},
        {"key": "description", "text": "Опис", "width": 240, "stretch": True},
        {"key": "partner_name", "text": "Клиент", "width": 150},
        {"key": "net", "text": "Без ДДВ", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "vat_rate", "text": "ДДВ %", "width": 55, "anchor": "e", "sort": "num"},
        {"key": "amount", "text": "Со ДДВ", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "paid", "text": "Платено", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "source", "text": "Извор", "width": 65},
    )

    def build_filters(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Категорија:", style="Muted.TLabel").pack(side="left", padx=(0, 4))
        self.cat_var = tk.StringVar(value="Сите")
        self.cat_combo = ttk.Combobox(parent, textvariable=self.cat_var, state="readonly",
                                      width=22)
        self.cat_combo.pack(side="left")
        self.cat_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        # Трошок создаден од извод што повеќе го нема — останал сам.
        self.orphan_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(parent, text="само осамени од извод", variable=self.orphan_var,
                        command=self.refresh).pack(side="left", padx=(14, 0))

    def on_show(self) -> None:
        values = ["Сите"] + expenses.categories()
        self.cat_combo.configure(values=values)
        if self.cat_var.get() not in values:
            self.cat_var.set("Сите")
        super().on_show()

    def fetch(self, search: str) -> list[dict]:
        category = "" if not hasattr(self, "cat_var") or self.cat_var.get() == "Сите" \
            else self.cat_var.get()
        orphans = bool(getattr(self, "orphan_var", None) and self.orphan_var.get())
        paid_map = payments.paid_map(payments.KIND_EXPENSE)
        rows = []
        total = D(0)
        alone = 0
        for rec in expenses.list_all(search, category=category, orphans_only=orphans):
            amount = q2(rec["amount"])
            total += amount
            done = paid_map.get(int(rec["id"]), D(0))
            lonely = rec["source"] == expenses.SOURCE_BANK and not rec["linked"]
            alone += 1 if lonely else 0
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "category": rec["category"],
                "description": rec["description"],
                "partner_name": rec["partner_name"],
                "net": fmt(rec["net"]), "net_raw": rec["net"],
                "vat_rate": fmt(rec["vat_rate"], 0), "vat_rate_raw": rec["vat_rate"],
                "amount": fmt(amount), "amount_raw": float(amount),
                "paid": fmt(done) if done else "", "paid_raw": float(done),
                "source": "извод (сам)" if lonely else rec["source"],
                "_tags": ("vnimanie",) if lonely else
                         (("neaktiven",) if rec["source"] == expenses.SOURCE_BANK else ()),
            })
        text = f"рачни и автоматски од изводите  •  вкупно {fmt(total)} ден."
        if alone:
            text += (f"  •  {alone} без свој извод — изводот е избришан, "
                     "трошокот останал")
        self.set_subtitle(text)
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['doc_no']} — {row['description'] or row['category']}"

    def delete_record(self, rec_id: int) -> None:
        expenses.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        record = expenses.get(rec_id) if rec_id else None

        def save(data: dict):
            payload = dict(data)
            payload["date"] = parse_date(data.get("date"))
            payload["source"] = record["source"] if record else expenses.SOURCE_MANUAL
            new_id = expenses.save_document(rec_id, payload)
            self.status("Зачуван трошок.")
            return new_id

        title = "Нов трошок" if not rec_id else f"Трошок — {record['doc_no']}"
        return FormDialog(self, title, expense_fields(), expense_values(record),
                          on_save=save, width=760).show() is not None
