# -*- coding: utf-8 -*-
"""ПОДЕСУВАЊА → Магацини."""

from __future__ import annotations

from ...repo import warehouses
from ..widgets import Field, FormDialog
from .base import CrudView


class MagaciniView(CrudView):
    title = "Магацини"
    subtitle = "изборот на магацин се појавува во документите штом има повеќе од еден"
    empty_text = "Нема магацини."

    columns = (
        {"key": "code", "text": "Шифра", "width": 70},
        {"key": "name", "text": "Назив", "width": 220, "stretch": True},
        {"key": "address", "text": "Адреса", "width": 240},
        {"key": "is_default", "text": "Стандарден", "width": 95, "anchor": "center"},
        {"key": "moves", "text": "Движења", "width": 85, "anchor": "e", "sort": "num"},
        {"key": "active", "text": "Активен", "width": 70, "anchor": "center"},
    )

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for row in warehouses.list_all():
            if search.strip() and search.strip().lower() not in (
                    row["name"] + " " + row["code"] + " " + row["address"]).lower():
                continue
            moves = warehouses.usage(int(row["id"]))
            rows.append({
                "id": row["id"],
                "code": row["code"],
                "name": row["name"],
                "address": row["address"],
                "is_default": "Да" if row["is_default"] else "",
                "moves": moves, "moves_raw": moves,
                "active": "Да" if row["active"] else "Не",
                "_tags": () if row["active"] else ("neaktiven",),
            })
        return rows

    def describe(self, row: dict) -> str:
        return row["name"]

    def delete_record(self, rec_id: int) -> None:
        warehouses.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        record = warehouses.get(rec_id) if rec_id else None
        values = dict(record) if record else {"active": True, "is_default": False}

        fields = [
            Field("code", "Шифра", col=2, chars=8),
            Field("name", "Назив", col=10, required=True),
            Field("address", "Адреса", col=12),
            Field("sep", "", kind="sep"),
            Field("is_default", "Стандарден магацин", kind="check", col=5),
            Field("active", "Активен", kind="check", col=4),
            Field("note", "Забелешка", kind="memo", col=12, height=2),
        ]

        def save(data: dict):
            if rec_id:
                warehouses.update(rec_id, data)
            else:
                warehouses.create(data)
            self.status("Зачуван магацин: " + data["name"])
            return True

        title = "Нов магацин" if not rec_id else f"Магацин — {values.get('name', '')}"
        return FormDialog(self, title, fields, values, on_save=save, width=620).show() is not None
