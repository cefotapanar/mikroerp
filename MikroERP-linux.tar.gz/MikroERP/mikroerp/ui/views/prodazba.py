# -*- coding: utf-8 -*-
"""ФАКТУРИ → Профактури и Излезни фактури.

Двата екрана се исти по форма и се разликуваат само во видот на документот,
затоа делат основа и тука.
"""

from __future__ import annotations

from datetime import date

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, q2
from ...repo import issues, links, payments, reversals, sales
from ...util import fmt_date, parse_date
from .. import theme, widgets
from ..widgets import DataTable, Toolbar
from .base import CrudView
from .doc_window import DocumentWindow

ALL = "Сите"

PAYMENT_COLUMNS = (
    {"key": "date", "text": "Датум", "width": 90},
    {"key": "statement_no", "text": "Извод", "width": 80},
    {"key": "amount", "text": "Износ", "width": 110, "anchor": "e", "sort": "num"},
)


def payments_window(parent, title: str, kind: str, doc_id: int, total) -> None:
    """Мал прозорец „Уплати“ за еден документ."""
    window = tk.Toplevel(parent)
    window.title("Уплати — " + title)
    window.transient(parent.winfo_toplevel())
    window.geometry("440x320")
    payments_panel(window, kind, doc_id, total).pack(fill="both", expand=True,
                                                     padx=10, pady=10)
    ttk.Button(window, text="Затвори", width=12, command=window.destroy).pack(
        side="right", padx=10, pady=(0, 10))
    window.bind("<Escape>", lambda _e: window.destroy())
    widgets.center_on(window, parent.winfo_toplevel())
    window.grab_set()
    parent.wait_window(window)


def payments_panel(parent, kind: str, doc_id: int, total) -> ttk.Frame:
    """Список на уплати со состојба на плаќање."""
    box = ttk.Labelframe(parent, text="Уплати", padding=(10, 6, 10, 8))
    rows = payments.for_target(kind, doc_id) if doc_id else []
    done = payments.paid(kind, doc_id) if doc_id else D(0)
    state = payments.status(total, done)

    head = ttk.Frame(box)
    head.pack(fill="x")
    ttk.Label(head, text=f"Платено: {fmt(done)}   ·   Останува: "
                         f"{fmt(q2(D(total) - done))}").pack(side="left")
    ttk.Label(head, text=state.upper(), style="Head.TLabel",
              foreground=theme.C["ok"] if state == "платена" else
              (theme.C["warn"] if state == "делумно" else theme.C["muted"])).pack(
        side="left", padx=(12, 0))

    if rows:
        table = DataTable(box, PAYMENT_COLUMNS, height=min(len(rows), 4))
        table.pack(fill="x", pady=(6, 0))
        table.set_rows([{
            "id": index, "date": fmt_date(row["date"] or row["statement_date"]),
            "statement_no": row["statement_no"],
            "amount": fmt(row["amount"]), "amount_raw": row["amount"],
        } for index, row in enumerate(rows)])
    else:
        ttk.Label(box, text="Нема евидентирани уплати.", style="Small.TLabel").pack(
            anchor="w", pady=(6, 0))
    return box


class SalesWindow(DocumentWindow):
    partner_label = "Купувач"
    due_label = "Рок на плаќање"
    doc_kind = sales.KIND_INVOICE

    def default_price(self, item_row):
        """Се нуди партнерската цена без ДДВ; ако ја нема — МПЦ без ДДВ."""
        return item_row["price_partner"] or item_row["price_retail_net"]

    def build_header_extra(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text=self.due_label + ":").pack(side="left")
        self.due_var = tk.StringVar(value=fmt_date(self.header_data.get("due_date")))
        ttk.Entry(parent, textvariable=self.due_var, width=11).pack(side="left", padx=(4, 16))

        # Класификација: слободен текст, но паѓачкото мени ги нуди веќе
        # користените — така поделбата останува иста од фактура во фактура.
        ttk.Label(parent, text="Класификација:").pack(side="left")
        self.classification_var = tk.StringVar(
            value=self.header_data.get("classification") or "")
        ttk.Combobox(parent, textvariable=self.classification_var, width=24,
                     values=sales.classifications(self.doc_kind)).pack(
            side="left", padx=(4, 16))

        linked = self.header_data.get("issue_id")
        if linked:
            from ...repo import issues
            issue = issues.get(int(linked))
            ttk.Label(parent, text=f"По испратница {issue['doc_no']} — "
                                   "стоката веќе е издадена",
                      style="Muted.TLabel").pack(side="left")

    def pull_header_extra(self) -> None:
        self.header_data["due_date"] = self._norm_date(self.due_var.get())
        self.header_data["classification"] = self.classification_var.get().strip()


class ProfakturaWindow(SalesWindow):
    doc_label = "Профактура"
    due_label = "Важи до"
    save_hint = "Профактурата е понуда — не ја движи залихата."
    repo = sales.SalesApi(sales.KIND_PROFORMA)
    print_kind = "profaktura"
    doc_kind = sales.KIND_PROFORMA


class FakturaWindow(SalesWindow):
    doc_label = "Излезна фактура"
    save_hint = "Со зачувување стоката излегува од магацин по FIFO."
    repo = sales.SalesApi(sales.KIND_INVOICE)
    print_kind = "faktura"

    def __init__(self, master, app, doc_id=None):
        super().__init__(master, app, doc_id)
        if self.header_data.get("issue_id"):
            self.save_hint = "Стоката веќе излегла со испратницата."

    def build_payments(self, parent):
        if not self.doc_id:
            return None
        record = sales.get(self.doc_id)
        if record is None:
            return None
        return payments_panel(parent, payments.KIND_SALES, self.doc_id,
                              record["total_gross"])


class SalesListView(CrudView):
    """Заедничка листа за профактури и фактури."""

    kind = sales.KIND_INVOICE
    window = FakturaWindow
    show_profit = True
    new_text = "Нова"

    base_columns = (
        {"key": "doc_no", "text": "Број", "width": 90},
        {"key": "date", "text": "Датум", "width": 80},
        {"key": "due_date", "text": "Рок", "width": 80},
        {"key": "partner_name", "text": "Купувач", "width": 175, "stretch": True},
        {"key": "lines_count", "text": "Ставки", "width": 55, "anchor": "e", "sort": "num"},
        {"key": "total_net", "text": "Основица", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "total_vat", "text": "ДДВ", "width": 80, "anchor": "e", "sort": "num"},
        {"key": "total_gross", "text": "Вкупно", "width": 95, "anchor": "e", "sort": "num"},
    )
    profit_columns = (
        {"key": "total_cost", "text": "Чинење", "width": 85, "anchor": "e", "sort": "num"},
        {"key": "gain", "text": "Заработка", "width": 85, "anchor": "e", "sort": "num"},
    )
    payment_columns = (
        {"key": "paid", "text": "Платено", "width": 90, "anchor": "e", "sort": "num"},
        {"key": "remaining", "text": "Останува", "width": 90, "anchor": "e", "sort": "num"},
        {"key": "pay_status", "text": "Состојба", "width": 85},
    )
    link_column = {"key": "link", "text": "Врска", "width": 95}
    issues_column = {"key": "issues", "text": "Испратници", "width": 130}
    class_column = {"key": "classification", "text": "Класификација", "width": 130}
    storno_column = {"key": "storno", "text": "Сторно", "width": 110}

    def __init__(self, master, app):
        self.columns = (self.base_columns
                        + (self.profit_columns if self.show_profit else ())
                        + (self.payment_columns if self.show_profit else ())
                        + ((self.storno_column,) if self.show_profit else ())
                        + ((self.class_column,) if self.show_profit else ())
                        + ((self.issues_column,) if self.show_profit else ())
                        + (self.link_column,))
        super().__init__(master, app)

    def build_filters(self, parent: ttk.Frame) -> None:
        if not self.show_profit:
            return
        ttk.Label(parent, text="Состојба:", style="Muted.TLabel").pack(side="left", padx=(0, 4))
        self.state_var = tk.StringVar(value="Сите")
        combo = ttk.Combobox(parent, textvariable=self.state_var, state="readonly", width=12,
                             values=["Сите", "неплатена", "делумно", "платена"])
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        ttk.Label(parent, text="Класификација:", style="Muted.TLabel").pack(
            side="left", padx=(14, 4))
        self.class_var = tk.StringVar(value=ALL)
        self.class_combo = ttk.Combobox(parent, textvariable=self.class_var,
                                        state="readonly", width=18)
        self.class_combo.pack(side="left")
        self.class_combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        # Период: по стандард од 1 јануари оваа година до денес.
        ttk.Label(parent, text="Од:", style="Muted.TLabel").pack(side="left", padx=(14, 4))
        self.from_var = tk.StringVar(value=fmt_date(f"{date.today().year}-01-01"))
        ttk.Entry(parent, textvariable=self.from_var, width=11).pack(side="left")
        ttk.Label(parent, text="До:", style="Muted.TLabel").pack(side="left", padx=(8, 4))
        self.to_var = tk.StringVar(value=fmt_date(date.today().isoformat()))
        ttk.Entry(parent, textvariable=self.to_var, width=11).pack(side="left")
        ttk.Button(parent, text="Прикажи", width=10,
                   command=self.refresh).pack(side="left", padx=(6, 0))
        ttk.Button(parent, text="Цела историја", width=15,
                   command=self.clear_period).pack(side="left", padx=(4, 0))

    def clear_period(self) -> None:
        self.from_var.set("")
        self.to_var.set("")
        self.refresh()

    def _period(self) -> tuple[str, str]:
        """(од, до) во ISO; празно значи без граница."""
        out = []
        for var in (getattr(self, "from_var", None), getattr(self, "to_var", None)):
            text = var.get().strip() if var is not None else ""
            try:
                out.append(parse_date(text) if text else "")
            except ValueError:
                out.append("")
        return (out + ["", ""])[:2]

    def on_show(self) -> None:
        if hasattr(self, "class_combo"):
            values = [ALL] + sales.classifications(self.kind)
            self.class_combo.configure(values=values)
            if self.class_var.get() not in values:
                self.class_var.set(ALL)
        super().on_show()

    def export_info(self) -> list[str]:
        info = super().export_info()
        date_from, date_to = self._period()
        if date_from or date_to:
            info.append("Период: " + " – ".join(fmt_date(x) if x else "…"
                                                for x in (date_from, date_to)))
        if getattr(self, "class_var", None) and self.class_var.get() != ALL:
            info.append("Класификација: " + self.class_var.get())
        return info

    def extra_buttons(self, toolbar: Toolbar) -> None:
        if self.show_profit:
            self.btn_pay = toolbar.button("Уплати", self.action_payments, width=12)
            self.btn_storno = toolbar.button("Сторнирај", self.action_storno, width=13)

    def update_extra_buttons(self, row: dict | None) -> None:
        button = getattr(self, "btn_pay", None)
        if button is not None:
            button.state(["!disabled"] if row is not None else ["disabled"])
        storno = getattr(self, "btn_storno", None)
        if storno is not None:
            # Сторно има смисла само на обична фактура што сè уште не е сторнирана.
            ok = bool(row) and not row.get("_is_storno") and not row.get("_stornirana")
            storno.state(["!disabled"] if ok else ["disabled"])

    def action_payments(self) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        record = sales.get(int(row["id"]))
        if record is None:
            return
        payments_window(self, record["doc_no"], payments.KIND_SALES,
                        int(row["id"]), record["total_gross"])
        self.refresh()

    def action_storno(self) -> None:
        """Сторно на фактурата, и по потреба повратница за испратниците."""
        row = self.table.selected_row()
        if row is None:
            return
        record = sales.get(int(row["id"]))
        if record is None:
            return
        if not widgets.confirm(
            self,
            f"Да се сторнира фактурата {row['doc_no']}?\n\n"
            "Се прави нова фактура — огледало со негативни износи. "
            "Оригиналот останува, а ефектот се поништува."
            + ("\n\nСтоката се враќа на залиха." if record["moves_stock"]
               else ""),
            title="Сторнирај",
        ):
            return
        try:
            new_id = reversals.storno_invoice(int(row["id"]))
        except (reversals.ReversalError, ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc), title="Сторно")
            return
        storno = sales.get(new_id)
        self.status(f"Направено сторно {storno['doc_no']} на {row['doc_no']}.")

        # Ако фактурата покрива испратници, стоката излегла со нив — тогаш
        # враќањето оди со повратница, не со сторното.
        napraveni = []
        for item in reversals.issues_of_invoice(int(row["id"])):
            if reversals.return_of(int(item["id"])) is not None:
                continue
            if not widgets.confirm(
                self,
                f"Фактурата ја покрива испратницата {item['doc_no']}.\n\n"
                "Да се направи повратница за неа? Стоката се враќа на "
                "залиха по цената по која излегла.",
                title="Повратница",
            ):
                continue
            try:
                back = reversals.povratnica(int(item["id"]))
                napraveni.append(issues.get(back)["doc_no"])
            except (reversals.ReversalError, ValueError, RuntimeError) as exc:
                widgets.error(self, str(exc), title="Повратница")
        if napraveni:
            widgets.info(self, "Направени повратници: " + ", ".join(napraveni)
                         + "\n\nСе гледаат во листата на испратници.",
                         title="Повратница")
        self.refresh()

    def fetch(self, search: str) -> list[dict]:
        rows = []
        paid_map = payments.paid_map(payments.KIND_SALES)
        date_from, date_to = self._period() if self.show_profit else ("", "")
        wanted_class = ""
        if getattr(self, "class_var", None) and self.class_var.get() != ALL:
            wanted_class = self.class_var.get()
        for rec in sales.list_all(self.kind, search, date_from=date_from,
                                  date_to=date_to, classification=wanted_class):
            net = q2(rec["total_net"])
            cost = q2(rec["total_cost"])
            gain = q2(net - cost)
            percent = q2(gain / cost * 100) if cost else D(0)
            gross = q2(rec["total_gross"])
            done = paid_map.get(int(rec["id"]), D(0)) if self.show_profit else D(0)
            state = payments.status(gross, done)
            wanted = getattr(self, "state_var", None)
            if self.show_profit and wanted is not None and wanted.get() != "Сите" \
                    and state != wanted.get():
                continue
            if rec["issue_no"]:
                link = "испр. " + rec["issue_no"]
            elif rec["source_no"]:
                link = "проф. " + rec["source_no"]
            elif rec["converted_no"]:
                link = "→ " + rec["converted_no"]
            else:
                link = ""
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "due_date": fmt_date(rec["due_date"]), "due_date_raw": rec["due_date"],
                "partner_name": rec["partner_name"] or "—",
                "lines_count": rec["lines_count"], "lines_count_raw": rec["lines_count"],
                "total_net": fmt(net), "total_net_raw": float(net),
                "total_vat": fmt(rec["total_vat"]), "total_vat_raw": rec["total_vat"],
                "total_gross": fmt(rec["total_gross"]), "total_gross_raw": rec["total_gross"],
                "total_cost": fmt(cost), "total_cost_raw": float(cost),
                "gain": fmt(gain), "gain_raw": float(gain),
                "margin": fmt(percent, 1), "margin_raw": float(percent),
                "paid": fmt(done) if done else "", "paid_raw": float(done),
                "remaining": fmt(q2(gross - done)) if state != "платена" else "",
                "remaining_raw": float(q2(gross - done)),
                "pay_status": state if self.show_profit else "",
                "classification": rec["classification"] or "",
                "storno": ("сторно на " + (
                    sales.get(int(rec["storno_of_id"]))["doc_no"]
                    if rec["storno_of_id"] else "")) if rec["is_storno"]
                    else (("сторнирана: " + storno_row["doc_no"])
                          if (storno_row := reversals.storno_of(int(rec["id"])))
                          else ""),
                "_is_storno": bool(rec["is_storno"]),
                "_stornirana": reversals.is_stornirana(int(rec["id"])),
                "issues": (links.source_label(links.FAKTURA, int(rec["id"]))
                           if self.show_profit else ""),
                "link": link,
                "_converted": bool(rec["converted_no"]),
                "_tags": ("neaktiven",) if rec["converted_no"] else (
                    () if not self.show_profit else
                    ({"платена": ("ok_row",), "делумно": ("warn_row",)}
                     .get(state, ("bad_row",)))),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['doc_no']} ({row['partner_name']})"

    def can_delete(self, row: dict) -> str:
        """Поднесена во УЈП не се брише — тогаш оди само сторно."""
        return reversals.why_cannot_delete(sales.get(int(row["id"])))

    def delete_warning(self, row: dict) -> str:
        if row.get("_is_storno"):
            return "Ова е сторно документ — со бришењето фактурата пак станува важечка."
        return ""

    def delete_record(self, rec_id: int) -> None:
        sales.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        return self.window(self, self.app, rec_id).show()


class IzlezniFakturiView(SalesListView):
    title = "Излезни фактури"
    subtitle = "продажба кон купувачи"
    empty_text = "Нема излезни фактури."
    kind = sales.KIND_INVOICE
    window = FakturaWindow
    show_profit = True
    print_kind = "faktura"


class ProfakturiView(SalesListView):
    title = "Профактури"
    subtitle = "понуди што можат да се претворат во фактура"
    empty_text = "Нема профактури."
    kind = sales.KIND_PROFORMA
    window = ProfakturaWindow
    show_profit = False
    print_kind = "profaktura"

    def extra_buttons(self, toolbar: Toolbar) -> None:
        self.btn_convert = toolbar.button("Претвори во фактура", self.action_convert,
                                          width=22)

    def update_extra_buttons(self, row: dict | None) -> None:
        button = getattr(self, "btn_convert", None)
        if button is None:
            return
        button.state(["!disabled"] if row is not None and not row.get("_converted")
                     else ["disabled"])

    def action_convert(self) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        if not widgets.confirm(
            self,
            f"Од профактурата {row['doc_no']} да се направи излезна фактура?\n\n"
            "Стоката ќе излезе од магацин при фактурирањето.",
            title="Претвори во фактура",
        ):
            return
        try:
            new_id = sales.convert_to_invoice(int(row["id"]))
        except (ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc))
            return
        record = sales.get(new_id)
        self.status(f"Направена излезна фактура {record['doc_no']} "
                    f"од профактура {row['doc_no']}.")
        self.refresh()
