# -*- coding: utf-8 -*-
"""МАТЕРИЈАЛНО → Испратници."""

from __future__ import annotations

from ...money import D, fmt, q2
from ...repo import issues, links, reversals, sales
from ...util import fmt_date
from .. import widgets
from ..widgets import Toolbar
from .base import CrudView
from . import links_ui
from .doc_window import DocumentWindow


class IspratnicaWindow(DocumentWindow):
    doc_label = "Испратница"
    partner_label = "Купувач"
    partner_as_supplier = False
    save_hint = ("Со зачувување стоката излегува од магацин по FIFO "
                 "(прво најстарата серија).")
    repo = issues
    print_kind = "ispratnica"

    def default_price(self, item_row):
        """Се нуди партнерската цена без ДДВ; ако ја нема — МПЦ без ДДВ."""
        return item_row["price_partner"] or item_row["price_retail_net"]


class IspratniciView(CrudView):
    title = "Испратници"
    print_kind = "ispratnica"
    subtitle = "излез на стока од магацин"
    empty_text = "Нема испратници. Кликни „Нова“ за да издадеш стока."
    new_text = "Нова"

    columns = (
        {"key": "doc_no", "text": "Број", "width": 100},
        {"key": "date", "text": "Датум", "width": 90},
        {"key": "partner_name", "text": "Купувач", "width": 230, "stretch": True},
        {"key": "lines_count", "text": "Ставки", "width": 60, "anchor": "e", "sort": "num"},
        {"key": "total_net", "text": "Основица", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "total_vat", "text": "ДДВ", "width": 85, "anchor": "e", "sort": "num"},
        {"key": "total_gross", "text": "Вкупно", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "total_cost", "text": "Чинење", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "gain", "text": "Заработка", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "margin", "text": "Маржа %", "width": 75, "anchor": "e", "sort": "num"},
        {"key": "invoice_no", "text": "Фактура", "width": 100},
        {"key": "povratnica", "text": "Повратница", "width": 120},
    )

    def extra_buttons(self, toolbar: Toolbar) -> None:
        self.btn_invoice = toolbar.button("Креирај фактура", self.action_invoice,
                                          width=17)
        self.btn_link = toolbar.button("Поврзи со фактура", self.action_link, width=19)
        self.btn_back = toolbar.button("Повратница", self.action_povratnica, width=14)

    def update_extra_buttons(self, row: dict | None) -> None:
        for name in ("btn_invoice", "btn_link"):
            button = getattr(self, name, None)
            if button is not None:
                button.state(["!disabled"] if row is not None else ["disabled"])
        back = getattr(self, "btn_back", None)
        if back is not None:
            ok = bool(row) and not row.get("_is_return") and not row.get("_vratena")
            back.state(["!disabled"] if ok else ["disabled"])

    def action_invoice(self) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        if not widgets.confirm(
            self,
            f"Од испратницата {row['doc_no']} да се направи излезна фактура?\n\n"
            "Стоката веќе излегла — фактурата само ја наплаќа.",
            title="Фактурирај",
        ):
            return
        try:
            new_id = sales.invoice_from_issue(int(row["id"]))
        except (ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc))
            return
        record = sales.get(new_id)
        self.status(f"Направена излезна фактура {record['doc_no']} "
                    f"по испратница {row['doc_no']}.")
        self.refresh()

    def action_povratnica(self) -> None:
        """Стоката се враќа на залиха по цената по која излегла."""
        row = self.table.selected_row()
        if row is None:
            return
        if not widgets.confirm(
            self,
            f"Да се направи повратница по испратницата {row['doc_no']}?\n\n"
            "Стоката се враќа на залиха по цената по која излегла, а на "
            "документот стојат продажните цени од испратницата.",
            title="Повратница",
        ):
            return
        try:
            new_id = reversals.povratnica(int(row["id"]))
        except (reversals.ReversalError, ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc), title="Повратница")
            return
        self.status(f"Направена повратница {issues.get(new_id)['doc_no']} "
                    f"по {row['doc_no']}.")
        self.refresh()

    def action_link(self) -> None:
        """Испратницата се закачува на веќе внесена фактура."""
        row = self.table.selected_row()
        if row is None:
            return
        if links_ui.link_to_invoice(self, links.ISPRATNICA, row):
            self.refresh()

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for rec in issues.list_all(search):
            net = q2(rec["total_net"])
            cost = q2(rec["total_cost"])
            gain = q2(net - cost)
            percent = q2(gain / cost * 100) if cost else D(0)
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "partner_name": rec["partner_name"] or "—",
                "lines_count": rec["lines_count"], "lines_count_raw": rec["lines_count"],
                "total_net": fmt(net), "total_net_raw": float(net),
                "total_vat": fmt(rec["total_vat"]), "total_vat_raw": rec["total_vat"],
                "total_gross": fmt(rec["total_gross"]), "total_gross_raw": rec["total_gross"],
                "total_cost": fmt(cost), "total_cost_raw": float(cost),
                "gain": fmt(gain), "gain_raw": float(gain),
                "margin": fmt(percent, 1), "margin_raw": float(percent),
                "partner_id": rec["partner_id"],
                "invoice_no": links.target_label(links.ISPRATNICA, int(rec["id"])),
                "povratnica": ("повратница на " + (
                    issues.get(int(rec["return_of_id"]))["doc_no"]
                    if rec["return_of_id"] else "")) if rec["is_return"]
                    else (("вратена: " + back["doc_no"])
                          if (back := reversals.return_of(int(rec["id"]))) else ""),
                "_is_return": bool(rec["is_return"]),
                "_vratena": reversals.return_of(int(rec["id"])) is not None,
                "_tags": ("vnimanie",) if gain < 0 else (),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['doc_no']} ({row['partner_name']})"

    def delete_record(self, rec_id: int) -> None:
        # Стоката се враќа во магацин.
        issues.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        return IspratnicaWindow(self, self.app, rec_id).show()
