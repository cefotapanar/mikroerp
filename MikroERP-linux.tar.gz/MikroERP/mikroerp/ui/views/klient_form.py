# -*- coding: utf-8 -*-
"""Внес и измена на клиент.

Клиентот е **правно** или **физичко** лице. Физичкото нема ЕДБ/ЕМБС, нема
повлекување од УЈП и нема посебни контакт-лица.

Полето **Назив** го носи кратниот назив (тој се гледа насекаде), а под него со
побледи букви стои полниот назив — оној што го дава УЈП и што се печати кога
документот ќе го побара.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ... import ujp
from ...repo import partners
from .. import theme, widgets
from ..widgets import DataTable, Field, FormDialog, SearchPicker, Toolbar

CONTACT_COLUMNS = (
    {"key": "line_no", "text": "Р.бр", "width": 45, "anchor": "e"},
    {"key": "name", "text": "Име", "width": 180},
    {"key": "phone", "text": "Телефон", "width": 130},
    {"key": "email", "text": "Е-пошта", "width": 200, "stretch": True},
    {"key": "note", "text": "Опис", "width": 200},
)

UJP_COLUMNS = (
    {"key": "name", "text": "Назив", "width": 420, "stretch": True},
    {"key": "edb", "text": "ЕДБ", "width": 140},
)


def choose_company(parent, hits: list[dict]) -> dict | None:
    """Кога УЈП врати повеќе фирми — корисникот избира која."""
    window = tk.Toplevel(parent)
    window.title("Најдени фирми на УЈП")
    window.transient(parent.winfo_toplevel())
    window.geometry("660x430")
    window.columnconfigure(0, weight=1)
    window.rowconfigure(1, weight=1)
    chosen: dict = {}

    ttk.Label(window, text=f"Најдени се {len(hits)} фирми. Избери која да се повлече:",
              padding=(10, 8)).grid(row=0, column=0, sticky="w")

    def take(*_a):
        index = table.selected_id()
        if index is not None and index < len(hits):
            chosen.update(hits[index])
            window.destroy()

    table = DataTable(window, UJP_COLUMNS, height=14, on_activate=lambda _i: take())
    table.grid(row=1, column=0, sticky="nsew", padx=10)
    table.set_rows([{"id": index, "name": hit["name"], "edb": hit["edb"]}
                    for index, hit in enumerate(hits)])
    table.select_first()

    buttons = ttk.Frame(window, padding=(10, 8, 10, 10))
    buttons.grid(row=2, column=0, sticky="ew")
    ttk.Button(buttons, text="Откажи", width=12, command=window.destroy).pack(side="right")
    ttk.Button(buttons, text="Повлечи", width=12, command=take).pack(side="right", padx=(0, 6))
    window.bind("<Escape>", lambda _e: window.destroy())
    widgets.center_on(window, parent.winfo_toplevel())
    window.grab_set()
    parent.wait_window(window)
    return chosen or None


class KlientWindow(tk.Toplevel):
    def __init__(self, master, app, partner_id: int | None = None,
                 as_supplier: bool = False):
        super().__init__(master)
        self.app = app
        self.partner_id = partner_id
        self.saved = False
        self.new_id: int | None = None

        record = partners.get(partner_id) if partner_id else None
        if record is not None:
            self.data = dict(record)
            self.contacts = [dict(row) for row in partners.contacts(partner_id)]
        else:
            self.data = {
                "code": partners.next_code(), "country": "Македонија",
                "is_customer": not as_supplier, "is_supplier": as_supplier,
                "active": True, "kind": partners.KIND_COMPANY,
            }
            self.contacts = []

        self.title("Клиент — " + (self.data.get("name") or "нов"))
        self.transient(master.winfo_toplevel())
        self.geometry("880x700")
        self.minsize(780, 620)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        self._build_form()
        self._build_contacts()
        self._build_footer()

        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.bind("<Escape>", lambda _e: self.destroy())
        self._apply_kind()
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()

    # ---------------------------------------------------------------- форма
    def _build_form(self) -> None:
        top = ttk.Frame(self, padding=(10, 8, 10, 0))
        top.grid(row=0, column=0, sticky="ew")
        ttk.Label(top, text="Вид:").pack(side="left")
        self.kind_var = tk.StringVar(value=partners.kind_of(self.data))
        for label in partners.KINDS:
            ttk.Radiobutton(top, text=label.capitalize(), value=label,
                            variable=self.kind_var,
                            command=self._apply_kind).pack(side="left", padx=(8, 0))

        fields = [
            Field("code", "Шифра", col=2, chars=8),
            Field("name", "Назив (краток)", col=10, required=True,
                  side_button=("Повлечи од УЈП", self._ujp),
                  help="може и ЕДБ или матичен број — па кликни „Повлечи од УЈП“"),
            Field("full_name", "Полн назив (како во УЈП)", col=12),

            Field("tax_number", "ЕДБ", col=3, chars=17),
            Field("reg_number", "ЕМБС", col=2, chars=10),
            Field("bank_account", "Жиро сметка", col=3, chars=18),
            Field("bank_name", "Банка", col=4, chars=28),

            Field("heading_adresa", "Адреса и контакт", kind="heading"),
            Field("address", "Улица и број", col=5),
            Field("city", "Град", col=3, chars=18),
            Field("country", "Држава", col=4, chars=18),
            Field("phone", "Телефон", col=3, chars=16),
            Field("email", "Е-пошта", col=5, chars=28),
            Field("contact_person", "Контакт лице", col=4, chars=22),

            Field("sep", "", kind="sep"),
            Field("is_customer", "Купувач", kind="check", col=3),
            Field("is_supplier", "Добавувач", kind="check", col=3),
            Field("active", "Активен", kind="check", col=3),
        ]
        self.panel = widgets.FormPanel(self, fields, self.data, padding=(10, 6, 10, 4))
        self.panel.grid(row=1, column=0, sticky="ew")

        # полниот назив се гледа побледо — кратниот е главниот
        full = self.panel.widgets.get("full_name")
        if isinstance(full, ttk.Entry):
            full.configure(foreground=theme.C["muted"])

    def _apply_kind(self) -> None:
        person = self.kind_var.get() == partners.KIND_PERSON
        for key in ("tax_number", "reg_number", "full_name"):
            widget = self.panel.widgets.get(key)
            if widget is not None:
                widget.configure(state="disabled" if person else "normal")
        for widget in self.contacts_box.winfo_children() if hasattr(self, "contacts_box") else []:
            try:
                widget.configure(state="disabled" if person else "normal")
            except tk.TclError:
                pass
        if hasattr(self, "contacts_box"):
            if person:
                self.contacts_box.grid_remove()
            else:
                self.contacts_box.grid()

    # ------------------------------------------------------------- контакти
    def _build_contacts(self) -> None:
        self.contacts_box = ttk.Labelframe(self, text="Дополнителни контакти",
                                           padding=(10, 6, 10, 8))
        self.contacts_box.grid(row=2, column=0, sticky="nsew", padx=10, pady=(8, 4))
        self.contacts_box.columnconfigure(0, weight=1)
        self.contacts_box.rowconfigure(1, weight=1)

        # Внес во еден ред, исто како ставка во фактура — без посебен прозорец.
        row = ttk.Frame(self.contacts_box)
        row.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        self.c_name = tk.StringVar()
        self.c_phone = tk.StringVar()
        self.c_email = tk.StringVar()
        self.c_note = tk.StringVar()
        chain = []
        for text, var, width in (("Име:", self.c_name, 20),
                                 ("Телефон:", self.c_phone, 14),
                                 ("Е-пошта:", self.c_email, 22),
                                 ("Опис:", self.c_note, 20)):
            ttk.Label(row, text=text).pack(side="left")
            entry = ttk.Entry(row, textvariable=var, width=width)
            entry.pack(side="left", padx=(4, 10))
            chain.append(entry)
        for index, widget in enumerate(chain):
            if index + 1 < len(chain):
                widget.bind("<Return>", self._next(chain[index + 1]), add="+")
            else:
                widget.bind("<Return>", lambda _e: self.commit_contact(), add="+")
        self.btn_contact = ttk.Button(row, text="Додај", width=10,
                                      command=self.commit_contact)
        self.btn_contact.pack(side="left")

        ttk.Label(self.contacts_box,
                  text="Enter оди на следното поле; на последното го додава контактот. "
                       "Delete го брише избраниот.",
                  style="Small.TLabel").grid(row=1, column=0, sticky="w", pady=(0, 4))

        self.table = DataTable(self.contacts_box, CONTACT_COLUMNS, height=6,
                               on_activate=lambda _i: self.edit_contact(),
                               on_select=lambda _i: self._update_buttons())
        self.table.grid(row=2, column=0, sticky="nsew")
        self.table.tree.bind("<Delete>", lambda _e: self.delete_contact())
        self.contacts_box.rowconfigure(2, weight=1)

        tools = Toolbar(self.contacts_box)
        tools.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.btn_edit = tools.button("Измени", self.edit_contact, width=10)
        self.btn_del = tools.button("Избриши", self.delete_contact, width=10)
        self.editing: int | None = None
        self._refresh_contacts()

    @staticmethod
    def _next(widget):
        def handler(_event=None):
            widget.focus_set()
            try:
                widget.select_range(0, "end")
            except tk.TclError:
                pass
            return "break"
        return handler

    def commit_contact(self) -> None:
        data = {"name": self.c_name.get().strip(), "phone": self.c_phone.get().strip(),
                "email": self.c_email.get().strip(), "note": self.c_note.get().strip()}
        if not any(data.values()):
            widgets.info(self, "Внеси барем име или телефон.")
            return
        if self.editing is None:
            self.contacts.append(data)
        else:
            self.contacts[self.editing] = data
            self.editing = None
            self.btn_contact.configure(text="Додај")
        for var in (self.c_name, self.c_phone, self.c_email, self.c_note):
            var.set("")
        self._refresh_contacts()

    def edit_contact(self) -> None:
        index = self.table.selected_id()
        if index is None or index >= len(self.contacts):
            return
        contact = self.contacts[index]
        self.editing = index
        self.c_name.set(contact.get("name") or "")
        self.c_phone.set(contact.get("phone") or "")
        self.c_email.set(contact.get("email") or "")
        self.c_note.set(contact.get("note") or "")
        self.btn_contact.configure(text="Зачувај")

    def delete_contact(self) -> None:
        index = self.table.selected_id()
        if index is None or index >= len(self.contacts):
            return
        contact = self.contacts[index]
        if not widgets.confirm(self, "Да се избрише контактот?\n\n"
                                     f"{contact.get('name') or ''}",
                               title="Избриши контакт"):
            return
        self.contacts.pop(index)
        if self.editing is not None:
            self.editing = None
            self.btn_contact.configure(text="Додај")
        self._refresh_contacts()

    def _refresh_contacts(self) -> None:
        self.table.set_rows([
            {"id": index, "line_no": index + 1, "name": row.get("name") or "",
             "phone": row.get("phone") or "", "email": row.get("email") or "",
             "note": row.get("note") or ""}
            for index, row in enumerate(self.contacts)
        ])
        self._update_buttons()

    def _update_buttons(self) -> None:
        state = ["!disabled"] if self.table.selected_id() is not None else ["disabled"]
        self.btn_edit.state(state)
        self.btn_del.state(state)

    # ------------------------------------------------------------------ УЈП
    def _ujp(self, panel) -> None:
        if self.kind_var.get() == partners.KIND_PERSON:
            widgets.info(self, "Повлекувањето од УЈП важи само за правни лица.")
            return None
        term = str(panel.get_values().get("name") or "").strip()
        if len(term) < 3:
            widgets.info(self, "Во полето Назив внеси назив, дел од назив, ЕДБ или\n"
                               "матичен број (барем 3 знаци), па кликни повторно.",
                         title="Повлечи од УЈП")
            return None

        def fetch(work, message):
            try:
                return widgets.run_with_progress(self, "Повлекување од УЈП", work,
                                                 message=message)
            except ujp.UjpError as exc:
                widgets.error(self, str(exc), title="УЈП")
            except Exception as exc:  # noqa: BLE001
                widgets.error(self, f"Повлекувањето не успеа:\n\n{exc}", title="УЈП")
            return None

        result = fetch(lambda: ujp.lookup(term), f"Се бара „{term}“ на ujp.gov.mk…")
        if result is None:
            return None
        if result["kind"] == "none":
            widgets.info(self, f"УЈП нема резултат за „{term}“.", title="Повлечи од УЈП")
            return None

        if result["kind"] == "list":
            hit = choose_company(self, result["hits"])
            if not hit:
                return None
            data = fetch(lambda: ujp.fetch(hit), "Се повлекуваат деталите…")
            if not data:
                return None
        else:
            data = result["data"]

        values = ujp.to_partner(data)
        self.kind_var.set(partners.KIND_COMPANY)
        self._apply_kind()
        panel.set_values({k: v for k, v in values.items() if v and k != "kind"})
        return None

    # -------------------------------------------------------------- зачувај
    def _build_footer(self) -> None:
        buttons = ttk.Frame(self, padding=(10, 6, 10, 10))
        buttons.grid(row=3, column=0, sticky="ew")
        ttk.Button(buttons, text="Откажи", width=12, command=self.destroy).pack(side="right")
        ttk.Button(buttons, text="Зачувај", width=14, command=self.save).pack(
            side="right", padx=(0, 6))
        self.error_label = ttk.Label(buttons, text="", style="Error.TLabel")
        self.error_label.pack(side="left")

    def save(self) -> None:
        data = self.panel.get_values()
        data["kind"] = self.kind_var.get()
        missing = self.panel.missing_required(data)
        if missing is not None:
            self.error_label.configure(text=f"Полето „{missing.label}“ е задолжително.")
            return
        try:
            if self.partner_id:
                partners.update(self.partner_id, data, self.contacts)
                self.new_id = self.partner_id
            else:
                self.new_id = partners.create(data, self.contacts)
        except ValueError as exc:
            self.error_label.configure(text=str(exc))
            return
        self.saved = True
        self.app.set_status("Зачуван клиент: " + data["name"])
        self.destroy()

    def show(self) -> int | None:
        self.wait_window(self)
        return self.new_id if self.saved else None
