# -*- coding: utf-8 -*-
"""ШИФРАРНИК → Брендови."""

from __future__ import annotations

from ...repo import brands
from ..widgets import Field, FormDialog
from .base import CrudView


class BrendoviView(CrudView):
    title = "Брендови"
    empty_text = "Нема внесени брендови."
    search_placeholder = "Барај бренд:"

    columns = (
        {"key": "name", "text": "Назив", "width": 240, "stretch": True},
        {"key": "items_count", "text": "Артикли", "width": 90, "anchor": "e", "sort": "num"},
        {"key": "note", "text": "Забелешка", "width": 320, "stretch": True},
        {"key": "active", "text": "Активен", "width": 90, "anchor": "center"},
    )

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for row in brands.list_all(search):
            rows.append({
                "id": row["id"],
                "name": row["name"],
                "items_count": row["items_count"],
                "items_count_raw": row["items_count"],
                "note": row["note"],
                "active": "Да" if row["active"] else "Не",
                "_tags": () if row["active"] else ("neaktiven",),
            })
        return rows

    def describe(self, row: dict) -> str:
        return row["name"]

    def can_delete(self, row: dict) -> str:
        if int(row.get("items_count_raw") or 0) > 0:
            return (f"Брендот „{row['name']}“ е поврзан со {row['items_count_raw']} артикл(и).\n\n"
                    "Прво промени го брендот на тие артикли, или означи го брендот како неактивен.")
        return ""

    def delete_record(self, rec_id: int) -> None:
        brands.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        record = brands.get(rec_id) if rec_id else None
        values = dict(record) if record else {"active": True}

        fields = [
            Field("name", "Назив на бренд", col=12, required=True),
            Field("note", "Забелешка", kind="memo", col=12, height=3),
            Field("active", "Активен", kind="check", col=4),
        ]

        def save(data: dict):
            if rec_id:
                brands.update(rec_id, data)
            else:
                brands.create(data)
            self.status("Зачуван бренд: " + data["name"])
            return True

        dialog = FormDialog(
            self,
            "Нов бренд" if not rec_id else f"Бренд — {values.get('name', '')}",
            fields, values, on_save=save, width=560,
        )
        return dialog.show() is not None
