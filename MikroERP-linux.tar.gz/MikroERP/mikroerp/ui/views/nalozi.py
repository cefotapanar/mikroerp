# -*- coding: utf-8 -*-
"""МАТЕРИЈАЛНО → Работен налог.

Материјалите излегуваат од магацинот-извор, готовиот производ влегува во
магацинот-примач (може и во истиот). Цената на чинење на производот е збир на
цените на чинење на вложените материјали, поделен со количината.

Две копчиња, зашто тоа се два вистински настани:
  * **Зачувај**   — материјалите излегуваат, лагерот е оптоварен;
  * **Произведи** — производот влегува на залиха.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, fmt_qty
from ...repo import items, stock, warehouses, workorders
from ...util import fmt_date, parse_date, today
from .. import theme, widgets
from ..widgets import DataTable, SearchPicker, Toolbar
from .artikli import new_item_dialog
from .base import CrudView

MATERIAL_COLUMNS = (
    {"key": "line_no", "text": "Р.бр", "width": 45, "anchor": "e"},
    {"key": "code", "text": "Шифра", "width": 80},
    {"key": "name", "text": "Материјал", "width": 260, "stretch": True},
    {"key": "unit", "text": "ЕМ", "width": 50, "anchor": "center"},
    {"key": "qty", "text": "Количина", "width": 90, "anchor": "e", "sort": "num"},
    {"key": "cost", "text": "Вредност", "width": 110, "anchor": "e", "sort": "num"},
    {"key": "warn", "text": "", "width": 130},
)


class NalogWindow(tk.Toplevel):
    def __init__(self, master, app, doc_id: int | None = None):
        super().__init__(master)
        self.app = app
        self.doc_id = doc_id
        self.saved = False
        self.editing: int | None = None

        self.header_data, self.lines_data = self._load()
        self._start = self._snapshot()

        self.title(f"Работен налог {self.header_data['doc_no']}"
                   + ("" if doc_id else " (нов)"))
        self.transient(master.winfo_toplevel())
        self.geometry("1000x700")
        self.minsize(900, 600)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        self._build_header()
        self._build_lines()
        self._build_note()
        self._build_footer()

        self.protocol("WM_DELETE_WINDOW", self.cancel)
        self.bind("<Escape>", lambda _e: self.cancel())
        self.refresh_lines()
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()
        self.after(50, self.product_picker.focus)

    # ------------------------------------------------------------- податоци
    def _load(self):
        if self.doc_id is None:
            return workorders.blank(today()), []
        record = workorders.get(self.doc_id)
        if record is None:
            raise ValueError("Работниот налог не постои.")
        rows = [{"item_id": int(r["item_id"]), "code": r["item_code"],
                 "name": r["item_name"], "unit": r["item_unit"],
                 "qty": D(r["qty"])} for r in workorders.lines(self.doc_id)]
        return workorders.header_of(record), rows

    def _snapshot(self) -> str:
        header = {k: v for k, v in self.header_data.items()
                  if k not in ("doc_no", "status")}
        return repr((sorted((k, str(v)) for k, v in header.items()),
                     [sorted((k, str(v)) for k, v in l.items()) for l in self.lines_data]))

    def _is_dirty(self) -> bool:
        self._pull_header()
        return self._snapshot() != self._start

    def _done(self) -> bool:
        return str(self.header_data.get("status")) == workorders.STATUS_DONE

    # -------------------------------------------------------------- заглавие
    def _build_header(self) -> None:
        box = ttk.Labelframe(self, text="Заглавие", padding=(10, 6, 10, 8))
        box.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 4))

        row1 = ttk.Frame(box)
        row1.pack(fill="x")
        ttk.Label(row1, text="Број:").pack(side="left")
        ttk.Label(row1, text=self.header_data["doc_no"], style="Path.TLabel",
                  width=13).pack(side="left", padx=(4, 16))

        ttk.Label(row1, text="Датум:").pack(side="left")
        self.date_var = tk.StringVar(value=fmt_date(self.header_data["date"]))
        ttk.Entry(row1, textvariable=self.date_var, width=11).pack(side="left", padx=(4, 16))

        ttk.Label(row1, text="Производ:").pack(side="left")
        self.product_picker = SearchPicker(row1, self._product_options(), width=30,
                                           on_select=lambda _v: self.refresh_lines())
        self.product_picker.pack(side="left", padx=(4, 4))
        self.product_picker.set(str(self.header_data["item_id"] or ""))
        widgets.require(self.product_picker)
        ttk.Button(row1, text="Нов производ", width=14,
                   command=self.create_product).pack(side="left", padx=(0, 16))

        ttk.Label(row1, text="Количина:").pack(side="left")
        self.qty_var = tk.StringVar(value=fmt_qty(self.header_data["qty"]))
        entry = ttk.Entry(row1, textvariable=self.qty_var, width=8, justify="right")
        entry.pack(side="left", padx=(4, 0))
        entry.bind("<FocusOut>", lambda _e: self.refresh_lines())
        widgets.require(entry, self.qty_var,
                        getter=lambda: self.qty_var.get()
                        if D(self.qty_var.get() or 0) > 0 else "")

        row2 = ttk.Frame(box)
        row2.pack(fill="x", pady=(8, 0))
        options = [(str(i), n) for i, n in warehouses.options()]
        ttk.Label(row2, text="Материјали од магацин:").pack(side="left")
        self.from_picker = SearchPicker(row2, options, width=22,
                                        on_select=lambda _v: self.refresh_lines())
        self.from_picker.pack(side="left", padx=(4, 16))
        self.from_picker.set(str(self.header_data["from_warehouse_id"]))

        ttk.Label(row2, text="Производ во магацин:").pack(side="left")
        self.to_picker = SearchPicker(row2, options, width=22)
        self.to_picker.pack(side="left", padx=(4, 16))
        self.to_picker.set(str(self.header_data["to_warehouse_id"]))

        self.status_label = ttk.Label(row2, text="", style="Head.TLabel")
        self.status_label.pack(side="left")

    def _product_options(self):
        return [(str(r["id"]), f"{r['code']} — {r['name']}", r["barcode"])
                for r in items.list_all(only_active=True, only_manufactured=True)]

    def create_product(self) -> None:
        new_id = new_item_dialog(self, kind=items.KIND_PRODUCT)
        if new_id:
            self.product_picker.set_options(self._product_options())
            self.product_picker.set(str(new_id))
            self.refresh_lines()

    def _pull_header(self) -> None:
        try:
            self.header_data["date"] = parse_date(self.date_var.get())
        except ValueError:
            self.header_data["date"] = self.date_var.get()
        self.header_data["item_id"] = (int(self.product_picker.get())
                                       if self.product_picker.get() else None)
        try:
            self.header_data["qty"] = D(self.qty_var.get() or 0)
        except ValueError:
            self.header_data["qty"] = D(0)
        if self.from_picker.get():
            self.header_data["from_warehouse_id"] = int(self.from_picker.get())
        if self.to_picker.get():
            self.header_data["to_warehouse_id"] = int(self.to_picker.get())
        self.header_data["note"] = self.note_widget.get("1.0", "end-1c").strip()

    # ------------------------------------------------------------ материјали
    def _build_lines(self) -> None:
        box = ttk.Labelframe(self, text="Материјали", padding=(10, 6, 10, 8))
        box.grid(row=1, column=0, sticky="nsew", padx=8, pady=4)
        box.columnconfigure(0, weight=1)
        box.rowconfigure(2, weight=1)

        entry_row = ttk.Frame(box)
        entry_row.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(entry_row, text="Материјал:").pack(side="left")
        self.item_picker = SearchPicker(entry_row, self._item_options(), width=34)
        self.item_picker.pack(side="left", padx=(4, 4))
        ttk.Button(entry_row, text="Креирај артикл", width=15,
                   command=self.create_item).pack(side="left", padx=(0, 14))

        ttk.Label(entry_row, text="Количина:").pack(side="left")
        self.mat_qty_var = tk.StringVar(value="1")
        qty_entry = ttk.Entry(entry_row, textvariable=self.mat_qty_var, width=9,
                              justify="right")
        qty_entry.pack(side="left", padx=(4, 12))

        self.btn_line = ttk.Button(entry_row, text="Додај", width=10, command=self.commit_line)
        self.btn_line.pack(side="left")

        # Enter: од артиклот на количината, од количината — додава
        self.item_picker.entry.bind(
            "<Return>", lambda _e: (qty_entry.focus_set(), qty_entry.select_range(0, "end"),
                                    "break")[-1], add="+")
        qty_entry.bind("<Return>", lambda _e: self.commit_line())

        ttk.Label(box, text="Enter оди на количината, па ја додава ставката. "
                            "Delete ја брише избраната.",
                  style="Small.TLabel").grid(row=1, column=0, sticky="w", pady=(0, 4))

        self.lines = DataTable(box, MATERIAL_COLUMNS,
                               on_activate=lambda _i: self.edit_line(),
                               on_select=lambda _i: self._update_line_buttons(), height=10)
        self.lines.grid(row=2, column=0, sticky="nsew")
        self.lines.tree.bind("<Delete>", lambda _e: self.delete_line())

        tools = Toolbar(box)
        tools.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.btn_edit = tools.button("Измени", self.edit_line, width=12)
        self.btn_del = tools.button("Избриши", self.delete_line, width=12)

    def _item_options(self):
        return [(str(r["id"]), f"{r['code']} — {r['name']}",
                 f"{r['barcode']} {r['brand_name']}")
                for r in items.list_all(only_active=True)]

    def create_item(self) -> None:
        new_id = new_item_dialog(self)
        if new_id:
            self.item_picker.set_options(self._item_options())
            self.item_picker.set(str(new_id))

    def commit_line(self) -> None:
        item_id = self.item_picker.get()
        if not item_id:
            widgets.info(self, "Избери материјал.")
            self.item_picker.focus()
            return
        row = items.get(int(item_id))
        data = {"item_id": int(item_id), "code": row["code"], "name": row["name"],
                "unit": row["unit"], "qty": self.mat_qty_var.get()}
        try:
            workorders.clean_line(data)
        except ValueError as exc:
            widgets.error(self, str(exc))
            return
        data["qty"] = D(data["qty"])
        if self.editing is None:
            self.lines_data.append(data)
        else:
            self.lines_data[self.editing] = data
            self.editing = None
            self.btn_line.configure(text="Додај")
        self.item_picker.clear()
        self.mat_qty_var.set("1")
        self.item_picker.focus()
        self.refresh_lines()

    def edit_line(self) -> None:
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = self.lines_data[index]
        self.editing = index
        self.item_picker.set(str(line["item_id"]))
        self.mat_qty_var.set(fmt_qty(line["qty"]))
        self.btn_line.configure(text="Зачувај")
        self.item_picker.focus()

    def delete_line(self) -> None:
        index = self.lines.selected_id()
        if index is None or index >= len(self.lines_data):
            return
        line = self.lines_data[index]
        if not widgets.confirm(self, f"Да се избрише материјалот?\n\n"
                                     f"{line['code']} — {line['name']}",
                               title="Избриши материјал"):
            return
        self.lines_data.pop(index)
        if self.editing is not None:
            self.editing = None
            self.btn_line.configure(text="Додај")
        self.refresh_lines()

    def refresh_lines(self) -> None:
        self._pull_header()
        from_wh = int(self.header_data["from_warehouse_id"])
        rows = []
        total = D(0)
        for index, line in enumerate(self.lines_data):
            cost, short = stock.estimate_cost(line["item_id"], from_wh, line["qty"])
            total += cost
            rows.append({
                "id": index,
                "line_no": index + 1,
                "code": line["code"], "name": line["name"], "unit": line["unit"],
                "qty": fmt_qty(line["qty"]), "qty_raw": float(line["qty"]),
                "cost": fmt(cost), "cost_raw": float(cost),
                "warn": f"нема {fmt_qty(short)} на залиха" if short > 0 else "",
                "_tags": ("vnimanie",) if short > 0 else (),
            })
        self.lines.set_rows(rows)

        qty = D(self.header_data["qty"] or 0)
        unit = (total / qty) if qty else D(0)
        self.sum_labels["material"].configure(text=fmt(total))
        self.sum_labels["unit"].configure(text=fmt(unit))
        self.sum_labels["qty"].configure(text=fmt_qty(qty))

        done = self._done()
        self.status_label.configure(
            text=("✔ произведен" if done else "материјалите се раздолжуваат при зачувување"),
            foreground=theme.C["ok"] if done else theme.C["muted"],
        )
        self.btn_produce.configure(text="Произведи" if not done else "Произведено")
        self.btn_produce.state(["disabled"] if done else ["!disabled"])
        self._update_line_buttons()

    def _update_line_buttons(self) -> None:
        state = ["!disabled"] if self.lines.selected_id() is not None else ["disabled"]
        self.btn_edit.state(state)
        self.btn_del.state(state)

    # -------------------------------------------------------------- забелешка
    def _build_note(self) -> None:
        box = ttk.Labelframe(self, text="Забелешка", padding=(10, 6, 10, 8))
        box.grid(row=2, column=0, sticky="ew", padx=8, pady=4)
        self.note_widget = tk.Text(box, height=2, wrap="word", relief="sunken",
                                   borderwidth=1, font=theme.FONTS["base"])
        self.note_widget.pack(fill="x")
        if self.header_data["note"]:
            self.note_widget.insert("1.0", self.header_data["note"])

    # --------------------------------------------------------------- збирови
    def _build_footer(self) -> None:
        footer = ttk.Frame(self, padding=(8, 0, 8, 6))
        footer.grid(row=3, column=0, sticky="ew")
        footer.columnconfigure(0, weight=1)

        sums = ttk.Frame(footer)
        sums.grid(row=0, column=1, sticky="e")
        self.sum_labels: dict[str, ttk.Label] = {}
        for index, (key, text) in enumerate((("material", "Вредност на материјалите:"),
                                             ("qty", "Количина:"),
                                             ("unit", "Цена на чинење по единица:"))):
            ttk.Label(sums, text=text).grid(row=index, column=0, sticky="e", padx=(0, 10))
            style = "Path.TLabel" if key == "unit" else "TLabel"
            value = ttk.Label(sums, text="0,00", anchor="e", width=14, style=style)
            value.grid(row=index, column=1, sticky="e")
            self.sum_labels[key] = value

        ttk.Label(footer, text="Цената на чинење на производот е збир на вложените "
                               "материјали, поделен со количината.",
                  style="Small.TLabel").grid(row=0, column=0, sticky="w")

        buttons = ttk.Frame(self, padding=(8, 0, 8, 10))
        buttons.grid(row=4, column=0, sticky="ew")
        ttk.Button(buttons, text="Откажи", width=12, command=self.cancel).pack(side="right")
        ttk.Button(buttons, text="Зачувај", width=14,
                   command=self.save).pack(side="right", padx=(0, 6))
        self.btn_produce = ttk.Button(buttons, text="Произведи", width=16,
                                      command=self.produce)
        self.btn_produce.pack(side="right", padx=(0, 6))

    # -------------------------------------------------------------- дејства
    def _store(self, produce: bool | None) -> bool:
        try:
            self._pull_header()
            header = dict(self.header_data)
            header["date"] = parse_date(header["date"])
        except ValueError as exc:
            widgets.error(self, str(exc))
            return False
        try:
            self.doc_id = workorders.save_document(self.doc_id, header,
                                                   self.lines_data, produce)
        except (ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc), title="Зачувувањето не успеа")
            return False
        self.saved = True
        return True

    def save(self) -> None:
        if not self._store(None):
            return
        record = workorders.get(self.doc_id)
        self.app.set_status(
            f"Зачуван работен налог {record['doc_no']} — материјалите се раздолжени."
        )
        self.destroy()

    def produce(self) -> None:
        if not self._store(True):
            return
        record = workorders.get(self.doc_id)
        self.app.set_status(
            f"Произведено по налог {record['doc_no']}: {fmt_qty(record['qty'])} "
            f"{record['item_unit']} {record['item_name']} по "
            f"{fmt(record['unit_cost'])} ден."
        )
        self.destroy()

    def cancel(self) -> None:
        if self._is_dirty() and not widgets.confirm(
            self, "Има промени што не се зачувани.\n\nДа се затвори без зачувување?",
            title="Незачувани промени",
        ):
            return
        self.destroy()

    def show(self) -> bool:
        self.wait_window(self)
        return self.saved


class NaloziView(CrudView):
    title = "Работен налог"
    print_kind = "raboten_nalog"
    subtitle = "материјали → готов производ"
    empty_text = "Нема работни налози."
    new_text = "Нов"

    columns = (
        {"key": "doc_no", "text": "Број", "width": 95},
        {"key": "date", "text": "Датум", "width": 85},
        {"key": "item_name", "text": "Производ", "width": 210, "stretch": True},
        {"key": "qty", "text": "Количина", "width": 80, "anchor": "e", "sort": "num"},
        {"key": "from_name", "text": "Од магацин", "width": 120},
        {"key": "to_name", "text": "Во магацин", "width": 120},
        {"key": "lines_count", "text": "Материјали", "width": 80, "anchor": "e", "sort": "num"},
        {"key": "material_cost", "text": "Вредност", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "unit_cost", "text": "Чинење/ед.", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "status", "text": "Состојба", "width": 95},
    )

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for rec in workorders.list_all(search):
            done = rec["status"] == workorders.STATUS_DONE
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "item_name": f"{rec['item_code']} — {rec['item_name']}",
                "qty": fmt_qty(rec["qty"]), "qty_raw": rec["qty"],
                "from_name": rec["from_name"], "to_name": rec["to_name"],
                "lines_count": rec["lines_count"], "lines_count_raw": rec["lines_count"],
                "material_cost": fmt(rec["material_cost"]),
                "material_cost_raw": rec["material_cost"],
                "unit_cost": fmt(rec["unit_cost"]), "unit_cost_raw": rec["unit_cost"],
                "status": rec["status"],
                "_tags": () if done else ("neaktiven",),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['doc_no']} ({row['item_name']})"

    def delete_record(self, rec_id: int) -> None:
        workorders.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        return NalogWindow(self, self.app, rec_id).show()
