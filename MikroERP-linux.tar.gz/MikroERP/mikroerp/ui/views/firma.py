# -*- coding: utf-8 -*-
"""ПОДЕСУВАЊА → Фирма.

Три блока, по редот по кој се работи:

1. **Официјални податоци (УЈП)** — се повлекуваат од јавниот регистар и стојат
   заклучени. Тие се она што го кажува државата и не се менуваат на рака.
2. **Податоци за документите** — тоа што ќе се печати на фактурите: назив,
   адреса, контакт, лого. Тука сè се менува, зашто фирмата на документ може да
   се претстави поинаку отколку што стои во регистарот.
3. **Банки и сметки** — една или повеќе трансакциски сметки; за секоја се бира
   дали се печати на фактурата. Изводите се водат по сметка.

Полињата се редат во мрежа со фиксни колони, за да стојат едно под друго, а не
расфрлани по ширината.
"""

from __future__ import annotations

import shutil
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, ttk

from ... import registracija, sertifikati, ujp, winprint
from ...paths import DATA_DIR, app_dir, ensure_dir
from ...repo import bank_accounts, settings
from .. import theme, widgets
from ..widgets import DataTable
from .base import View
from .klient_form import choose_company

LOGO_KEY = "firma_logo"
LOGO_TYPES = [("Слики", "*.png *.gif *.jpg *.jpeg *.bmp *.tif *.tiff"),
              ("Сите датотеки", "*.*")]

BANK_COLUMNS = (
    {"key": "bank_name", "text": "Банка", "width": 300, "stretch": True},
    {"key": "account_no", "text": "Трансакциска сметка", "width": 190},
    {"key": "show", "text": "На фактура", "width": 95, "anchor": "center"},
    {"key": "active", "text": "Активна", "width": 85, "anchor": "center"},
    {"key": "statements", "text": "Изводи", "width": 80, "anchor": "e",
     "sort": "num"},
)


def logo_path() -> Path | None:
    """Патека до логото, ако е поставено и сè уште постои."""
    name = settings.get(LOGO_KEY, "").strip()
    if not name:
        return None
    path = Path(name)
    if not path.is_absolute():
        path = app_dir() / name
    return path if path.exists() else None


class Form:
    """Мала помош за уредна мрежа: етикета горе, поле долу, се реди по редови."""

    def __init__(self, parent: ttk.Frame, columns: int = 4):
        self.parent = parent
        self.columns = columns
        self.row = 0
        self.col = 0
        self.vars: dict[str, tk.StringVar] = {}
        self.widgets: dict[str, tk.Widget] = {}
        parent.grid_columnconfigure(columns, weight=1)      # вишокот десно

    def newline(self) -> None:
        if self.col:
            self.row += 2
            self.col = 0

    def add(self, key: str, label: str, width: int = 24, span: int = 1,
            readonly: bool = False, value: str = "", help: str = "") -> tk.Widget:
        if self.col + span > self.columns:
            self.newline()
        cell = ttk.Frame(self.parent)
        cell.grid(row=self.row, column=self.col, columnspan=span, rowspan=2,
                  sticky="nw", padx=(0, 18), pady=(0, 8))
        ttk.Label(cell, text=label,
                  style="Muted.TLabel" if readonly else "TLabel").grid(
            row=0, column=0, sticky="w")
        var = tk.StringVar(value=value)
        entry = ttk.Entry(cell, textvariable=var, width=width)
        entry.grid(row=1, column=0, sticky="w")
        if readonly:
            entry.state(["readonly"])
            entry.configure(foreground=theme.C["muted"])
        if help:
            ttk.Label(cell, text=help, style="Small.TLabel").grid(row=2, column=0,
                                                                  sticky="w")
        self.vars[key] = var
        self.widgets[key] = entry
        self.col += span
        return entry

    def get(self, key: str) -> str:
        return self.vars[key].get().strip()

    def set_values(self, values: dict) -> None:
        for key, var in self.vars.items():
            if key in values:
                var.set("" if values[key] is None else str(values[key]))

    def values(self) -> dict:
        return {key: var.get().strip() for key, var in self.vars.items()}


class FirmaView(View):
    title = "Фирма"
    subtitle = "официјалните податоци се од УЈП; долу е она што се печати"

    def build(self) -> None:
        # Екранот има пет блока — повеќе отколку што собира еден прозорец,
        # затоа содржината е подвижна. Инаку последниот блок ги здробува
        # претходните и табелата со сметките останува без простор.
        self.rowconfigure(2, weight=1)
        holder = ttk.Frame(self)
        holder.grid(row=2, column=0, sticky="nsew")
        holder.columnconfigure(0, weight=1)
        holder.rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(holder, highlightthickness=0,
                                background=self.winfo_toplevel().cget("background"))
        self.canvas.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(holder, orient="vertical",
                               command=self.canvas.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(yscrollcommand=scroll.set)

        self.body = ttk.Frame(self.canvas, padding=(0, 0, 8, 8))
        self._body_id = self.canvas.create_window((0, 0), window=self.body,
                                                  anchor="nw")
        self.body.columnconfigure(0, weight=1)
        self.body.bind("<Configure>", self._on_body)
        self.canvas.bind("<Configure>", self._on_canvas)
        self.canvas.bind_all("<MouseWheel>", self._on_wheel)
        self._logo_image = None
        self.pulled = ""
        self.editing_bank: int | None = None

        self._build_ujp()
        self._build_documents()
        self._build_banks()
        self._build_efaktura()
        self._build_footer()

    # ------------------------------------------------------------- скрол
    def _on_body(self, _event=None) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas(self, event) -> None:
        self.canvas.itemconfigure(self._body_id, width=event.width)

    def _on_wheel(self, event) -> None:
        """Тркалцето лизга само кога овој екран е видлив."""
        if not self.winfo_ismapped():
            return
        self.canvas.yview_scroll(-event.delta // 120, "units")

    # ------------------------------------------------------------------ УЈП
    def _build_ujp(self) -> None:
        box = ttk.Labelframe(self.body, text="Официјални податоци (УЈП)",
                             padding=(12, 8, 12, 10))
        box.grid(row=0, column=0, sticky="ew")
        box.columnconfigure(0, weight=1)

        bar = ttk.Frame(box)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(bar, text="Барај:").pack(side="left")
        self.term = tk.StringVar()
        entry = ttk.Entry(bar, textvariable=self.term, width=32)
        entry.pack(side="left", padx=(4, 6))
        entry.bind("<Return>", lambda _e: self.pull_ujp())
        ttk.Button(bar, text="Повлечи од УЈП", width=18,
                   command=self.pull_ujp).pack(side="left")
        ttk.Label(bar, text="назив, дел од назив, ЕДБ или матичен број",
                  style="Small.TLabel").pack(side="left", padx=(10, 0))
        ttk.Button(bar, text="Регистрирај", width=14,
                   command=self.register).pack(side="right")
        self.reg_label = ttk.Label(bar, text="", style="Small.TLabel")
        self.reg_label.pack(side="right", padx=(0, 10))

        grid = ttk.Frame(box)
        grid.grid(row=1, column=0, sticky="ew")
        self.ujp = Form(grid, columns=4)
        self.ujp.add("ujp_naziv", "Назив (краток)", width=34, readonly=True)
        self.ujp.add("ujp_edb", "ЕДБ", width=16, readonly=True)
        self.ujp.add("ujp_embs", "ЕМБС", width=12, readonly=True)
        self.ujp.add("ujp_dejnost", "Дејност", width=30, readonly=True)
        self.ujp.newline()
        self.ujp.add("ujp_pln_naziv", "Полн назив", width=76, span=3, readonly=True)
        self.ujp.add("ujp_telefon", "Телефон", width=16, readonly=True)
        self.ujp.newline()
        self.ujp.add("ujp_adresa", "Адреса", width=34, readonly=True)
        self.ujp.add("ujp_grad", "Град", width=22, readonly=True)
        self.ujp.add("ujp_banka", "Банка", width=28, readonly=True)
        self.ujp.add("ujp_smetka", "Жиро сметка", width=18, readonly=True)

        self.pulled_label = ttk.Label(box, text="", style="Small.TLabel")
        self.pulled_label.grid(row=2, column=0, sticky="w", pady=(2, 0))

    # ------------------------------------------------------- документи и лого
    def _build_documents(self) -> None:
        box = ttk.Labelframe(self.body, text="Податоци за документите "
                                        "(фактури, испратници, профактури)",
                             padding=(12, 8, 12, 10))
        box.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        box.columnconfigure(0, weight=1)

        grid = ttk.Frame(box)
        grid.grid(row=0, column=0, sticky="ew")
        self.doc = Form(grid, columns=4)
        self.doc.add("firma_naziv", "Назив на фирмата *", width=34,
                     help="онака како што сакаш да стои на документот")
        self.doc.add("firma_direktor", "Управител", width=24)
        self.doc.add("firma_dejnost", "Дејност", width=30, span=2)
        self.doc.newline()
        self.doc.add("firma_adresa", "Улица и број", width=34)
        self.doc.add("firma_grad", "Град", width=22)
        self.doc.add("firma_postenski", "Пошт. број", width=8)
        self.doc.add("firma_drzava", "Држава", width=16)
        self.doc.newline()
        self.doc.add("firma_telefon", "Телефон", width=18)
        self.doc.add("firma_email", "Е-пошта", width=26)
        self.doc.add("firma_web", "Веб страна", width=26)
        self.doc.add("firma_edb", "ЕДБ (од УЈП)", width=16, readonly=True)
        self.doc.newline()

        row = ttk.Frame(box)
        row.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Label(row, text="Основна ДДВ стапка (%):").pack(side="left")
        self.vat_var = tk.StringVar(value="18")
        ttk.Combobox(row, textvariable=self.vat_var, width=6,
                     values=["18", "10", "5", "0"]).pack(side="left", padx=(4, 18))
        ttk.Label(row, text="Валута:").pack(side="left")
        self.currency_var = tk.StringVar(value="ден.")
        ttk.Combobox(row, textvariable=self.currency_var, width=8,
                     values=["ден.", "MKD", "EUR"]).pack(side="left", padx=(4, 18))
        self.vat_payer = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text="Регистриран за ДДВ",
                        variable=self.vat_payer).pack(side="left")

        logo = ttk.Frame(box)
        logo.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        ttk.Label(logo, text="Лого:").pack(side="left")
        self.logo_label = ttk.Label(logo, text="(нема лого)", style="Muted.TLabel")
        self.logo_label.pack(side="left", padx=(6, 10))
        ttk.Button(logo, text="Избери слика…", width=16,
                   command=self.pick_logo).pack(side="left")
        ttk.Button(logo, text="Отстрани", width=12,
                   command=self.clear_logo).pack(side="left", padx=(6, 14))
        self.logo_preview = ttk.Label(logo)
        self.logo_preview.pack(side="left")
        ttk.Label(logo, text="секоја слика се претвора во PNG и се копира во "
                             "data\\ — патува заедно со базата",
                  style="Small.TLabel").pack(side="left", padx=(14, 0))

    # ----------------------------------------------------------------- банки
    def _build_banks(self) -> None:
        box = ttk.Labelframe(self.body, text="Банки и трансакциски сметки",
                             padding=(12, 8, 12, 10))
        box.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        box.columnconfigure(0, weight=1)

        row = ttk.Frame(box)
        row.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(row, text="Банка:").pack(side="left")
        self.b_name = tk.StringVar()
        entry_bank = ttk.Entry(row, textvariable=self.b_name, width=30)
        entry_bank.pack(side="left", padx=(4, 12))
        ttk.Label(row, text="Трансакциска сметка:").pack(side="left")
        self.b_account = tk.StringVar()
        entry_acc = ttk.Entry(row, textvariable=self.b_account, width=20)
        entry_acc.pack(side="left", padx=(4, 12))
        self.b_show = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text="Прикажи на фактура",
                        variable=self.b_show).pack(side="left", padx=(0, 12))
        self.b_active = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, text="Активна",
                        variable=self.b_active).pack(side="left", padx=(0, 12))
        self.btn_bank = ttk.Button(row, text="Додај", width=10,
                                   command=self.commit_bank)
        self.btn_bank.pack(side="left")
        entry_bank.bind("<Return>", lambda _e: entry_acc.focus_set())
        entry_acc.bind("<Return>", lambda _e: self.commit_bank())

        ttk.Label(box, text="Сметките означени со „на фактура“ се печатат на "
                            "документите. Изводите се водат по сметка.",
                  style="Small.TLabel").grid(row=1, column=0, sticky="w", pady=(0, 4))

        self.bank_table = DataTable(box, BANK_COLUMNS, height=7,
                                    on_activate=lambda _i: self.edit_bank(),
                                    on_select=lambda _i: self._update_bank_buttons())
        self.bank_table.grid(row=2, column=0, sticky="nsew")
        self.bank_table.tree.bind("<Delete>", lambda _e: self.delete_bank())

        tools = ttk.Frame(box)
        tools.grid(row=3, column=0, sticky="w", pady=(6, 0))
        self.btn_edit_bank = ttk.Button(tools, text="Измени", width=12,
                                        command=self.edit_bank)
        self.btn_edit_bank.pack(side="left")
        self.btn_del_bank = ttk.Button(tools, text="Избриши", width=12,
                                       command=self.delete_bank)
        self.btn_del_bank.pack(side="left", padx=(6, 0))

    def _update_bank_buttons(self) -> None:
        state = ["!disabled"] if self.bank_table.selected_id() is not None \
            else ["disabled"]
        self.btn_edit_bank.state(state)
        self.btn_del_bank.state(state)

    def refresh_banks(self) -> None:
        rows = []
        for row in bank_accounts.list_all():
            count = bank_accounts.statement_count(row["account_no"])
            rows.append({
                "id": row["id"],
                "bank_name": row["bank_name"] or "—",
                "account_no": row["account_no"],
                "show": "✓" if row["show_on_invoice"] else "",
                "active": "Да" if row["active"] else "Не",
                "statements": count or "", "statements_raw": count,
                "_tags": () if row["active"] else ("neaktiven",),
            })
        self.bank_table.set_rows(rows)
        self._update_bank_buttons()

    def commit_bank(self) -> None:
        data = {"bank_name": self.b_name.get().strip(),
                "account_no": self.b_account.get().strip(),
                "show_on_invoice": self.b_show.get(),
                "active": self.b_active.get()}
        try:
            bank_accounts.save(self.editing_bank, data)
        except bank_accounts.ValidationError as exc:
            widgets.error(self, str(exc))
            return
        self.editing_bank = None
        self.btn_bank.configure(text="Додај")
        for var in (self.b_name, self.b_account):
            var.set("")
        self.b_show.set(True)
        self.b_active.set(True)
        self.refresh_banks()
        self.status("Зачувана сметка.")

    def edit_bank(self) -> None:
        rec_id = self.bank_table.selected_id()
        if rec_id is None:
            return
        row = bank_accounts.get(int(rec_id))
        if row is None:
            return
        self.editing_bank = int(rec_id)
        self.b_name.set(row["bank_name"])
        self.b_account.set(row["account_no"])
        self.b_show.set(bool(row["show_on_invoice"]))
        self.b_active.set(bool(row["active"]))
        self.btn_bank.configure(text="Зачувај")

    def delete_bank(self) -> None:
        rec_id = self.bank_table.selected_id()
        if rec_id is None:
            return
        row = bank_accounts.get(int(rec_id))
        if row is None:
            return
        if not widgets.confirm(self, f"Да се избрише сметката {row['account_no']}?"):
            return
        try:
            bank_accounts.delete(int(rec_id))
        except bank_accounts.ValidationError as exc:
            widgets.info(self, str(exc), title="Бришењето не е можно")
            return
        self.refresh_banks()

    # ------------------------------------------------------------------ лого
    def pick_logo(self) -> None:
        path = filedialog.askopenfilename(parent=self, title="Избери лого",
                                          filetypes=LOGO_TYPES)
        if not path:
            return
        source = Path(path)
        target = DATA_DIR / "logo.png"
        try:
            ensure_dir(DATA_DIR)
            for old in DATA_DIR.glob("logo.*"):
                if old != target:
                    old.unlink()
            if source.suffix.lower() == ".png":
                if source.resolve() != target.resolve():
                    shutil.copy2(source, target)
            elif not winprint.convert_to_png(source, target):
                widgets.error(self, "Сликата не може да се претвори во PNG.\n\n"
                                    "Пробај да зачуваш PNG од сликата и избери го "
                                    "него.")
                return
        except OSError as exc:
            widgets.error(self, f"Логото не може да се копира:\n{exc}")
            return
        try:
            relative = str(target.relative_to(app_dir()))
        except ValueError:
            relative = str(target)
        settings.set(LOGO_KEY, relative)
        self._show_logo()
        self.status("Логото е поставено.")

    def clear_logo(self) -> None:
        if not settings.get(LOGO_KEY, "").strip():
            return
        if not widgets.confirm(self, "Да се отстрани логото?"):
            return
        path = logo_path()
        settings.set(LOGO_KEY, "")
        if path is not None:
            try:
                path.unlink()
            except OSError:
                pass
        self._show_logo()

    def _show_logo(self) -> None:
        path = logo_path()
        self._logo_image = None
        self.logo_preview.configure(image="", text="")
        if path is None:
            # Ако патеката покажува на слика што ја нема, подесувањето се чисти
            # само — инаку документот молчешкум останува без лого.
            if settings.get(LOGO_KEY, "").strip():
                settings.set(LOGO_KEY, "")
            self.logo_label.configure(text="(нема лого)")
            return
        self.logo_label.configure(text=path.name)
        try:
            image = tk.PhotoImage(file=str(path))
            factor = max(1, image.width() // 220, image.height() // 56)
            if factor > 1:
                image = image.subsample(factor, factor)
            self._logo_image = image           # мора да се држи референца
            self.logo_preview.configure(image=image, text="")
        except tk.TclError:
            self.logo_preview.configure(text="(сликата не може да се прикаже)")

    # -------------------------------------------------------- е-Фактура
    def _build_efaktura(self) -> None:
        """Сè што е потребно за е-Фактура стои тука, не во кодот.

        Кога софтверот ќе работи за друга фирма, се менуваат сертификатот и
        податоците на овој екран — ништо не се препишува во апликацијата.
        """
        box = ttk.Labelframe(self.body, text="е-Фактура (УЈП)",
                             padding=(12, 8, 12, 10))
        box.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        box.columnconfigure(0, weight=1)

        row = ttk.Frame(box)
        row.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(row, text="Сертификат за потпишување:").pack(side="left")
        self.cert_var = tk.StringVar()
        self.cert_combo = ttk.Combobox(row, textvariable=self.cert_var,
                                       state="readonly", width=58)
        self.cert_combo.pack(side="left", padx=(6, 6))
        self.cert_combo.bind("<<ComboboxSelected>>", self._show_serial)
        ttk.Button(row, text="Освежи", width=10,
                   command=self.refresh_certs).pack(side="left")
        self.cert_note = ttk.Label(row, text="", style="Small.TLabel")
        self.cert_note.pack(side="left", padx=(12, 0))

        red = ttk.Frame(box)
        red.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        ttk.Label(red, text="Сериски број (X-SERIAL-NUMBER):").pack(side="left")
        self.serial_label = ttk.Label(red, text="—", style="Path.TLabel")
        self.serial_label.pack(side="left", padx=(6, 12))
        ttk.Label(red, text="ова се праќа во заглавието кон УЈП; се чита од "
                            "избраниот сертификат, не се пишува рачно",
                  style="Small.TLabel").pack(side="left")

        grid = ttk.Frame(box)
        grid.grid(row=2, column=0, sticky="ew")
        self.ef = Form(grid, columns=4)
        self.ef.add("efaktura_eujp_id", "еУЈП-ид на потписникот", width=24)
        self.ef.add("efaktura_ulica", "Улица (како во УЈП)", width=28)
        self.ef.add("efaktura_broj", "Број", width=10)
        self.ef.add("efaktura_postenski", "Пошт. код", width=8)
        self.ef.newline()
        self.ef.add("efaktura_grad", "Град (како во УЈП)", width=24)

        line = ttk.Frame(box)
        line.grid(row=3, column=0, sticky="ew", pady=(4, 0))
        ttk.Label(line, text="Околина:").pack(side="left")
        self.env_var = tk.StringVar(value="test")
        ttk.Combobox(line, textvariable=self.env_var, state="readonly",
                     width=26, values=["test — пробна (без правно дејство)",
                                       "prod — вистинска"]).pack(
            side="left", padx=(6, 16))
        ttk.Label(line, text="Улицата, бројот и градот се полнат сами при "
                             "„Повлечи од УЈП“; поштенскиот код УЈП не го дава.",
                  style="Small.TLabel").pack(side="left")

    def refresh_certs(self) -> None:
        """Го чита списокот сертификати од Windows (токенот мора да е вклучен)."""
        self._certs = sertifikati.list_certificates()
        values = [c.label for c in self._certs]
        self.cert_combo.configure(values=values)
        if not values:
            self.cert_note.configure(
                text="Нема сертификати — вклучи го токенот, па „Освежи“.",
                foreground=theme.C["warn"])
        else:
            dobri = sum(1 for c in self._certs if c.usable)
            self.cert_note.configure(
                text=(f"{len(values)} најдени, {dobri} можат да потпишуваат"
                      if dobri else
                      f"{len(values)} најдени, ниту еден не може да потпише — "
                      "вклучи го токенот"),
                foreground=theme.C["ok"] if dobri else theme.C["warn"])
        self._show_serial()

    def _show_serial(self, _event=None) -> None:
        """Го покажува серискиот број на избраниот сертификат."""
        serial = self._cert_serial()
        self.serial_label.configure(text=serial or "—")

    def _select_cert(self, serial: str) -> None:
        for item in getattr(self, "_certs", []):
            if item.serial == str(serial or "").strip().upper():
                self.cert_var.set(item.label)
                self._show_serial()
                return
        self.cert_var.set("")
        if serial:
            self.cert_note.configure(
                text=f"Зачуваниот сертификат ({serial}) не е најден — "
                     "вклучи го токенот.", foreground=theme.C["warn"])

    def _cert_serial(self) -> str:
        label = self.cert_var.get().strip()
        for item in getattr(self, "_certs", []):
            if item.label == label:
                return item.serial
        return str(settings.get("efaktura_cert_serial", "")).strip()

    # --------------------------------------------------------------- подножје
    def _build_footer(self) -> None:
        self.message = ttk.Label(self.body, text="", style="Muted.TLabel")
        self.message.grid(row=4, column=0, sticky="w", pady=(8, 0))

        buttons = ttk.Frame(self.body)
        buttons.grid(row=5, column=0, sticky="ew", pady=(6, 0))
        ttk.Button(buttons, text="Зачувај", width=14, command=self.save).pack(side="left")
        ttk.Button(buttons, text="Врати ги промените", width=22,
                   command=self.reload).pack(side="left", padx=(6, 0))

    # ---------------------------------------------------------- регистрација
    def _nezachuvani(self) -> bool:
        """Дали во формата има променето нешто што сè уште не е зачувано."""
        saved = settings.all()
        return any(str(saved.get(key) or "").strip() != value
                   for key, value in self.doc.values().items())

    def register(self) -> None:
        """Го пријавува примерокот кај издавачот и ги отклучува назив и лого."""
        if registracija.aktivna():
            self._prikazi_registracija()
            return

        # Се праќа она што е ЗАЧУВАНО — инаку човекот се регистрира со стари
        # податоци, а мисли дека пратил нови.
        if self._nezachuvani():
            if not widgets.confirm(
                self, "Има промени што не се зачувани.\n\n"
                      "Регистрацијата ги праќа зачуваните податоци. Да ги "
                      "зачувам прво?", title="Регистрација"):
                return
            self.save()

        missing = registracija.nedostasuva()
        if missing:
            widgets.info(
                self, f"Прво пополни го полето „{missing}“ во податоците за "
                      "фирмата и зачувај.\n\nБез него регистрацијата нема смисла "
                      "— серверот не знае кој се пријавува.",
                title="Регистрација")
            return

        self._posti()

    def _posti(self, proverka: bool = False) -> None:
        """Самиот повик — преку готовиот образец, за да не замрзне прозорецот."""
        try:
            rezultat = widgets.run_with_progress(
                self, "Регистрација",
                registracija.proveri_sega if proverka else registracija.registriraj,
                message="Се поврзувам со серверот…")
        except registracija.VrskaError:
            widgets.error(
                self, "Нема врска со серверот.\n\nПровери го интернетот и обиди "
                      "се повторно. Апликацијата продолжува да работи нормално и "
                      "без регистрација.", title="Регистрација")
            return
        except Exception as exc:  # noqa: BLE001
            widgets.error(self, f"Регистрацијата не успеа:\n{exc}",
                          title="Регистрација")
            return

        self.reload()
        if rezultat.ok:
            widgets.info(self, rezultat.message, title="Регистрација")
        else:
            widgets.error(self, rezultat.message, title="Регистрација")

    def _prikazi_registracija(self) -> None:
        """Кога е веќе регистрирана — состојба и понуда за повторна проверка."""
        redovi = [f"Фирма: {settings.get('firma_naziv', '')}",
                  f"Лиценцен клуч: {registracija.licenca()}"]
        if registracija.datum():
            redovi.append(f"Регистрирана на: {registracija.datum()}")
        if widgets.confirm(
            self, "\n".join(redovi) + "\n\nДа проверам кај серверот повторно?",
            title="Регистрација",
        ):
            self._posti(proverka=True)

    # ---------------------------------------------------------------- дејства
    def on_show(self) -> None:
        self.reload()

    def reload(self) -> None:
        values = settings.all()
        self.ujp.set_values(values)
        self.doc.set_values(values)
        self.vat_var.set(values.get("ddv_stapka") or "18")
        self.currency_var.set(values.get("valuta") or "ден.")
        self.vat_payer.set(str(values.get("firma_danocen_obvrznik") or "1") == "1")
        self.pulled = str(values.get("ujp_povlecen") or "").strip()
        self._show_pulled()
        self.reg_label.configure(
            text=registracija.sostojba_tekst(),
            foreground=theme.C["ok"] if registracija.aktivna() else theme.C["warn"])
        self._show_logo()
        self.refresh_banks()
        self.refresh_certs()
        self.ef.set_values(values)
        self._select_cert(values.get('efaktura_cert_serial', ''))
        self.env_var.set('prod — вистинска'
                         if str(values.get('efaktura_okolina')) == 'prod'
                         else 'test — пробна (без правно дејство)')
        self.message.configure(text="")

    def _show_pulled(self, fresh: bool = False) -> None:
        self.pulled_label.configure(
            text=f"Повлечено од УЈП: {self.pulled}   ·   овие полиња не се менуваат"
            if self.pulled else "Сè уште не е повлечено од УЈП.",
            foreground=theme.C["ok"] if fresh else theme.C["muted"])

    def pull_ujp(self) -> None:
        term = self.term.get().strip() or self.doc.get("firma_naziv")
        if len(term) < 3:
            widgets.info(self, "Внеси назив, дел од назив, ЕДБ или матичен број "
                               "(барем 3 знаци).", title="Повлечи од УЈП")
            return

        def fetch(work, message):
            try:
                return widgets.run_with_progress(self, "Повлекување од УЈП", work,
                                                 message=message)
            except ujp.UjpError as exc:
                widgets.error(self, str(exc), title="УЈП")
            except Exception as exc:  # noqa: BLE001
                widgets.error(self, f"Повлекувањето не успеа:\n\n{exc}", title="УЈП")
            return None

        result = fetch(lambda: ujp.lookup(term), f"Се бара „{term}“ на ujp.gov.mk…")
        if result is None:
            return
        if result["kind"] == "none":
            widgets.info(self, f"УЈП нема резултат за „{term}“.", title="Повлечи од УЈП")
            return
        if result["kind"] == "list":
            hit = choose_company(self, result["hits"])
            if not hit:
                return
            data = fetch(lambda: ujp.fetch(hit), "Се повлекуваат деталите…")
            if not data:
                return
        else:
            data = result["data"]
        self._apply_ujp(data)

    def _apply_ujp(self, data: dict) -> None:
        """Официјалните полиња се полнат од УЈП; празните за документи исто."""
        from ...util import fmt_date, today

        values = ujp.to_partner(data)
        official = {
            "ujp_naziv": values.get("name") or "",
            "ujp_pln_naziv": values.get("full_name") or "",
            "ujp_edb": values.get("tax_number") or "",
            "ujp_embs": values.get("reg_number") or "",
            "ujp_adresa": values.get("address") or "",
            "ujp_grad": values.get("city") or "",
            "ujp_telefon": values.get("phone") or "",
            "ujp_banka": values.get("bank_name") or "",
            "ujp_smetka": values.get("bank_account") or "",
            "ujp_dejnost": data.get("activity") or "",
        }
        self.ujp.set_values(official)
        self.doc.set_values({"firma_edb": official["ujp_edb"]})

        # Празните полиња за документите се пополнуваат; дотераното не се гази.
        current = self.doc.values()
        prefill = {
            "firma_naziv": official["ujp_naziv"],
            "firma_dejnost": official["ujp_dejnost"],
            "firma_adresa": official["ujp_adresa"],
            "firma_grad": official["ujp_grad"],
            "firma_telefon": official["ujp_telefon"],
        }
        self.doc.set_values({k: v for k, v in prefill.items()
                             if v and not current.get(k)})

        # е-Фактура ја бара адресата разделена — УЈП ја дава слепена, па
        # тука се дели. Поштенски број УЈП НЕ дава; тој се внесува рачно.
        ulica, broj = ujp.split_address(official["ujp_adresa"])
        sega = self.ef.values()
        self.ef.set_values({key: value for key, value in {
            "efaktura_ulica": ulica,
            "efaktura_broj": broj,
            "efaktura_grad": ujp.split_city(official["ujp_grad"]),
        }.items() if value and not sega.get(key)})

        # Сметката од регистарот сама влегува меѓу сметките на фирмата.
        if official["ujp_smetka"]:
            try:
                bank_accounts.ensure(official["ujp_smetka"], official["ujp_banka"])
            except bank_accounts.ValidationError:
                pass
            self.refresh_banks()

        self.pulled = fmt_date(today())
        self._show_pulled(fresh=True)
        self.message.configure(text="Повлечено од УЈП — кликни „Зачувај“ за да остане.")

    def save(self) -> None:
        data = self.doc.values()
        if not data.get("firma_naziv"):
            self.message.configure(text="Полето „Назив на фирмата“ е задолжително.")
            self.doc.widgets["firma_naziv"].focus_set()
            return
        payload = dict(self.ujp.values())
        payload.update(data)
        payload["ujp_povlecen"] = self.pulled
        payload["ddv_stapka"] = self.vat_var.get().strip() or "18"
        payload["valuta"] = self.currency_var.get().strip() or "ден."
        payload["firma_danocen_obvrznik"] = "1" if self.vat_payer.get() else "0"
        payload.update(self.ef.values())
        payload["efaktura_cert_serial"] = self._cert_serial()
        payload["efaktura_okolina"] = ("prod"
                                       if self.env_var.get().startswith("prod")
                                       else "test")
        # Првата сметка што се печати останува и во подесувањата — за
        # документите што ја бараат само едната.
        first = bank_accounts.for_invoice()
        payload["firma_banka"] = first[0]["bank_name"] if first else ""
        payload["firma_ziro_smetka"] = first[0]["account_no"] if first else ""
        try:
            settings.save_many(payload)
        except Exception as exc:  # noqa: BLE001
            widgets.error(self, f"Не може да се зачува:\n{exc}")
            return
        self.message.configure(text="✔ Зачувано.")
        self.app.refresh_title()
        self.status("Подесувањата за фирмата се зачувани.")
