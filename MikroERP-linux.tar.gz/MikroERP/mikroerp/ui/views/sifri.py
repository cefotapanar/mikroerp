# -*- coding: utf-8 -*-
"""ПОДЕСУВАЊА → Шифри на плаќање.

Шифрарникот доаѓа полн со шифрите што сигурно се сретнуваат во изводите.
Останатите од официјалната листа се додаваат тука — штом ќе се внесат, веднаш
важат и правилата за автоматско распределување во изводите.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...repo import expenses, paycodes
from .. import widgets
from ..widgets import Field, FormDialog
from .base import CrudView

GROUPS = ["Лични примања", "Промет и услуги", "Чек и меница", "Кредити и депозити",
          "Камати и провизии", "Уплати и исплати", "Пренос и сторно", "Брокерски"]


class SifriView(CrudView):
    title = "Шифри на плаќање"
    subtitle = ("официјалната листа на НБРСМ; правилата тука одлучуваат "
                "што ќе направи изводот сам")
    empty_text = "Нема шифри."
    new_text = "Нова"

    columns = (
        {"key": "code", "text": "Шифра", "width": 70, "anchor": "center"},
        {"key": "name", "text": "Назив", "width": 330, "stretch": True},
        {"key": "category", "text": "Категорија", "width": 120},
        {"key": "auto_expense", "text": "Авто-трошок", "width": 95, "anchor": "center"},
        {"key": "expense_category", "text": "Категорија на трошок", "width": 165},
        {"key": "ask_always", "text": "Секогаш прашувај", "width": 130, "anchor": "center"},
        {"key": "active", "text": "Активна", "width": 70, "anchor": "center"},
    )

    def build_filters(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Група:", style="Muted.TLabel").pack(side="left",
                                                                    padx=(0, 4))
        self.group_var = tk.StringVar(value="Сите")
        combo = ttk.Combobox(parent, textvariable=self.group_var, state="readonly",
                             width=20, values=["Сите"] + GROUPS)
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

        self.only_rules = tk.BooleanVar(value=False)
        ttk.Checkbutton(parent, text="само со правило", variable=self.only_rules,
                        command=self.refresh).pack(side="left", padx=(14, 0))

    def fetch(self, search: str) -> list[dict]:
        group = getattr(self, "group_var", None)
        group = "" if group is None or group.get() == "Сите" else group.get()
        only_rules = bool(getattr(self, "only_rules", None) and self.only_rules.get())
        rows = []
        for row in paycodes.list_all(search):
            if group and row["category"] != group:
                continue
            if only_rules and not (row["auto_expense"] or row["ask_always"]
                                   or row["expense_category"]):
                continue
            rows.append({
                "id": row["code"],
                "code": row["code"],
                "name": row["name"],
                "category": row["category"],
                "auto_expense": "Да" if row["auto_expense"] else "",
                "expense_category": row["expense_category"],
                "ask_always": "Да" if row["ask_always"] else "",
                "active": "Да" if row["active"] else "Не",
                "note": row["note"],
                "_tags": () if row["active"] else ("neaktiven",),
            })
        self.set_subtitle(f"официјалната листа на НБРСМ  •  {len(rows)} шифри  •  "
                          "правилата тука одлучуваат што ќе направи изводот сам")
        return rows

    def on_activate(self, rec_id) -> None:
        self.action_edit()

    # шифрата е текст, па табелата работи со неа наместо со број
    def action_edit(self, *_a) -> None:
        row = self.table.selected_row()
        if row is not None and self.open_form(row["code"]):
            self.refresh()

    def action_delete(self, *_a) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        if not widgets.confirm(self, f"Да се избрише шифрата {row['code']}?"):
            return
        paycodes.delete(row["code"])
        self.refresh()

    def describe(self, row: dict) -> str:
        return f"{row['code']} — {row['name']}"

    def delete_record(self, rec_id) -> None:
        paycodes.delete(rec_id)

    def open_form(self, code) -> bool:
        record = paycodes.get(code) if code else None
        values = dict(record) if record is not None else {"active": True, "code": ""}

        fields = [
            Field("code", "Шифра", col=2, chars=6, required=True,
                  readonly=bool(code)),
            Field("name", "Назив", col=10, required=True),
            Field("category", "Група", kind="combo_edit", col=4, chars=20,
                  values=GROUPS),
            Field("sep", "", kind="sep"),
            Field("auto_expense", "Сама создава трошок", kind="check", col=5),
            Field("expense_category", "Категорија на трошокот", kind="combo_edit",
                  col=5, chars=24, values=expenses.categories()),
            Field("ask_always", "Не погодувај клиент (банка/менувачница)",
                  kind="check", col=8),
            Field("active", "Активна", kind="check", col=4),
            Field("note", "Забелешка", col=12),
        ]

        def save(data: dict):
            paycodes.save(data.get("code") or code, data)
            self.status("Зачувана шифра " + str(data.get("code") or code))
            return True

        title = "Нова шифра" if not code else f"Шифра {code}"
        return FormDialog(self, title, fields, values, on_save=save,
                          width=740).show() is not None
