# -*- coding: utf-8 -*-
"""Поврзување на една ставка од извод со документ или трошок.

Кога клиентот е познат (погоден или рачно избран) тука се гледаат сите негови
отворени документи; се штиклираат оние што уплатата ги затвора. Ако нема
фактура, ставката може да се води како **трошок** со категорија и ДДВ.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, q2
from ...repo import expenses, partners, payments, statements
from ...util import fmt_date
from .. import theme, widgets
from ..widgets import DataTable, SearchPicker
from .klienti import new_partner_dialog

OPEN_COLUMNS = (
    {"key": "mark", "text": "✓", "width": 34, "anchor": "center"},
    {"key": "kind", "text": "Документ", "width": 120},
    {"key": "doc_no", "text": "Број", "width": 95},
    {"key": "date", "text": "Датум", "width": 85},
    {"key": "total", "text": "Вкупно", "width": 105, "anchor": "e", "sort": "num"},
    {"key": "paid", "text": "Платено", "width": 100, "anchor": "e", "sort": "num"},
    {"key": "remaining", "text": "Останува", "width": 105, "anchor": "e", "sort": "num"},
    {"key": "assign", "text": "Се затвора со", "width": 115, "anchor": "e", "sort": "num"},
)


class LinkWindow(tk.Toplevel):
    def __init__(self, master, app, line: dict):
        super().__init__(master)
        self.app = app
        self.line = line
        self.saved = False
        self.marked: dict[tuple, D.__class__] = {}
        self.docs: list[dict] = []

        self.title("Поврзување на уплата")
        self.transient(master.winfo_toplevel())
        self.geometry("880x600")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        self._build_head()
        self._build_docs()
        self._build_expense()
        self._build_footer()

        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.bind("<Escape>", lambda _e: self.destroy())
        self._reload_docs()
        widgets.center_on(self, master.winfo_toplevel())
        self.grab_set()

    # ---------------------------------------------------------------- горе
    def _build_head(self) -> None:
        box = ttk.Labelframe(self, text="Ставка од извод", padding=(10, 6, 10, 8))
        box.grid(row=0, column=0, sticky="ew", padx=10, pady=(10, 4))

        row1 = ttk.Frame(box)
        row1.pack(fill="x")
        ttk.Label(row1, text=fmt_date(self.line["date"])).pack(side="left")
        ttk.Label(row1, text=self.line["direction"], style="Head.TLabel").pack(
            side="left", padx=(12, 12))
        ttk.Label(row1, text=fmt(self.line["amount"]) + " ден.",
                  style="Path.TLabel").pack(side="left")
        ttk.Label(row1, text=self.line.get("cp_name") or "", style="Muted.TLabel").pack(
            side="left", padx=(16, 0))

        row2 = ttk.Frame(box)
        row2.pack(fill="x", pady=(8, 0))
        ttk.Label(row2, text="Клиент:").pack(side="left")
        self.partner = SearchPicker(row2, self._partner_options(), width=34,
                                    on_select=lambda _v: self._reload_docs())
        self.partner.pack(side="left", padx=(4, 4))
        self.partner.set(str(self.line.get("partner_id") or ""))
        ttk.Button(row2, text="Нов клиент", width=12,
                   command=self.create_partner).pack(side="left")
        if self.line.get("purpose"):
            ttk.Label(row2, text="Намена: " + self.line["purpose"],
                      style="Small.TLabel").pack(side="left", padx=(16, 0))

    def _partner_options(self):
        return [(str(r["id"]), r["name"], f"{r['code']} {r['city']} {r['bank_account']}")
                for r in partners.list_all(only_active=True)]

    def create_partner(self) -> None:
        new_id = new_partner_dialog(self)
        if new_id:
            self.partner.set_options(self._partner_options())
            self.partner.set(str(new_id))
            self._reload_docs()

    # ------------------------------------------------------- отворени долгови
    def _build_docs(self) -> None:
        box = ttk.Labelframe(self, text="Отворени документи на клиентот",
                             padding=(10, 6, 10, 8))
        box.grid(row=2, column=0, sticky="nsew", padx=10, pady=4)
        box.columnconfigure(0, weight=1)
        box.rowconfigure(1, weight=1)

        ttk.Label(box, text="Клик на редот го штиклира/одштиклира документот. "
                            "Се затвора најмногу до износот на уплатата.",
                  style="Small.TLabel").grid(row=0, column=0, sticky="w", pady=(0, 4))

        self.table = DataTable(box, OPEN_COLUMNS, height=10,
                               on_activate=lambda _i: self.toggle())
        self.table.grid(row=1, column=0, sticky="nsew")
        self.table.tree.bind("<space>", lambda _e: self.toggle())
        self.table.tree.bind("<ButtonRelease-1>", self._maybe_toggle, add="+")

    def _maybe_toggle(self, event) -> None:
        """Клик врз колоната ✓ штиклира.“"""
        if self.table.tree.identify_column(event.x) == "#1":
            self.toggle()

    def _reload_docs(self) -> None:
        partner_id = self.partner.get() if hasattr(self, "partner") else None
        self.docs = (payments.open_documents(int(partner_id), self.line["direction"])
                     if partner_id else [])
        # старите означувања што повеќе не постојат — тргни ги
        keys = {(d["kind"], d["id"]) for d in self.docs}
        self.marked = {k: v for k, v in self.marked.items() if k in keys}
        self._refresh()

    def _refresh(self) -> None:
        rows = []
        for index, doc in enumerate(self.docs):
            key = (doc["kind"], doc["id"])
            assigned = self.marked.get(key)
            rows.append({
                "id": index,
                "mark": "✓" if assigned is not None else "",
                "kind": payments.LABEL.get(doc["kind"], doc["kind"]),
                "doc_no": doc["doc_no"],
                "date": fmt_date(doc["date"]), "date_raw": doc["date"],
                "total": fmt(doc["total"]), "total_raw": float(doc["total"]),
                "paid": fmt(doc["paid"]) if doc["paid"] else "",
                "paid_raw": float(doc["paid"]),
                "remaining": fmt(doc["remaining"]), "remaining_raw": float(doc["remaining"]),
                "assign": fmt(assigned) if assigned is not None else "",
                "assign_raw": float(assigned) if assigned is not None else 0.0,
                "_tags": ("marked",) if assigned is not None else (),
            })
        self.table.set_rows(rows)
        self._update_totals()

    def toggle(self) -> None:
        index = self.table.selected_id()
        if index is None or index >= len(self.docs):
            return
        doc = self.docs[index]
        key = (doc["kind"], doc["id"])
        if key in self.marked:
            del self.marked[key]
        else:
            free = self._free_amount()
            if free <= 0:
                widgets.info(self, "Целиот износ на уплатата е веќе распореден.")
                return
            self.marked[key] = q2(min(D(doc["remaining"]), free))
        self._refresh()

    def _assigned_total(self):
        return q2(sum(self.marked.values(), D(0)))

    def _free_amount(self):
        return q2(D(self.line["amount"]) - self._assigned_total())

    def _update_totals(self) -> None:
        assigned = self._assigned_total()
        free = q2(D(self.line["amount"]) - assigned)
        self.total_label.configure(text=f"Распоредено: {fmt(assigned)}     "
                                        f"Нераспоредено: {fmt(free)}")
        self.total_label.configure(
            foreground=theme.C["ok"] if free == 0 else theme.C["muted"])

    # ------------------------------------------------------------- трошок
    def _build_expense(self) -> None:
        box = ttk.Labelframe(self, text="Или: ставката е трошок",
                             padding=(10, 6, 10, 8))
        box.grid(row=3, column=0, sticky="ew", padx=10, pady=4)

        row = ttk.Frame(box)
        row.pack(fill="x")
        current = self.line.get("expense") or {}
        self.is_expense = tk.BooleanVar(value=bool(current))
        ttk.Checkbutton(row, text="Трошок", variable=self.is_expense,
                        command=self._toggle_expense).pack(side="left", padx=(0, 14))

        ttk.Label(row, text="Категорија:").pack(side="left")
        self.category = tk.StringVar(value=current.get("category")
                                     or expenses.DEFAULT_BANK_CATEGORY)
        self.cat_combo = ttk.Combobox(row, textvariable=self.category, width=24,
                                      values=expenses.categories())
        self.cat_combo.pack(side="left", padx=(4, 14))

        ttk.Label(row, text="ДДВ %:").pack(side="left")
        self.vat = tk.StringVar(value=fmt(current.get("vat_rate") or 0, 0))
        self.vat_combo = ttk.Combobox(row, textvariable=self.vat, state="readonly",
                                      width=5, values=expenses.VAT_RATES)
        self.vat_combo.pack(side="left", padx=(4, 14))

        ttk.Label(row, text="Опис:").pack(side="left")
        self.description = tk.StringVar(
            value=current.get("description") or self.line.get("purpose") or "")
        self.desc_entry = ttk.Entry(row, textvariable=self.description, width=30)
        self.desc_entry.pack(side="left", padx=(4, 0))

        ttk.Label(box, text="Ако нема фактура, уплатата се води како трошок. "
                            "Ако не избереш ДДВ, се смета 0.",
                  style="Small.TLabel").pack(anchor="w", pady=(6, 0))
        self._toggle_expense()

    def _toggle_expense(self) -> None:
        state = "normal" if self.is_expense.get() else "disabled"
        self.cat_combo.configure(state="readonly" if state == "normal" else "disabled")
        self.vat_combo.configure(state="readonly" if state == "normal" else "disabled")
        self.desc_entry.configure(state=state)

    # ------------------------------------------------------------- подножје
    def _build_footer(self) -> None:
        footer = ttk.Frame(self, padding=(10, 4, 10, 4))
        footer.grid(row=4, column=0, sticky="ew")
        self.total_label = ttk.Label(footer, text="", style="Head.TLabel")
        self.total_label.pack(side="left")

        buttons = ttk.Frame(self, padding=(10, 4, 10, 10))
        buttons.grid(row=5, column=0, sticky="ew")
        ttk.Button(buttons, text="Откажи", width=12, command=self.destroy).pack(side="right")
        ttk.Button(buttons, text="Потврди", width=14, command=self.save).pack(
            side="right", padx=(0, 6))

    def save(self) -> None:
        partner_id = self.partner.get()
        self.line["partner_id"] = int(partner_id) if partner_id else None
        if partner_id and not self.line.get("matched_by"):
            self.line["matched_by"] = "рачно"
        self.line["targets"] = [
            {"kind": kind, "id": target_id, "amount": amount}
            for (kind, target_id), amount in self.marked.items()
        ]
        if self.is_expense.get():
            self.line["expense"] = {
                "category": self.category.get().strip() or expenses.DEFAULT_BANK_CATEGORY,
                "description": self.description.get().strip(),
                "vat_rate": self.vat.get() or 0,
            }
        else:
            self.line.pop("expense", None)
        self.saved = True
        self.destroy()

    def show(self) -> bool:
        self.wait_window(self)
        return self.saved
