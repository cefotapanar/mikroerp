# -*- coding: utf-8 -*-
"""МАТЕРИЈАЛНО → Приемници."""

from __future__ import annotations

from ...money import fmt
from ...repo import links, purchases, receipts
from ...util import fmt_date
from .. import widgets
from ..widgets import Toolbar
from .base import CrudView
from . import links_ui
from .priemnica_form import PriemnicaWindow


class PriemniciView(CrudView):
    title = "Приемници"
    print_kind = "priemnica"
    subtitle = "влез на стока во магацин"
    empty_text = "Нема приемници. Кликни „Нова“ за да внесеш влез на стока."
    new_text = "Нова"

    columns = (
        {"key": "doc_no", "text": "Број", "width": 100},
        {"key": "date", "text": "Датум", "width": 90},
        {"key": "partner_name", "text": "Добавувач", "width": 240, "stretch": True},
        {"key": "supplier_doc", "text": "Док. од добавувач", "width": 130},
        {"key": "lines_count", "text": "Ставки", "width": 60, "anchor": "e", "sort": "num"},
        {"key": "total_net", "text": "Основица", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "total_vat", "text": "ДДВ", "width": 90, "anchor": "e", "sort": "num"},
        {"key": "total_gross", "text": "Вкупно", "width": 105, "anchor": "e", "sort": "num"},
        {"key": "invoice_no", "text": "Влезна фактура", "width": 115},
    )

    def extra_buttons(self, toolbar: Toolbar) -> None:
        self.btn_invoice = toolbar.button("Креирај влезна фактура",
                                          self.action_invoice, width=23)
        self.btn_link = toolbar.button("Поврзи со влезна фактура", self.action_link,
                                       width=25)

    def update_extra_buttons(self, row: dict | None) -> None:
        for name in ("btn_invoice", "btn_link"):
            button = getattr(self, name, None)
            if button is not None:
                button.state(["!disabled"] if row is not None else ["disabled"])

    def action_invoice(self) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        if not widgets.confirm(
            self,
            f"Од приемницата {row['doc_no']} да се направи влезна фактура?\n\n"
            "Стоката веќе е внесена — фактурата само ја евидентира обврската.",
            title="Фактурирај",
        ):
            return
        try:
            new_id = purchases.from_receipt(int(row["id"]))
        except (ValueError, RuntimeError) as exc:
            widgets.error(self, str(exc))
            return
        record = purchases.get(new_id)
        self.status(f"Направена влезна фактура {record['doc_no']} "
                    f"по приемница {row['doc_no']}.")
        self.refresh()

    def action_link(self) -> None:
        """Приемницата се закачува на веќе внесена влезна фактура."""
        row = self.table.selected_row()
        if row is None:
            return
        if links_ui.link_to_invoice(self, links.PRIEMNICA, row):
            self.refresh()

    def fetch(self, search: str) -> list[dict]:
        rows = []
        for rec in receipts.list_all(search):
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "partner_name": rec["partner_name"] or "—",
                "supplier_doc": rec["supplier_doc"],
                "lines_count": rec["lines_count"], "lines_count_raw": rec["lines_count"],
                "total_net": fmt(rec["total_net"]), "total_net_raw": rec["total_net"],
                "total_vat": fmt(rec["total_vat"]), "total_vat_raw": rec["total_vat"],
                "total_gross": fmt(rec["total_gross"]), "total_gross_raw": rec["total_gross"],
                "partner_id": rec["partner_id"],
                "invoice_no": links.target_label(links.PRIEMNICA, int(rec["id"])),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['doc_no']} ({row['partner_name']})"

    def delete_record(self, rec_id: int) -> None:
        # Ако од таа стока веќе е издадено нешто, слојот за залиха ќе одбие.
        receipts.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        return PriemnicaWindow(self, self.app, rec_id).show()
