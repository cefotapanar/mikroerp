# -*- coding: utf-8 -*-
"""ФАКТУРИ → Влезни фактури."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...money import D, fmt, q2
from ...repo import links, payments, purchases
from ...util import fmt_date
from ..widgets import Toolbar
from .base import CrudView
from .doc_window import DocumentWindow
from .prodazba import payments_window


class VleznaFakturaWindow(DocumentWindow):
    doc_label = "Влезна фактура"
    partner_label = "Добавувач"
    partner_as_supplier = True
    save_hint = "Самостојната влезна фактура сама ја внесува стоката во магацин."
    repo = purchases
    print_kind = "vlezna_faktura"

    def default_price(self, item_row):
        return item_row["purchase_price"]

    def build_header_extra(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Фактура бр. (кај добавувачот):").pack(side="left")
        self.supplier_doc_var = tk.StringVar(value=self.header_data["supplier_doc"])
        ttk.Entry(parent, textvariable=self.supplier_doc_var, width=16).pack(
            side="left", padx=(4, 14))

        ttk.Label(parent, text="Датум на фактурата:").pack(side="left")
        self.supplier_date_var = tk.StringVar(
            value=fmt_date(self.header_data["supplier_date"]))
        ttk.Entry(parent, textvariable=self.supplier_date_var, width=11).pack(
            side="left", padx=(4, 14))

        ttk.Label(parent, text="Рок на плаќање:").pack(side="left")
        self.due_var = tk.StringVar(value=fmt_date(self.header_data["due_date"]))
        ttk.Entry(parent, textvariable=self.due_var, width=11).pack(side="left", padx=(4, 14))

        if self.header_data.get("receipt_id"):
            from ...repo import receipts
            receipt = receipts.get(int(self.header_data["receipt_id"]))
            ttk.Label(parent, text=f"По приемница {receipt['doc_no']} — "
                                   "стоката веќе е внесена",
                      style="Muted.TLabel").pack(side="left")
        else:
            self.update_prices_var = tk.BooleanVar(value=self.header_data["update_prices"])
            ttk.Checkbutton(parent, text="Запиши ја набавната цена",
                            variable=self.update_prices_var).pack(side="left")

    def build_payments(self, parent):
        if not self.doc_id:
            return None
        record = purchases.get(self.doc_id)
        if record is None:
            return None
        from .prodazba import payments_panel
        return payments_panel(parent, payments.KIND_PURCHASE, self.doc_id,
                              record["total_gross"])

    def pull_header_extra(self) -> None:
        self.header_data["supplier_doc"] = self.supplier_doc_var.get().strip()
        self.header_data["supplier_date"] = self._norm_date(self.supplier_date_var.get())
        self.header_data["due_date"] = self._norm_date(self.due_var.get())
        if hasattr(self, "update_prices_var"):
            self.header_data["update_prices"] = bool(self.update_prices_var.get())


class VlezniFakturiView(CrudView):
    title = "Влезни фактури"
    print_kind = "vlezna_faktura"
    subtitle = "обврски кон добавувачи"
    empty_text = "Нема влезни фактури."
    new_text = "Нова"

    columns = (
        {"key": "doc_no", "text": "Број", "width": 90},
        {"key": "date", "text": "Датум", "width": 80},
        {"key": "supplier_doc", "text": "Фактура бр.", "width": 110},
        {"key": "due_date", "text": "Рок", "width": 80},
        {"key": "partner_name", "text": "Добавувач", "width": 195, "stretch": True},
        {"key": "lines_count", "text": "Ставки", "width": 55, "anchor": "e", "sort": "num"},
        {"key": "total_net", "text": "Основица", "width": 95, "anchor": "e", "sort": "num"},
        {"key": "total_vat", "text": "ДДВ", "width": 85, "anchor": "e", "sort": "num"},
        {"key": "total_gross", "text": "Вкупно", "width": 100, "anchor": "e", "sort": "num"},
        {"key": "paid", "text": "Платено", "width": 90, "anchor": "e", "sort": "num"},
        {"key": "pay_status", "text": "Состојба", "width": 85},
        {"key": "receipt_no", "text": "Приемници", "width": 130},
    )

    def build_filters(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Состојба:", style="Muted.TLabel").pack(side="left", padx=(0, 4))
        self.state_var = tk.StringVar(value="Сите")
        combo = ttk.Combobox(parent, textvariable=self.state_var, state="readonly", width=12,
                             values=["Сите", "неплатена", "делумно", "платена"])
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self.refresh())

    def extra_buttons(self, toolbar: Toolbar) -> None:
        self.btn_pay = toolbar.button("Уплати", self.action_payments, width=12)

    def update_extra_buttons(self, row: dict | None) -> None:
        button = getattr(self, "btn_pay", None)
        if button is not None:
            button.state(["!disabled"] if row is not None else ["disabled"])

    def action_payments(self) -> None:
        row = self.table.selected_row()
        if row is None:
            return
        record = purchases.get(int(row["id"]))
        if record is None:
            return
        payments_window(self, record["doc_no"], payments.KIND_PURCHASE,
                        int(row["id"]), record["total_gross"])
        self.refresh()

    def fetch(self, search: str) -> list[dict]:
        rows = []
        paid_map = payments.paid_map(payments.KIND_PURCHASE)
        for rec in purchases.list_all(search):
            gross = q2(rec["total_gross"])
            done = paid_map.get(int(rec["id"]), D(0))
            state = payments.status(gross, done)
            wanted = getattr(self, "state_var", None)
            if wanted is not None and wanted.get() != "Сите" and state != wanted.get():
                continue
            rows.append({
                "id": rec["id"],
                "doc_no": rec["doc_no"],
                "date": fmt_date(rec["date"]), "date_raw": rec["date"],
                "supplier_doc": rec["supplier_doc"],
                "due_date": fmt_date(rec["due_date"]), "due_date_raw": rec["due_date"],
                "partner_name": rec["partner_name"] or "—",
                "lines_count": rec["lines_count"], "lines_count_raw": rec["lines_count"],
                "total_net": fmt(rec["total_net"]), "total_net_raw": rec["total_net"],
                "total_vat": fmt(rec["total_vat"]), "total_vat_raw": rec["total_vat"],
                "total_gross": fmt(gross), "total_gross_raw": float(gross),
                "paid": fmt(done) if done else "", "paid_raw": float(done),
                "pay_status": state,
                "receipt_no": links.source_label(links.VLEZNA, int(rec["id"])),
                "_tags": {"платена": ("ok_row",), "делумно": ("warn_row",)}
                .get(state, ("bad_row",)),
            })
        return rows

    def describe(self, row: dict) -> str:
        return f"{row['doc_no']} ({row['partner_name']})"

    def delete_record(self, rec_id: int) -> None:
        purchases.delete(rec_id)

    def open_form(self, rec_id: int | None) -> bool:
        return VleznaFakturaWindow(self, self.app, rec_id).show()
