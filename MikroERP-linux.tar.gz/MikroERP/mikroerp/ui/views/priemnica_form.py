# -*- coding: utf-8 -*-
"""Уредување на една приемница (влез на стока)."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ...repo import receipts
from ...util import fmt_date
from .doc_window import DocumentWindow


class PriemnicaWindow(DocumentWindow):
    doc_label = "Приемница"
    partner_label = "Добавувач"
    partner_as_supplier = True
    save_hint = "Со зачувување стоката влегува во магацин по FIFO."
    repo = receipts
    print_kind = "priemnica"

    def default_price(self, item_row):
        return item_row["purchase_price"]

    # Приемницата има уште: документ од добавувачот и дали да се запише
    # набавната цена во шифрарникот.
    def build_header_extra(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Документ од добавувач:").pack(side="left")
        self.supplier_doc_var = tk.StringVar(value=self.header_data["supplier_doc"])
        ttk.Entry(parent, textvariable=self.supplier_doc_var, width=18).pack(
            side="left", padx=(4, 16))

        ttk.Label(parent, text="Датум на документот:").pack(side="left")
        self.supplier_date_var = tk.StringVar(
            value=fmt_date(self.header_data["supplier_date"]))
        ttk.Entry(parent, textvariable=self.supplier_date_var, width=11).pack(
            side="left", padx=(4, 16))

        self.update_prices_var = tk.BooleanVar(value=self.header_data["update_prices"])
        ttk.Checkbutton(parent, text="Запиши ја набавната цена во шифрарникот",
                        variable=self.update_prices_var).pack(side="left")

    def pull_header_extra(self) -> None:
        self.header_data["supplier_doc"] = self.supplier_doc_var.get().strip()
        self.header_data["supplier_date"] = self._norm_date(self.supplier_date_var.get())
        self.header_data["update_prices"] = bool(self.update_prices_var.get())
