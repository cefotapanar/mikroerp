﻿# -*- coding: utf-8 -*-
"""Повеќекратно употребливи GUI елементи: табела, форма, копчиња, пораки.

Целата апликација ги користи овие, за да изгледа и се однесува исто насекаде.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk
from typing import Any, Callable, Iterable, Sequence

from ..util import matches
from . import theme


# ---------------------------------------------------------------- пораки
def error(parent, message: str, title: str = "Грешка") -> None:
    messagebox.showerror(title, message, parent=parent)


def info(parent, message: str, title: str = "Информација") -> None:
    messagebox.showinfo(title, message, parent=parent)


def confirm(parent, message: str, title: str = "Потврди") -> bool:
    return bool(messagebox.askyesno(title, message, parent=parent, icon="question"))


def balloon(parent, text: str, x: int, y: int, width: int = 420) -> None:
    """Мал балон со целосниот текст — за тесни колони во табела.

    Се затвора со клик било каде, со Esc или кога ќе се тргне глушецот.
    """
    if not str(text or "").strip():
        return
    window = tk.Toplevel(parent)
    window.overrideredirect(True)
    window.attributes("-topmost", True)
    frame = tk.Frame(window, background=theme.C["required_edge"], padx=1, pady=1)
    frame.pack(fill="both", expand=True)
    tk.Label(frame, text=text, background=theme.C["light"], foreground=theme.C["fg"],
             font=theme.FONTS["base"], wraplength=width, justify="left",
             padx=8, pady=6).pack(fill="both", expand=True)
    window.geometry(f"+{x + 12}+{y + 12}")

    def close(_event=None):
        try:
            window.destroy()
        except tk.TclError:
            pass

    window.bind("<Button-1>", close)
    window.bind("<Leave>", close)
    parent.bind("<Button-1>", close, add="+")
    parent.winfo_toplevel().bind("<Escape>", close, add="+")
    window.after(8000, close)


# ------------------------------------------------- работа што трае
def run_with_progress(parent, title: str, worker: Callable, message: str = ""):
    """Ја извршува `worker()` во посебна нишка, со мал прозорец „се работи…“.

    Прозорецот не замрзнува додека трае мрежен повик. Враќа што вратил
    `worker`, а ако тој фрлил грешка — истата се фрла понатаму.
    """
    import threading

    window = tk.Toplevel(parent)
    window.title(title)
    window.transient(parent.winfo_toplevel())
    window.resizable(False, False)
    frame = ttk.Frame(window, padding=(20, 16, 20, 16))
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text=message or title).pack(anchor="w")
    bar = ttk.Progressbar(frame, mode="indeterminate", length=280)
    bar.pack(fill="x", pady=(10, 0))
    bar.start(12)
    window.protocol("WM_DELETE_WINDOW", lambda: None)

    result: dict = {}

    def run():
        try:
            result["value"] = worker()
        except Exception as exc:  # noqa: BLE001 — се пренесува до повикувачот
            result["error"] = exc

    thread = threading.Thread(target=run, daemon=True)
    thread.start()

    def poll():
        if thread.is_alive():
            window.after(80, poll)
            return
        bar.stop()
        window.grab_release()
        window.destroy()

    window.update_idletasks()
    center_on(window, parent.winfo_toplevel())
    window.grab_set()
    window.after(80, poll)
    parent.wait_window(window)

    if "error" in result:
        raise result["error"]
    return result.get("value")


# ------------------------------------------------- задолжителни полиња
def require(widget, var: tk.Variable | None = None, getter: Callable | None = None) -> None:
    """Полето се бои најбледо црвено додека е празно.

    Работи за `ttk.Entry` и за `SearchPicker` (се бои неговото поле).
    """
    entry = widget.entry if isinstance(widget, SearchPicker) else widget
    if var is None:
        var = getattr(widget, "var", None)
    if getter is None and var is None:
        return

    def refresh(*_a) -> None:
        try:
            value = getter() if getter is not None else var.get()
        except Exception:  # noqa: BLE001 — недовршен внес не смее да пука
            value = ""
        try:
            entry.configure(style="TEntry" if str(value).strip() else theme.REQUIRED_STYLE)
        except tk.TclError:
            pass

    if var is not None:
        var.trace_add("write", refresh)
    entry.bind("<FocusOut>", refresh, add="+")
    refresh()


def center_on(window: tk.Misc, parent: tk.Misc) -> None:
    window.update_idletasks()
    width, height = window.winfo_width(), window.winfo_height()
    try:
        px, py = parent.winfo_rootx(), parent.winfo_rooty()
        pw, ph = parent.winfo_width(), parent.winfo_height()
    except tk.TclError:
        px = py = 0
        pw, ph = window.winfo_screenwidth(), window.winfo_screenheight()
    x = max(px + (pw - width) // 2, 0)
    y = max(py + (ph - height) // 3, 0)
    window.geometry(f"+{x}+{y}")


# ---------------------------------------------------------------- лента со копчиња
class Toolbar(ttk.Frame):
    """Ред обични системски копчиња, како во WSTG600."""

    def __init__(self, master, **kw):
        super().__init__(master, **kw)

    def button(self, text: str, command: Callable, width: int = 12) -> ttk.Button:
        btn = ttk.Button(self, text=text, width=width, command=command)
        btn.pack(side="left", padx=(0, 6))
        return btn

    def separator(self) -> None:
        ttk.Separator(self, orient="vertical").pack(side="left", fill="y", padx=6, pady=2)

    def label(self, text: str = "", style: str = "Muted.TLabel") -> ttk.Label:
        lbl = ttk.Label(self, text=text, style=style)
        lbl.pack(side="left", padx=(4, 8))
        return lbl


# ---------------------------------------------------------------- поле за пребарување
class SearchBox(ttk.Frame):
    """Поле за барање што повикува callback со мало доцнење (без трепкање)."""

    def __init__(self, master, on_change: Callable[[str], None], width: int = 30,
                 placeholder: str = "Барај:", delay_ms: int = 220):
        super().__init__(master)
        self.on_change = on_change
        self.delay_ms = delay_ms
        self._after_id: str | None = None
        self.var = tk.StringVar()
        ttk.Label(self, text=placeholder, style="Muted.TLabel").pack(side="left", padx=(0, 6))
        self.entry = ttk.Entry(self, textvariable=self.var, width=width)
        self.entry.pack(side="left")
        self._placeholder = placeholder
        self.var.trace_add("write", self._schedule)
        self.entry.bind("<Escape>", lambda _e: self.clear())
        ttk.Button(self, text="Исчисти", width=9, command=self.clear).pack(side="left", padx=(4, 0))

    def _schedule(self, *_a) -> None:
        if self._after_id:
            try:
                self.after_cancel(self._after_id)
            except tk.TclError:
                pass
        self._after_id = self.after(self.delay_ms, lambda: self.on_change(self.var.get()))

    def clear(self) -> None:
        self.var.set("")

    def get(self) -> str:
        return self.var.get()

    def focus(self) -> None:
        self.entry.focus_set()


# ---------------------------------------------------------------- избирач
class SearchPicker(ttk.Frame):
    """Поле за избор со пребарување додека пишуваш.

    Листата се стеснува со секоја буква, а барањето чита и кирилица и
    латиница („crna“ го наоѓа „Црна“ и обратно).

    `options` е листа од (вредност, натпис) или (вредност, натпис, додатен
    текст за пребарување).
    """

    def __init__(self, master, options: Sequence = (), width: int = 34,
                 on_select: Callable | None = None, allow_empty: bool = True,
                 placeholder: str = ""):
        super().__init__(master)
        self.on_select = on_select
        self.allow_empty = allow_empty
        self.placeholder = placeholder
        self._entries: list[tuple] = []
        self._value = None
        self._popup: tk.Toplevel | None = None
        self._list: tk.Listbox | None = None
        self._shown: list[tuple] = []
        self._guard = False
        self._picking = False           # тековно се клика врз листата
        self._close_job: str | None = None

        self.var = tk.StringVar()
        self.entry = ttk.Entry(self, textvariable=self.var, width=width)
        self.entry.pack(side="left", fill="x", expand=True)

        self.var.trace_add("write", self._on_type)
        self.entry.bind("<Down>", self._on_down)
        self.entry.bind("<Up>", self._on_up)
        self.entry.bind("<Return>", self._on_return)
        self.entry.bind("<Escape>", self._on_escape)
        self.entry.bind("<FocusOut>", self._on_focus_out)
        self.entry.bind("<Button-1>", lambda _e: self._open(select_all=True))
        self.bind("<Destroy>", lambda _e: self._close())

        # Паѓачката листа е посебен прозорец — мора да го следи главниот
        # кога тој се движи или менува големина.
        self.winfo_toplevel().bind("<Configure>", self._follow_window, add="+")

        self.set_options(options)

    # ------------------------------------------------------------- податоци
    def set_options(self, options: Sequence) -> None:
        normalized = []
        for entry in options:
            if len(entry) >= 3:
                normalized.append((entry[0], str(entry[1]), str(entry[2])))
            else:
                normalized.append((entry[0], str(entry[1]), ""))
        self._entries = normalized
        if self._value is not None and not self._label_of(self._value):
            self.clear()

    def _label_of(self, value) -> str:
        for val, label, _extra in self._entries:
            if str(val) == str(value):
                return label
        return ""

    def get(self):
        return self._value

    def get_text(self) -> str:
        return self.var.get()

    def set(self, value, fire: bool = False) -> None:
        label = self._label_of(value) if value not in (None, "") else ""
        self._value = value if label else None
        self._guard = True
        self.var.set(label)
        self._guard = False
        if fire and self.on_select:
            self.on_select(self._value)

    def clear(self) -> None:
        self.set(None)

    def focus(self) -> None:
        self.entry.focus_set()
        self.entry.select_range(0, "end")

    def state(self, spec=None):
        return self.entry.state(spec)

    # ------------------------------------------------------------- паѓачка
    def _filtered(self, query: str) -> list[tuple]:
        return [o for o in self._entries if matches(query, o[1], o[2])][:300]

    def _open(self, select_all: bool = False, query: str | None = None) -> None:
        if str(self.entry.cget("state")) == "disabled":
            return
        text = self.var.get() if query is None else query
        self._shown = self._entries[:300] if select_all else self._filtered(text)
        if not self._shown:
            self._close()
            return
        if self._popup is None:
            self._popup = tk.Toplevel(self)
            self._popup.overrideredirect(True)
            self._popup.attributes("-topmost", True)
            frame = ttk.Frame(self._popup, relief="solid", borderwidth=1)
            frame.pack(fill="both", expand=True)
            self._list = tk.Listbox(frame, activestyle="dotbox", exportselection=False,
                                    font=theme.FONTS["base"], highlightthickness=0,
                                    borderwidth=0)
            scroll = ttk.Scrollbar(frame, orient="vertical", command=self._list.yview)
            self._list.configure(yscrollcommand=scroll.set)
            self._list.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")
            # Кликот со глушец: притисокот го означува редот и го запира
            # затворањето (полето губи фокус штом се клика во листата),
            # а пуштањето го зема изборот.
            self._list.bind("<Button-1>", self._on_list_press)
            self._list.bind("<ButtonRelease-1>", lambda _e: self._take_current())
            self._list.bind("<Return>", lambda _e: self._take_current())
            self._list.bind("<Escape>", self._on_escape)

        self._list.delete(0, "end")
        for _value, label, _extra in self._shown:
            self._list.insert("end", label)
        self._list.selection_clear(0, "end")
        self._list.selection_set(0)
        self._list.see(0)
        self._list.configure(height=min(len(self._shown), 10))
        self._place_popup()
        self._popup.deiconify()

    def _place_popup(self) -> None:
        """Ја лепи листата под полето — и кога прозорецот се движи."""
        if self._popup is None or not self.entry.winfo_ismapped():
            return
        rows = min(len(self._shown), 10)
        height = rows * (theme.FONTS["base"].metrics("linespace") + 4) + 6
        self.update_idletasks()
        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        width = max(self.entry.winfo_width(), 260)
        self._popup.geometry(f"{width}x{height}+{x}+{y}")

    def _follow_window(self, _event=None) -> None:
        if self._popup is None:
            return
        try:
            self._place_popup()
        except tk.TclError:
            self._close()

    def _close(self) -> None:
        self._cancel_close_job()
        if self._popup is not None:
            try:
                self._popup.destroy()
            except tk.TclError:
                pass
            self._popup = None
            self._list = None
        self._shown = []

    def _on_list_press(self, event) -> None:
        self._picking = True
        self._cancel_close_job()
        if self._list is not None:
            index = self._list.nearest(event.y)
            self._list.selection_clear(0, "end")
            self._list.selection_set(index)

    def _take_current(self) -> None:
        if not self._list or not self._shown:
            self._picking = False
            return
        selection = self._list.curselection()
        index = selection[0] if selection else 0
        value = self._shown[index][0]
        self._close()
        self._picking = False
        self.set(value, fire=True)
        self.entry.focus_set()
        self.entry.icursor("end")

    # --------------------------------------------------------------- настани
    def _on_type(self, *_a) -> None:
        if self._guard:
            return
        self._value = None
        self._open()

    def _on_down(self, _event=None):
        if self._popup is None:
            self._open(select_all=not self.var.get().strip())
            return "break"
        current = self._list.curselection()
        index = (current[0] + 1) if current else 0
        if index < self._list.size():
            self._list.selection_clear(0, "end")
            self._list.selection_set(index)
            self._list.see(index)
        return "break"

    def _on_up(self, _event=None):
        if self._popup is None or not self._list:
            return None
        current = self._list.curselection()
        index = (current[0] - 1) if current else 0
        if index >= 0:
            self._list.selection_clear(0, "end")
            self._list.selection_set(index)
            self._list.see(index)
        return "break"

    def _on_return(self, _event=None):
        if self._popup is not None:
            self._take_current()
            return "break"
        return None

    def _on_escape(self, _event=None):
        if self._popup is not None:
            self._close()
            return "break"
        return None

    def _cancel_close_job(self) -> None:
        if self._close_job:
            try:
                self.after_cancel(self._close_job)
            except tk.TclError:
                pass
            self._close_job = None

    def _on_focus_out(self, _event=None) -> None:
        # Кликот врз листата исто така вади фокус од полето, па затворањето
        # се одложува за кликот да стигне до листата.
        self._cancel_close_job()
        self._close_job = self.after(200, self._finish_focus_out)

    def _finish_focus_out(self) -> None:
        self._close_job = None
        if self._picking:
            return
        # Ако корисникот пишувал но не избрал, земи го првиот погоден резултат;
        # ако нема таков — врати го претходниот натпис.
        text = self.var.get().strip()
        candidates = self._filtered(text) if text else []
        self._close()
        if self._value is None:
            if candidates and text:
                self.set(candidates[0][0], fire=True)
            elif self.allow_empty:
                self.set(None)


# ---------------------------------------------------------------- табела
class DataTable(ttk.Frame):
    """Treeview со сортирање по колона, наизменични редови и id по ред.

    columns: листа од речници:
        key      — клуч во речникот на редот
        text     — заглавие
        width    — почетна ширина во пиксели
        anchor   — 'w' | 'e' | 'center'
        sort     — 'text' | 'num'  (по што се сортира)
        stretch  — дали да се растегнува
    Редовите се речници; вредноста за приказ се чита од `key`, а ако постои
    `key + '_raw'` таа се користи за сортирање.
    """

    def __init__(self, master, columns: Sequence[dict], on_activate: Callable | None = None,
                 on_select: Callable | None = None, height: int = 18,
                 selectmode: str = "browse"):
        super().__init__(master)
        self.columns = list(columns)
        self.on_activate = on_activate
        self.on_select = on_select
        self._rows: list[dict] = []
        self._sort_key: str | None = None
        self._sort_desc = False

        keys = [c["key"] for c in self.columns]
        self.tree = ttk.Treeview(self, columns=keys, show="headings", height=height,
                                 selectmode=selectmode)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self.hsb = hsb
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)
        # Хоризонталната лента се крие кога сите колони се гледаат.
        self.tree.bind("<Configure>", self._sync_hsb)

        for col in self.columns:
            key = col["key"]
            self.tree.heading(key, text=col.get("text", key),
                              command=lambda k=key: self.sort_by(k))
            self.tree.column(
                key,
                width=int(col.get("width", 120)),
                minwidth=int(col.get("minwidth", 40)),
                anchor=col.get("anchor", "w"),
                stretch=bool(col.get("stretch", False)),
            )

        self.tree.tag_configure("odd", background=theme.C["row_alt"])
        self.tree.tag_configure("neaktiven", foreground=theme.C["muted"])
        self.tree.tag_configure("vnimanie", foreground=theme.C["danger"])
        self.tree.tag_configure("marked", background=theme.C["light"])
        self.tree.tag_configure("done", foreground=theme.C["ok"])
        # состојба: бледа позадина, доволна да се препознае без да дречи
        self.tree.tag_configure("ok_row", background=theme.C["pale_ok"])
        self.tree.tag_configure("warn_row", background=theme.C["pale_warn"])
        self.tree.tag_configure("bad_row", background=theme.C["pale_bad"])

        self.tree.bind("<Double-1>", self._activate)
        self.tree.bind("<Return>", self._activate)
        self.tree.bind("<<TreeviewSelect>>", self._select)

    def _sync_hsb(self, _event=None) -> None:
        try:
            total = sum(int(self.tree.column(c["key"], "width")) for c in self.columns)
            if total <= self.tree.winfo_width():
                self.hsb.grid_remove()
            else:
                self.hsb.grid()
        except tk.TclError:
            pass

    # ------------------------------------------------------------- полнење
    def set_rows(self, rows: Iterable[dict]) -> None:
        selected = self.selected_id()
        self._rows = [dict(r) for r in rows]
        self._render()
        if selected is not None:
            self.select_id(selected)

    def _render(self) -> None:
        rows = self._rows
        if self._sort_key:
            column = next((c for c in self.columns if c["key"] == self._sort_key), None)
            kind = (column or {}).get("sort", "text")

            def sort_value(row: dict):
                raw = row.get(f"{self._sort_key}_raw", row.get(self._sort_key))
                if kind == "num":
                    try:
                        return float(str(raw).replace(".", "").replace(",", ".") or 0)
                    except (TypeError, ValueError):
                        return 0.0
                return str(raw or "").casefold()

            rows = sorted(rows, key=sort_value, reverse=self._sort_desc)

        self.tree.delete(*self.tree.get_children())
        for index, row in enumerate(rows):
            tags = ["odd"] if index % 2 else []
            tags += list(row.get("_tags", ()))
            self.tree.insert(
                "", "end",
                iid=str(row.get("id", index)),
                values=[row.get(c["key"], "") for c in self.columns],
                tags=tuple(tags),
            )

    def sort_by(self, key: str) -> None:
        if self._sort_key == key:
            self._sort_desc = not self._sort_desc
        else:
            self._sort_key, self._sort_desc = key, False
        for col in self.columns:
            arrow = ""
            if col["key"] == self._sort_key:
                arrow = "  ▼" if self._sort_desc else "  ▲"
            self.tree.heading(col["key"], text=col.get("text", col["key"]) + arrow)
        self._render()

    # ------------------------------------------------------------- избор
    def selected_id(self) -> int | None:
        selection = self.tree.selection()
        if not selection:
            return None
        try:
            return int(selection[0])
        except ValueError:
            return None

    def selected_row(self) -> dict | None:
        rec_id = self.selected_id()
        if rec_id is None:
            return None
        return next((r for r in self._rows if int(r.get("id", -1)) == rec_id), None)

    def select_id(self, rec_id: int) -> None:
        iid = str(rec_id)
        if self.tree.exists(iid):
            self.tree.selection_set(iid)
            self.tree.focus(iid)
            self.tree.see(iid)

    def select_first(self) -> None:
        children = self.tree.get_children()
        if children:
            self.tree.selection_set(children[0])
            self.tree.focus(children[0])

    def selected_ids(self) -> list[int]:
        out = []
        for iid in self.tree.selection():
            try:
                out.append(int(iid))
            except ValueError:
                continue
        return out

    def select_ids(self, ids) -> None:
        wanted = [str(i) for i in ids if self.tree.exists(str(i))]
        self.tree.selection_set(wanted)

    def count(self) -> int:
        return len(self._rows)

    def _activate(self, _event=None) -> None:
        if self.on_activate and self.selected_id() is not None:
            self.on_activate(self.selected_id())

    def _select(self, _event=None) -> None:
        if self.on_select:
            self.on_select(self.selected_id())


# ---------------------------------------------------------------- форма
class Field:
    """Опис на едно поле во форма.

    col — ширина во колони од мрежа со 12 колони (како во веб).  Пример:
          три кратки полиња во ред = col=4 за секое.
    """

    def __init__(self, key: str, label: str, kind: str = "text", col: int = 12,
                 required: bool = False, values: Sequence | None = None,
                 default: Any = None, readonly: bool = False, help: str = "",
                 height: int = 4, uppercase: bool = False,
                 on_change: Callable | None = None, chars: int | None = None,
                 side_button: tuple | None = None):
        self.key = key
        self.label = label
        self.kind = kind          # text|memo|int|dec|money|check|combo|combo_edit|heading|sep
        self.col = max(1, min(12, int(col)))
        self.required = required
        self.values = list(values or [])
        self.default = default
        self.readonly = readonly
        self.help = help
        self.height = height
        self.uppercase = uppercase
        # on_change(panel, value) — се повикува кога полето ќе смени вредност
        # (за combo: при избор). Служи за автоматско полнење на други полиња.
        self.on_change = on_change
        # chars — ширина во знаци. Ако е зададена, полето НЕ се растегнува до
        # крајот на редот, туку останува по мерка на податокот.
        self.chars = chars
        # side_button — („натпис“, функција(panel)) копче веднаш до полето,
        # пр. „Нов клиент“. Ако функцијата врати вредност, таа се избира.
        self.side_button = side_button


class FormPanel(ttk.Frame):
    """Полиња распоредени во мрежа од 12 колони.

    Се користи и во дијалог (`FormDialog`) и вградено во екран (пр. Фирма).
    """

    def __init__(self, master, fields: Sequence[Field], values: dict | None = None,
                 padding=(12, 10, 12, 6)):
        super().__init__(master, padding=padding)
        self.fields = list(fields)
        self.vars: dict[str, tk.Variable] = {}
        self.widgets: dict[str, tk.Widget] = {}
        self._combo_maps: dict[str, dict[str, Any]] = {}
        for index in range(12):
            self.grid_columnconfigure(index, weight=1, uniform="grid12", minsize=24)
        self._build(self, values or {})

    # ------------------------------------------------------------- градење
    def _build(self, body: ttk.Frame, values: dict) -> None:
        row = 0
        used = 0
        for field in self.fields:
            if field.kind in ("heading", "sep"):
                if used:
                    row += 1
                    used = 0
                if field.kind == "sep":
                    ttk.Separator(body).grid(row=row, column=0, columnspan=12,
                                             sticky="ew", pady=(8, 6))
                else:
                    ttk.Label(body, text=field.label, style="Head.TLabel").grid(
                        row=row, column=0, columnspan=12, sticky="w", pady=(10, 2)
                    )
                row += 1
                continue

            if used + field.col > 12:
                row += 1
                used = 0

            cell = ttk.Frame(body)
            cell.grid(row=row, column=used, columnspan=field.col,
                      sticky="ew", padx=(0, 10), pady=(0, 8))
            # Полето со зададена ширина не се растегнува до крајот на редот.
            cell.grid_columnconfigure(0, weight=0 if field.chars else 1)

            value = values.get(field.key, field.default)
            self._build_field(cell, field, value)
            used += field.col
        body.grid_rowconfigure(row, weight=1)

    def _build_field(self, cell: ttk.Frame, field: Field, value) -> None:
        label_text = field.label + (" *" if field.required else "")

        if field.kind == "check":
            var = tk.BooleanVar(value=bool(int(value)) if str(value).strip() in ("0", "1") else bool(value))
            widget = ttk.Checkbutton(cell, text=field.label, variable=var)
            widget.grid(row=0, column=0, sticky="w", pady=(18, 0))
            self.vars[field.key] = var
            self.widgets[field.key] = widget
            return

        ttk.Label(cell, text=label_text).grid(row=0, column=0, sticky="w")

        if field.kind == "memo":
            widget = tk.Text(cell, height=field.height, wrap="word", relief="sunken",
                             borderwidth=1, font=theme.FONTS["base"])
            widget.grid(row=1, column=0, sticky="ew")
            if value:
                widget.insert("1.0", str(value))
            if field.readonly:
                widget.configure(state="disabled")
            self.widgets[field.key] = widget
            return

        var = tk.StringVar(value="" if value is None else str(value))
        self.vars[field.key] = var
        if field.kind in ("int", "dec", "money"):
            self._normalize_number(field, var)

        if field.kind == "picker":
            widget = SearchPicker(cell, field.values or (), width=field.chars or 34,
                                  on_select=lambda _v, f=field: self._fire_change(f))
            widget.set(value)
            self.widgets[field.key] = widget
            widget.grid(row=1, column=0, sticky="w" if field.chars else "ew")
            if field.required:
                require(widget)
            self._add_side_button(cell, field)
            if field.help:
                ttk.Label(cell, text=field.help, style="Small.TLabel").grid(
                    row=2, column=0, sticky="w")
            if field.readonly:
                widget.state(["disabled"])
            return

        if field.kind in ("combo", "combo_edit"):
            pairs = self._normalize_options(field.values)
            self._combo_maps[field.key] = {label: val for val, label in pairs}
            widget = ttk.Combobox(
                cell, values=[label for _v, label in pairs],
                state="readonly" if field.kind == "combo" else "normal",
            )
            if field.chars:
                widget.configure(width=field.chars)
            current = next((label for val, label in pairs if str(val) == str(value or "")), None)
            if current is not None:
                widget.set(current)
            elif field.kind == "combo_edit":
                widget.set("" if value is None else str(value))
            elif pairs:
                widget.set(pairs[0][1])
        else:
            widget = ttk.Entry(cell, textvariable=var)
            if field.chars:
                widget.configure(width=field.chars)
            if field.kind in ("int", "dec", "money"):
                widget.configure(justify="right")
                # По напуштање на полето бројот се препишува во нормализиран
                # облик, за корисникот ВЕДНАШ да види како е разбран внесот
                # (пр. „1.180“ → „1,18“ — тогаш е јасно дека треба „1180“).
                widget.bind("<FocusOut>", lambda _e, f=field, v=var: self._normalize_number(f, v))
            if field.uppercase:
                var.trace_add("write", lambda *_a, v=var: v.set(v.get().upper()))

        widget.grid(row=1, column=0, sticky="w" if field.chars else "ew")
        self._add_side_button(cell, field)
        if field.on_change is not None:
            if field.kind in ("combo", "combo_edit"):
                widget.bind("<<ComboboxSelected>>",
                            lambda _e, f=field: self._fire_change(f), add="+")
            else:
                widget.bind("<FocusOut>", lambda _e, f=field: self._fire_change(f), add="+")
        if field.required and isinstance(widget, ttk.Entry) and not isinstance(widget, ttk.Combobox):
            require(widget, var)
        if field.readonly:
            widget.configure(state="disabled")
        if field.help:
            ttk.Label(cell, text=field.help, style="Small.TLabel").grid(row=2, column=0, sticky="w")
        self.widgets[field.key] = widget

    def _add_side_button(self, cell: ttk.Frame, field: Field) -> None:
        """Копче веднаш до полето, пр. „Нов клиент“ покрај изборот на клиент."""
        if not field.side_button:
            return
        text, command = field.side_button[0], field.side_button[1]

        def run():
            created = command(self)
            if created is not None:
                self.set_values({field.key: created})
                self._fire_change(field)

        ttk.Button(cell, text=text, width=max(len(text) + 2, 10), command=run).grid(
            row=1, column=1, sticky="w", padx=(6, 0))

    def _fire_change(self, field: "Field") -> None:
        if field.on_change is None:
            return
        field.on_change(self, self.get_values().get(field.key))

    def set_value(self, key: str, value) -> None:
        """Полнење на едно поле однадвор (пр. од `on_change`)."""
        self.set_values({key: value})

    @staticmethod
    def _normalize_number(field: "Field", var: tk.Variable) -> None:
        from ..money import D, fmt, fmt_qty

        text = str(var.get()).strip()
        if not text:
            return
        try:
            value = D(text)
        except ValueError:
            return                      # невалиден внес — валидацијата ќе го фати
        if field.kind == "money":
            var.set(fmt(value, 2))
        elif field.kind == "int":
            var.set(str(int(value)))
        else:
            var.set(fmt_qty(value))

    @staticmethod
    def _normalize_options(values: Sequence) -> list[tuple[Any, str]]:
        pairs: list[tuple[Any, str]] = []
        for entry in values:
            if isinstance(entry, (tuple, list)) and len(entry) == 2:
                pairs.append((entry[0], str(entry[1])))
            else:
                pairs.append((entry, str(entry)))
        return pairs

    def focus_first(self) -> None:
        for field in self.fields:
            if field.kind in ("heading", "sep") or field.readonly:
                continue
            widget = self.widgets.get(field.key)
            if widget is not None:
                if isinstance(widget, SearchPicker):
                    widget.focus()
                else:
                    widget.focus_set()
                    if isinstance(widget, ttk.Entry):
                        widget.select_range(0, "end")
                return

    # ------------------------------------------------------------- вредности
    def get_values(self) -> dict:
        data: dict = {}
        for field in self.fields:
            if field.kind in ("heading", "sep"):
                continue
            widget = self.widgets.get(field.key)
            if field.kind == "picker":
                data[field.key] = widget.get() if widget else None
            elif field.kind == "memo":
                data[field.key] = widget.get("1.0", "end-1c").strip() if widget else ""
            elif field.kind == "check":
                data[field.key] = bool(self.vars[field.key].get())
            elif field.kind in ("combo", "combo_edit"):
                shown = widget.get() if widget else ""
                mapping = self._combo_maps.get(field.key, {})
                data[field.key] = mapping.get(shown, shown)
            else:
                data[field.key] = self.vars[field.key].get().strip()
        return data

    def set_values(self, values: dict) -> None:
        """Повторно полнење на формата (пр. по „Откажи ги промените“)."""
        for field in self.fields:
            if field.kind in ("heading", "sep") or field.key not in values:
                continue
            value = values[field.key]
            widget = self.widgets.get(field.key)
            if field.kind == "picker" and widget is not None:
                widget.set(value)
            elif field.kind == "memo" and widget is not None:
                widget.delete("1.0", "end")
                widget.insert("1.0", "" if value is None else str(value))
            elif field.kind == "check":
                text = str(value).strip().lower()
                self.vars[field.key].set(text in ("1", "true", "да", "yes") or value is True)
            elif field.kind in ("combo", "combo_edit") and widget is not None:
                mapping = self._combo_maps.get(field.key, {})
                label = next((lbl for lbl, val in mapping.items() if str(val) == str(value)), None)
                widget.set(label if label is not None else ("" if value is None else str(value)))
            elif field.key in self.vars:
                self.vars[field.key].set("" if value is None else str(value))
                if field.kind in ("int", "dec", "money"):
                    self._normalize_number(field, self.vars[field.key])

    def missing_required(self, data: dict) -> Field | None:
        for field in self.fields:
            if field.required and not str(data.get(field.key, "")).strip():
                return field
        return None


class FormDialog(tk.Toplevel):
    """Модален дијалог околу `FormPanel`."""

    def __init__(self, master, title: str, fields: Sequence[Field],
                 values: dict | None = None,
                 on_save: Callable[[dict], Any] | None = None,
                 width: int = 720, save_text: str = "Зачувај"):
        super().__init__(master)
        self.title(title)
        self.on_save = on_save
        self.result: Any = None
        self.saved = False

        self.transient(master.winfo_toplevel())
        self.resizable(True, False)

        self.panel = FormPanel(self, fields, values)
        self.panel.pack(fill="both", expand=True)

        self.error_label = ttk.Label(self, text="", style="Error.TLabel", wraplength=width - 40)
        self.error_label.pack(fill="x", padx=12)

        ttk.Separator(self).pack(fill="x", pady=(8, 0))
        footer = ttk.Frame(self, padding=(12, 8, 12, 10))
        footer.pack(fill="x")
        ttk.Button(footer, text="Откажи", width=12, command=self.cancel).pack(side="right")
        ttk.Button(footer, text=save_text, width=12,
                   command=self.save).pack(side="right", padx=(0, 6))

        self.bind("<Escape>", lambda _e: self.cancel())
        self.bind("<Control-Return>", lambda _e: self.save())
        self.protocol("WM_DELETE_WINDOW", self.cancel)

        self.update_idletasks()
        self.geometry(f"{width}x{self.winfo_reqheight()}")
        center_on(self, master.winfo_toplevel())
        self.grab_set()
        self.panel.focus_first()

    def get_values(self) -> dict:
        return self.panel.get_values()

    def set_error(self, message: str) -> None:
        self.error_label.configure(text=message)

    def save(self) -> None:
        self.set_error("")
        data = self.panel.get_values()
        missing = self.panel.missing_required(data)
        if missing is not None:
            self.set_error(f"Полето „{missing.label}“ е задолжително.")
            widget = self.panel.widgets.get(missing.key)
            if widget:
                widget.focus_set()
            return
        if self.on_save is None:
            self.result = data
            self.saved = True
            self.destroy()
            return
        try:
            self.result = self.on_save(data)
        except ValueError as exc:            # ValidationError наследува ValueError
            self.set_error(str(exc))
            return
        except Exception as exc:  # noqa: BLE001 — дијалогот не смее да падне „на слепо“
            self.set_error(f"Грешка при зачувување: {exc}")
            return
        self.saved = True
        self.destroy()

    def cancel(self) -> None:
        self.saved = False
        self.destroy()

    def show(self):
        """Блокира додека дијалогот не се затвори; враќа резултат или None."""
        self.wait_window(self)
        return self.result if self.saved else None
