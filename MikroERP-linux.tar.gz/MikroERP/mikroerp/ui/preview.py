# -*- coding: utf-8 -*-
"""Преглед пред печатење — сопствен прозорец, без прелистувач.

Страниците се цртаат на платно точно онака како што ќе излезат на печатачот
(истите примитиви во милиметри). Оттука:

  * **Печати** оди директно на печатач (Windows дијалог за избор);
  * **PDF** го снима истиот документ како PDF.
"""

from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import font as tkfont
from tkinter import ttk

from .. import doclayout, paper, winprint
from . import widgets

ZOOMS = [("Цела страна", 0), ("75 %", 0.75), ("100 %", 1.0), ("150 %", 1.5)]
BASE_DPI = 96.0                      # 100 % = екрански пиксели на инч


class PreviewWindow(tk.Toplevel):
    def __init__(self, master, app, doc, pdf_html: str | None = None):
        super().__init__(master)
        self.app = app
        self.doc = doc
        self.pdf_html = pdf_html
        self.pages = doclayout.paginate(doc)
        self.page_index = 0
        self._images: list = []
        self._fonts: dict = {}

        self.title("Преглед — " + (f"{doc.title} {doc.doc_no}".strip() or doc.title))
        self.transient(master.winfo_toplevel())
        self.geometry("1000x820")
        self.minsize(700, 520)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        self._build_bar()
        self._build_canvas()

        self.bind("<Escape>", lambda _e: self.destroy())
        self.bind("<Control-p>", lambda _e: self.do_print())
        self.bind("<Prior>", lambda _e: self.step(-1))
        self.bind("<Next>", lambda _e: self.step(1))
        widgets.center_on(self, master.winfo_toplevel())
        self.after(60, self.redraw)

    # ------------------------------------------------------------------ лента
    def _build_bar(self) -> None:
        bar = ttk.Frame(self, padding=(8, 8, 8, 4))
        bar.grid(row=0, column=0, sticky="ew")

        ttk.Button(bar, text="Печати", width=12, command=self.do_print).pack(side="left")
        ttk.Button(bar, text="PDF", width=10, command=self.do_pdf).pack(side="left",
                                                                        padx=(6, 0))
        ttk.Button(bar, text="Затвори", width=10,
                   command=self.destroy).pack(side="right")

        ttk.Label(bar, text="Приказ:", style="Muted.TLabel").pack(side="left",
                                                                  padx=(18, 4))
        self.zoom_var = tk.StringVar(value=ZOOMS[0][0])
        combo = ttk.Combobox(bar, textvariable=self.zoom_var, state="readonly",
                             width=14, values=[name for name, _z in ZOOMS])
        combo.pack(side="left")
        combo.bind("<<ComboboxSelected>>", lambda _e: self.redraw())

        if len(self.pages) > 1:
            nav = ttk.Frame(bar)
            nav.pack(side="left", padx=(18, 0))
            ttk.Button(nav, text="◀", width=3,
                       command=lambda: self.step(-1)).pack(side="left")
            self.page_label = ttk.Label(nav, text="", width=12, anchor="center")
            self.page_label.pack(side="left", padx=4)
            ttk.Button(nav, text="▶", width=3,
                       command=lambda: self.step(1)).pack(side="left")
        else:
            self.page_label = None

    def _build_canvas(self) -> None:
        holder = ttk.Frame(self, padding=(8, 0, 8, 8))
        holder.grid(row=1, column=0, sticky="nsew")
        holder.columnconfigure(0, weight=1)
        holder.rowconfigure(0, weight=1)

        self.canvas = tk.Canvas(holder, background="#787878", highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        vsb = ttk.Scrollbar(holder, orient="vertical", command=self.canvas.yview)
        vsb.grid(row=0, column=1, sticky="ns")
        hsb = ttk.Scrollbar(holder, orient="horizontal", command=self.canvas.xview)
        hsb.grid(row=1, column=0, sticky="ew")
        self.canvas.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.canvas.bind("<Configure>", lambda _e: self.redraw())
        self.canvas.bind("<MouseWheel>",
                         lambda e: self.canvas.yview_scroll(-e.delta // 120, "units"))

    def step(self, delta: int) -> None:
        self.page_index = max(0, min(len(self.pages) - 1, self.page_index + delta))
        self.redraw()

    # ------------------------------------------------------------- цртање
    def _scale(self) -> float:
        """Пиксели на милиметар."""
        chosen = dict(ZOOMS).get(self.zoom_var.get(), 0)
        if chosen:
            return chosen * BASE_DPI / 25.4
        height = max(self.canvas.winfo_height() - 24, 200)
        width = max(self.canvas.winfo_width() - 24, 200)
        return min(height / doclayout.PAGE_H, width / doclayout.PAGE_W)

    def _font(self, style: str, scale: float):
        key = (style, round(scale, 2))
        if key not in self._fonts:
            size, bold, _color = doclayout.STYLES[style]
            self._fonts[key] = tkfont.Font(
                size=-max(1, round(size * doclayout.PT_MM * scale)),
                weight="bold" if bold else "normal")
        return self._fonts[key]

    def redraw(self) -> None:
        if not self.winfo_exists():
            return
        canvas = self.canvas
        canvas.delete("all")
        self._images = []
        scale = self._scale()
        page_w = doclayout.PAGE_W * scale
        page_h = doclayout.PAGE_H * scale
        pad = 12
        origin_x = max(pad, (canvas.winfo_width() - page_w) / 2)

        canvas.create_rectangle(origin_x + 3, pad + 3, origin_x + page_w + 3,
                                pad + page_h + 3, fill="#5a5a5a", outline="")
        canvas.create_rectangle(origin_x, pad, origin_x + page_w, pad + page_h,
                                fill="white", outline="#404040")

        def px(mm_x, mm_y):
            return origin_x + mm_x * scale, pad + mm_y * scale

        for item in self.pages[self.page_index]:
            kind = item[0]
            if kind == "text":
                _, x, y, text, style, width, align = item
                _size, _bold, color = doclayout.STYLES[style]
                font = self._font(style, scale)
                anchor, cx = "nw", x
                if width and align == "r":
                    anchor, cx = "ne", x + width
                elif width and align == "c":
                    anchor, cx = "n", x + width / 2
                sx, sy = px(cx, y)
                canvas.create_text(sx, sy, text=str(text), anchor=anchor,
                                   font=font, fill=color)
            elif kind == "line":
                _, x1, y1, x2, y2, width, color = item
                a = px(x1, y1)
                b = px(x2, y2)
                canvas.create_line(*a, *b, fill=color,
                                   width=max(1, round(width * scale)))
            elif kind == "rect":
                _, x, y, w, h, fill, outline, width = item
                a = px(x, y)
                b = px(x + w, y + h)
                canvas.create_rectangle(*a, *b, fill=fill or "",
                                        outline=outline or "",
                                        width=max(1, round(width * scale)))
            elif kind == "image":
                _, x, y, w, h, path = item
                self._draw_image(px(x, y), w * scale, h * scale, path)

        canvas.configure(scrollregion=(0, 0, max(origin_x + page_w + pad,
                                                 canvas.winfo_width()),
                                       page_h + 2 * pad))
        if self.page_label is not None:
            self.page_label.configure(
                text=f"{self.page_index + 1} / {len(self.pages)}")

    def _draw_image(self, position, width, height, path) -> None:
        try:
            image = tk.PhotoImage(file=str(path))
        except tk.TclError:
            return
        factor = max(1, round(image.width() / max(width, 1)),
                     round(image.height() / max(height, 1)))
        if factor > 1:
            image = image.subsample(factor, factor)
        self._images.append(image)
        self.canvas.create_image(position[0], position[1], image=image, anchor="nw")

    # ------------------------------------------------------------- дејства
    def do_print(self) -> None:
        try:
            printed = winprint.print_pages(
                self.pages, f"{self.doc.title} {self.doc.doc_no}".strip(),
                hwnd=self.winfo_id())
        except winprint.PrintError as exc:
            if widgets.confirm(self, f"{exc}\n\nДа се сними како PDF наместо тоа?",
                               title="Печатење"):
                self.do_pdf()
            return
        except Exception as exc:  # noqa: BLE001
            widgets.error(self, f"Печатењето не успеа:\n{exc}")
            return
        if printed:
            self.app.set_status("Испратено на печатач: "
                                f"{self.doc.title} {self.doc.doc_no}".strip())

    def do_pdf(self) -> None:
        from .exporting import ask_path, open_file

        html = self.pdf_html or paper.document_html(self.doc)
        target = ask_path(self, self.doc.file_name, ".pdf", "Зачувај PDF")
        if target is None:
            return
        try:
            paper.save_pdf(html, Path(target), self.doc.file_name)
        except paper.PdfError as exc:
            widgets.error(self, str(exc), title="PDF")
            return
        open_file(Path(target))
        self.app.set_status("Зачуван PDF: " + Path(target).name)


def show(master, app, doc, pdf_html: str | None = None) -> PreviewWindow:
    return PreviewWindow(master, app, doc, pdf_html)
