# -*- coding: utf-8 -*-
"""PDF и HTML на документите — без ниту една надворешна библиотека.

**Печатењето не поминува оттука** — тоа оди преку сопствениот преглед
(`ui/preview.py`) право на печатач. Овде документот станува **HTML со CSS за
A4**, што служи само за да се направи **PDF** преку прелистувачот што го има
Windows (Edge/Chrome, режим „headless“, без прозорец).

Зошто вака: апликацијата останува преносна (нема reportlab, нема Office), а
изгледот на PDF-от се менува со обичен CSS.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import webbrowser
from html import escape
from pathlib import Path

from .paths import app_dir
from .repo import settings

A4_CSS = """
@page { size: A4; margin: 12mm 12mm 14mm 12mm; }
* { box-sizing: border-box; }
body { font-family: "Segoe UI", Tahoma, Arial, sans-serif; font-size: 10.5pt;
       color: #111; margin: 0; }
h1, h2, h3 { margin: 0; }
.doc { max-width: 186mm; margin: 0 auto; }
.head { display: flex; justify-content: space-between; align-items: flex-start;
        border-bottom: 2px solid #333; padding-bottom: 8px; margin-bottom: 12px; }
.head .logo img { max-height: 22mm; max-width: 60mm; }
.firma { text-align: right; font-size: 9.5pt; line-height: 1.45; }
.firma .naziv { font-size: 13pt; font-weight: 700; }
.title { display: flex; justify-content: space-between; align-items: baseline;
         margin: 10px 0 6px; }
.title h1 { font-size: 15pt; letter-spacing: .5px; }
.title .no { font-size: 13pt; font-weight: 700; }
.meta { font-size: 9.5pt; color: #333; }
.meta span { margin-left: 14px; }
.parties { display: flex; gap: 10mm; margin: 8px 0 12px; }
.party { border: 1px solid #bbb; padding: 7px 9px; min-width: 78mm; }
.party .label { font-size: 8.5pt; text-transform: uppercase; color: #666;
                letter-spacing: .6px; }
.party .naziv { font-weight: 700; font-size: 11pt; }
.party div { line-height: 1.4; }
table { width: 100%; border-collapse: collapse; }
th { background: #eee; border: 1px solid #999; padding: 4px 5px; font-size: 9pt;
     text-align: left; white-space: nowrap; }
td { border: 1px solid #bbb; padding: 4px 5px; font-size: 9.5pt; white-space: nowrap; }
td:first-child + td + td, th:first-child + th + th { white-space: normal; }
td.r, th.r { text-align: right; }
td.c, th.c { text-align: center; }
tbody tr:nth-child(even) td { background: #fafafa; }
.totals { margin-top: 10px; display: flex; justify-content: flex-end; }
.totals table { width: auto; min-width: 78mm; }
.totals td { border: none; padding: 3px 6px; }
.totals td.v { text-align: right; min-width: 34mm; }
.totals tr.grand td { border-top: 2px solid #333; font-weight: 700;
                      font-size: 12pt; padding-top: 6px; }
.note { margin-top: 12px; font-size: 9.5pt; }
.note .label { color: #666; }
.signs { display: flex; justify-content: space-between; margin-top: 18mm;
         font-size: 9.5pt; }
.signs div { width: 55mm; border-top: 1px solid #666; padding-top: 4px;
             text-align: center; }
.signs .mp { border: 1px dashed #aaa; border-radius: 50%; width: 26mm;
             height: 26mm; line-height: 26mm; color: #999; }
.foot { margin-top: 8mm; font-size: 8pt; color: #888; text-align: center; }
.small { font-size: 9pt; color: #555; }
@media print { .noprint { display: none !important; } }
.noprint { margin: 10px auto; max-width: 186mm; font-size: 10pt; color: #555; }
"""


# ------------------------------------------------------------------ фирмата
def logo_file() -> Path | None:
    """Патека до логото за документите, или `None`.

    Тука е и единствената брана за логото: **нерегистриран примерок не печати
    лого**. Се враќа истиот празен пат како кога сликата недостасува, за да не
    се воведува нова гранка низ прегледот, печатачот и PDF-от.
    """
    from .registracija import aktivna

    if not aktivna():
        return None
    name = settings.get("firma_logo", "").strip()
    if not name:
        return None
    path = Path(name)
    if not path.is_absolute():
        path = app_dir() / name
    return path if path.exists() else None


def company() -> dict:
    """Податоците за фирмата што се печатат (од ПОДЕСУВАЊА → Фирма).

    Кај **нерегистриран** примерок називот и логото се празни — тоа е она што
    го отклучува регистрацијата. Сè друго стои како и досега.
    """
    from .registracija import aktivna

    values = settings.all()
    registrirana = aktivna()
    return {
        "naziv": (values.get("firma_naziv") or "") if registrirana else "",
        "adresa": values.get("firma_adresa") or "",
        "grad": " ".join(x for x in (values.get("firma_postenski") or "",
                                     values.get("firma_grad") or "") if x).strip(),
        "drzava": values.get("firma_drzava") or "",
        "telefon": values.get("firma_telefon") or "",
        "email": values.get("firma_email") or "",
        "web": values.get("firma_web") or "",
        "edb": values.get("firma_edb") or values.get("ujp_edb") or "",
        "embs": values.get("firma_embs") or values.get("ujp_embs") or "",
        "banka": values.get("firma_banka") or "",
        "smetka": values.get("firma_ziro_smetka") or "",
        "direktor": values.get("firma_direktor") or "",
        "logo": (values.get("firma_logo") or "") if registrirana else "",
    }


def logo_tag() -> str:
    """Логото се вградува во HTML-от, за да работи и офлајн и во PDF."""
    import base64
    import mimetypes

    path = logo_file()
    if path is None:
        return ""
    mime = mimetypes.guess_type(str(path))[0] or "image/png"
    try:
        data = base64.b64encode(path.read_bytes()).decode("ascii")
    except OSError:
        return ""
    return f'<img src="data:{mime};base64,{data}" alt="">'


def bank_lines() -> list[str]:
    """Сметките што одат во заглавието на документот."""
    from .repo import bank_accounts

    rows = bank_accounts.for_invoice()
    if rows:
        return [" · ".join(x for x in (row["bank_name"], row["account_no"]) if x)
                for row in rows]
    firm = company()
    text = " · ".join(x for x in (firm["banka"], firm["smetka"]) if x)
    return [text] if text else []


def company_block() -> str:
    firm = company()
    parts = []
    if firm["naziv"]:
        parts.append(f'<div class="naziv">{escape(firm["naziv"])}</div>')
    for text in (firm["adresa"], firm["grad"]):
        if text:
            parts.append(f"<div>{escape(text)}</div>")
    contact = " · ".join(x for x in (firm["telefon"], firm["email"], firm["web"]) if x)
    if contact:
        parts.append(f"<div>{escape(contact)}</div>")
    ids = " · ".join(x for x in (f"ЕДБ {firm['edb']}" if firm["edb"] else "",
                                 f"ЕМБС {firm['embs']}" if firm["embs"] else "") if x)
    if ids:
        parts.append(f"<div>{escape(ids)}</div>")
    for text in bank_lines():
        parts.append(f"<div>{escape(text)}</div>")
    return ('<div class="head">'
            f'<div class="logo">{logo_tag()}</div>'
            f'<div class="firma">{"".join(parts)}</div>'
            "</div>")


# --------------------------------------------------------------- изградба
def page(title: str, body: str, hint: str = "") -> str:
    """Целата страница: заглавие на фирмата + содржина."""
    note = (f'<div class="noprint">{escape(hint)}</div>') if hint else ""
    return (
        "<!DOCTYPE html><html lang='mk'><head><meta charset='utf-8'>"
        f"<title>{escape(title)}</title><style>{A4_CSS}</style></head><body>"
        f'<div class="doc">{company_block()}{body}'
        '<div class="foot">Изработено во MikroERP</div></div>'
        f"{note}</body></html>"
    )


def table(columns: list[dict], rows: list[dict], wide: str = "") -> str:
    """`columns`: [{"key","text","align"}] — истите клучеви како во редовите.

    `wide` е клучот на колоната што го зема вишокот простор (обично називот).
    """
    if not wide:
        wide = next((c["key"] for c in columns if c["key"] in ("name", "what",
                                                               "description")), "")
    group = "".join(
        f'<col{" style=\'width:100%\'" if col["key"] == wide else ""}>'
        for col in columns) if wide else ""
    head = "".join(
        f'<th class="{col.get("align", "")}">{escape(str(col["text"]))}</th>'
        for col in columns)
    body = []
    for row in rows:
        cells = []
        for col in columns:
            value = row.get(col["key"], "")
            css = col.get("align", "")
            if row.get("_bold"):
                css = (css + " b").strip()
            cells.append(f'<td class="{css}">{escape(str(value))}</td>')
        body.append("<tr>" + "".join(cells) + "</tr>")
    return (f"<table>{group}<thead><tr>{head}</tr></thead>"
            f"<tbody>{''.join(body)}</tbody></table>")


def totals_block(rows: list[tuple]) -> str:
    """`rows`: [(текст, вредност, дали е главен)]"""
    out = []
    for label, value, grand in rows:
        css = ' class="grand"' if grand else ""
        out.append(f'<tr{css}><td>{escape(str(label))}</td>'
                   f'<td class="v">{escape(str(value))}</td></tr>')
    return f'<div class="totals"><table>{"".join(out)}</table></div>'


def document_html(doc) -> str:
    """Истиот `Doc` што го црта прегледот — тука како HTML за PDF."""
    body = [f'<div class="title"><h1>{escape(doc.title.upper())}</h1>'
            f'<div class="no">{escape(doc.doc_no)}</div></div>']
    if doc.meta:
        body.append('<div class="meta">' + "".join(
            f"<span><b>{escape(str(label))}:</b> {escape(str(value))}</span>"
            for label, value in doc.meta) + "</div>")
    if doc.info:
        body.append('<div class="meta">' + "".join(
            f"<span>{escape(str(text))}</span>" for text in doc.info) + "</div>")

    if doc.party_name or doc.party:
        lines = []
        if doc.party_name:
            lines.append(f'<div class="naziv">{escape(doc.party_name)}</div>')
        lines += [f"<div>{escape(text)}</div>" for text in doc.party]
        label = (f'<div class="label">{escape(doc.party_label)}</div>'
                 if doc.party_label else "")
        body.append('<div class="parties"><div class="party">'
                    f'{label}{"".join(lines)}</div></div>')

    if doc.columns:
        columns = [{"key": c["key"], "text": c.get("text", ""),
                    "align": "" if c.get("align", "l") == "l" else c["align"]}
                   for c in doc.columns]
        wide = next((c["key"] for c in doc.columns if c.get("wide")), "")
        body.append(table(columns, doc.rows, wide=wide))
    if doc.totals:
        body.append(totals_block(doc.totals))
    if doc.note:
        body.append(f'<div class="note">{escape(doc.note)}</div>')
    if doc.payment_note:
        body.append(f'<div class="note small">{escape(doc.payment_note)}</div>')
    if doc.signs:
        cells = "".join(f'<div class="mp">{escape(s)}</div>' if s == "М.П."
                        else f"<div>{escape(s)}</div>" for s in doc.signs)
        body.append(f'<div class="signs">{cells}</div>')
    title = (doc.title + " " + doc.doc_no).strip()
    return page(title, "".join(body))


# ------------------------------------------------------------- излез/печат
def write_temp(html: str, name: str) -> Path:
    folder = Path(tempfile.gettempdir()) / "mikroerp_print"
    folder.mkdir(parents=True, exist_ok=True)
    safe = "".join(ch for ch in name if ch.isalnum() or ch in "-_. ") or "dokument"
    path = folder / (safe + ".html")
    path.write_text(html, encoding="utf-8")
    return path


def open_print(html: str, name: str) -> Path:
    """Го отвора документот во прелистувач со отворен дијалог за печатење."""
    path = write_temp(html.replace("</body>",
                                   "<script>window.onload=function(){"
                                   "setTimeout(function(){window.print();},250);};"
                                   "</script></body>"), name)
    webbrowser.open(path.as_uri())
    return path


def open_view(html: str, name: str) -> Path:
    path = write_temp(html, name)
    webbrowser.open(path.as_uri())
    return path


def browsers() -> list[str]:
    """Сите најдени прелистувачи што умеат да прават PDF, по ред.

    Намерно се враќа список, а не еден: Edge знае да остане скршен додека се
    ажурира во позадина (враќа успех, а не создава PDF). Тогаш се пробува
    следниот наместо да се јави дека PDF не може.
    """
    candidates: list[str] = []
    if sys.platform == "win32":
        for base in (os.environ.get("PROGRAMFILES(X86)"), os.environ.get("PROGRAMFILES"),
                     os.environ.get("LOCALAPPDATA")):
            if not base:
                continue
            candidates += [
                str(Path(base) / "Microsoft/Edge/Application/msedge.exe"),
                str(Path(base) / "Google/Chrome/Application/chrome.exe"),
            ]
    else:
        for name in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge"):
            found = shutil.which(name)
            if found:
                candidates.append(found)
    found = []
    for path in candidates:
        if path and Path(path).exists() and path not in found:
            found.append(path)
    return found


def find_browser() -> str:
    """Првиот најден прелистувач (за проверка дали воопшто има некој)."""
    all_found = browsers()
    return all_found[0] if all_found else ""


class PdfError(RuntimeError):
    pass


def save_pdf(html: str, target: Path, name: str = "dokument") -> Path:
    """HTML → PDF преку прелистувачот. Крева `PdfError` ако ниту еден не успее."""
    found = browsers()
    if not found:
        raise PdfError("Не е најден Edge ниту Chrome за претворање во PDF.")
    source = write_temp(html, name)
    target = Path(target)
    profile = Path(tempfile.gettempdir()) / "mikroerp_print" / "profil"

    last = ""
    for index, browser in enumerate(found):
        target.unlink(missing_ok=True)
        command = [
            browser, "--headless=new", "--disable-gpu", "--no-first-run",
            "--no-pdf-header-footer", "--print-to-pdf-no-header",
            f"--user-data-dir={profile}-{index}",
            f"--print-to-pdf={target}", source.as_uri(),
        ]
        try:
            result = subprocess.run(
                command, capture_output=True, timeout=120,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except (OSError, subprocess.SubprocessError) as exc:
            last = str(exc)
            continue
        if target.exists() and target.stat().st_size > 0:
            return target
        # Прелистувачот може да врати успех, а да не создаде ништо (пр. Edge
        # среде ажурирање) — затоа се гледа фајлот, не излезниот код.
        last = (result.stderr or b"").decode("utf-8", "replace").strip()[-300:]

    raise PdfError(
        "PDF-от не е создаден со ниту еден од најдените прелистувачи.\n\n"
        "Ако Edge се ажурира во моментов, обиди се повторно за неколку минути. "
        "Документот и онака може да се испечати со копчето „Печати“."
        + (f"\n\n{last}" if last else ""))


