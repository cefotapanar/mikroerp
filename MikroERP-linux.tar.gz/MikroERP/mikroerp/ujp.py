# -*- coding: utf-8 -*-
"""Јавен регистар на даночни обврзници на УЈП (ujp.gov.mk).

Пребарување по **назив, дел од назив, ЕДБ или матичен број** и читање детали
за фирмата — за автоматско пополнување на клиент. Јавни податоци, без најава.

Пренесено од `app/Services/UjpRegistry.php` од големиот ЕРП. Користи само
стандардната библиотека, за да не му треба ништо на портабилниот пакет.
"""

from __future__ import annotations

import html
import re
import urllib.parse
import urllib.request

BASE_HOSTS = ("https://www.ujp.gov.mk", "http://www.ujp.gov.mk")
SEARCH_PATH = "/mk/prebaruvanje_pravni_lica/prebaruvaj?pravno_lice={q}&x=0&y=0"
SHOW_PATH = "/mk/prebaruvanje_pravni_lica/prikazi?edb={edb}"
USER_AGENT = "Mozilla/5.0 (compatible; MikroERP)"
TIMEOUT = 12

HIT_RE = re.compile(
    r'<a href="/mk/prebaruvanje_pravni_lica/prikazi\?edb=([^"]+)">([^<]+)</a>', re.U)
CELL_RE = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.S | re.I)
TAG_RE = re.compile(r"<[^>]+>")
SPACE_RE = re.compile(r"\s+", re.U)


class UjpError(RuntimeError):
    """Порака што директно се покажува на корисникот."""


def _get(path: str) -> str:
    last: Exception | None = None
    for host in BASE_HOSTS:
        request = urllib.request.Request(host + path, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
                if response.status != 200:
                    continue
                return response.read().decode("utf-8", errors="replace")
        except Exception as exc:  # noqa: BLE001 — мрежата може да падне на многу начини
            last = exc
            continue
    raise UjpError("Не може да се дојде до ujp.gov.mk.\n\n"
                   "Провери ја врската со интернет." + (f"\n\n({last})" if last else ""))


def _clean(text: str) -> str:
    return SPACE_RE.sub(" ", html.unescape(TAG_RE.sub("", text))).strip()


def search(term: str, limit: int = 20) -> list[dict]:
    """Пребарување → [{edb, name}]."""
    term = str(term or "").strip()
    if len(term) < 3:
        raise UjpError("Внеси барем 3 знаци (назив, ЕДБ или матичен број).")
    page = _get(SEARCH_PATH.format(q=urllib.parse.quote(term, safe="")))
    out = []
    for edb, name in HIT_RE.findall(page)[:limit]:
        out.append({"edb": edb.strip(), "name": html.unescape(name).strip()})
    return out


def _clean_account(account: str) -> str:
    """УЈП ја враќа сметката дополнета до 18 цифри со три водечки нули;
    вистинската МК сметка е 15 цифри."""
    account = account.strip()
    if len(account) == 18 and account.startswith("000") and account.isdigit():
        return account[3:]
    return account


def details(edb: str) -> dict | None:
    """Детали за фирма по ЕДБ (со или без префикс MK)."""
    page = _get(SHOW_PATH.format(edb=urllib.parse.quote(str(edb).strip(), safe="")))
    cells = [_clean(cell) for cell in CELL_RE.findall(page)]

    def find(label: str) -> str:
        for index, cell in enumerate(cells):
            if cell == label:
                return cells[index + 1] if index + 1 < len(cells) else ""
        return ""

    name = find("Назив")
    if not name:
        return None
    return {
        "name": name,
        "legal_form": find("Правна форма"),
        "activity": find("Дејност"),
        "edb": re.sub(r"^MK", "", find("ЕДБ")),
        "maticen": find("Матичен број"),
        "account_no": _clean_account(find("Жиро сметка")),
        "bank": find("Депонент банка"),
        "address": find("Адреса"),
        "city": find("Место"),
        "phone": find("Телефон"),
    }


def fetch(hit: dict) -> dict | None:
    """Деталите за една најдена фирма.

    Листата од пребарувањето го дава **кратниот** назив („МАКПЕТРОЛ АД СКОПЈЕ“),
    а страницата со детали го дава **полниот** („МАКПЕТРОЛ Акционерско друштво
    за промет со нафта и нафтени деривати Скопје“). Ги враќаме двата.
    """
    data = details(hit["edb"])
    if not data:
        return None
    data["full_name"] = data.get("name") or ""
    data["short_name"] = hit.get("name") or data["full_name"]
    return data


def lookup(term: str) -> dict:
    """Она што му треба на копчето „Повлечи од УЈП“.

    Враќа:
      {"kind": "details", "data": {...}}  — точно една фирма
      {"kind": "list",    "hits": [...]}  — повеќе, корисникот избира
      {"kind": "none"}                    — ништо не е најдено
    """
    hits = search(str(term or "").strip())
    if not hits:
        return {"kind": "none"}
    if len(hits) == 1:
        data = fetch(hits[0])
        return {"kind": "details", "data": data} if data else {"kind": "none"}
    return {"kind": "list", "hits": hits}


def split_address(address: str) -> tuple[str, str]:
    """Адреса во еден ред → (улица, број).

    УЈП ја дава адресата слепена („КОСТА НОВАКОВИЌ 22/2-2“), а е-Фактура ја
    бара разделена. Бројот е ПОСЛЕДНИОТ дел што почнува со цифра — не првиот,
    зашто има улици што почнуваат со број („11 Октомври 25“). „ББ“ (без број)
    исто се прима како број.
    """
    text = " ".join(str(address or "").split())
    if not text:
        return "", ""
    parts = text.split(" ")
    if len(parts) > 1:
        last = parts[-1]
        if last[0].isdigit() or last.upper().rstrip(".") in ("ББ", "BB"):
            street = " ".join(parts[:-1]).strip(" ,")
            # „бр.“ пред бројот не оди во бројот
            if street.upper().endswith(("БР.", "БР", "BR.", "BR")):
                street = street.rsplit(" ", 1)[0].strip(" ,")
            return street, last
    return text, ""


def split_city(place: str) -> str:
    """„СКОПЈЕ - АЕРОДРОМ“ → „СКОПЈЕ“ (по цртичката стои општината)."""
    text = " ".join(str(place or "").split())
    for delimiter in (" - ", " – ", " — "):
        if delimiter in text:
            return text.split(delimiter)[0].strip()
    return text


def to_partner(data: dict) -> dict:
    """Од податоците на УЈП во полињата на клиентот.

    `name` е кратниот назив (главен насекаде), `full_name` е полниот.
    """
    full = data.get("full_name") or data.get("name") or ""
    return {
        "name": data.get("short_name") or full,
        "full_name": full,
        "tax_number": data.get("edb") or "",
        "reg_number": data.get("maticen") or "",
        "address": data.get("address") or "",
        "city": data.get("city") or "",
        "phone": data.get("phone") or "",
        "bank_account": data.get("account_no") or "",
        "bank_name": data.get("bank") or "",
        "country": "Македонија",
        "kind": "правно",
    }
