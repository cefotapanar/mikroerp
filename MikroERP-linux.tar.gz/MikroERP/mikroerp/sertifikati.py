# -*- coding: utf-8 -*-
"""Сертификати од Windows складот — за потпишување на е-Фактура.

УЈП бара документот да е потпишан со сертификат на фирмата (обично на USB
токен). Сертификатот НЕ е вграден во апликацијата: се избира од складот на
Windows, за да може истиот софтвер да работи за друга фирма со друг токен.

Се чита преку `crypt32` со ctypes — без надворешна библиотека, како и сè друго.
Приватниот клуч не се чита никогаш; тој останува на токенот и потпишувањето го
прави Windows.
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes
from dataclasses import dataclass

WINDOWS = sys.platform == "win32"

# Складови: „Лични“ на корисникот е местото каде се појавува токенот.
STORE_MY = "MY"
CERT_STORE_PROV_SYSTEM_W = 10
CERT_SYSTEM_STORE_CURRENT_USER = 1 << 16
CERT_SYSTEM_STORE_LOCAL_MACHINE = 2 << 16

CERT_NAME_SIMPLE_DISPLAY_TYPE = 4
CERT_NAME_ISSUER_FLAG = 1
X509_ASN_ENCODING = 0x00000001
PKCS_7_ASN_ENCODING = 0x00010000
ENCODING = X509_ASN_ENCODING | PKCS_7_ASN_ENCODING


@dataclass
class Sertifikat:
    subject: str = ""
    issuer: str = ""
    serial: str = ""
    valid_from: str = ""
    valid_to: str = ""
    store: str = "korisnik"
    has_key: bool = False          # има ли приватен клуч (без него нема потпис)
    expired: bool = False

    @property
    def usable(self) -> bool:
        """Може ли воопшто да се потпише со него."""
        return self.has_key and not self.expired

    @property
    def problem(self) -> str:
        if self.expired:
            return "истечен"
        if not self.has_key:
            return "нема приватен клуч"
        return ""

    @property
    def label(self) -> str:
        znak = "✓" if self.usable else "✗"
        rok = f"  ·  важи до {self.valid_to}" if self.valid_to else ""
        loshо = f"  ·  {self.problem.upper()}" if self.problem else ""
        return f"{znak}  {self.subject}  ·  {self.serial}{rok}{loshо}"


if WINDOWS:
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    class FILETIME(ctypes.Structure):
        _fields_ = [("dwLowDateTime", wintypes.DWORD),
                    ("dwHighDateTime", wintypes.DWORD)]

    class CRYPT_INTEGER_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD),
                    ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    class CRYPT_ALGORITHM_IDENTIFIER(ctypes.Structure):
        _fields_ = [("pszObjId", ctypes.c_char_p),
                    ("Parameters", CRYPT_INTEGER_BLOB)]

    class CERT_INFO(ctypes.Structure):
        _fields_ = [
            ("dwVersion", wintypes.DWORD),
            ("SerialNumber", CRYPT_INTEGER_BLOB),
            ("SignatureAlgorithm", CRYPT_ALGORITHM_IDENTIFIER),
            ("Issuer", CRYPT_INTEGER_BLOB),
            ("NotBefore", FILETIME),
            ("NotAfter", FILETIME),
            ("Subject", CRYPT_INTEGER_BLOB),
        ]

    class CERT_CONTEXT(ctypes.Structure):
        _fields_ = [
            ("dwCertEncodingType", wintypes.DWORD),
            ("pbCertEncoded", ctypes.POINTER(ctypes.c_byte)),
            ("cbCertEncoded", wintypes.DWORD),
            ("pCertInfo", ctypes.POINTER(CERT_INFO)),
            ("hCertStore", ctypes.c_void_p),
        ]

    PCERT_CONTEXT = ctypes.POINTER(CERT_CONTEXT)

    crypt32.CertOpenStore.restype = ctypes.c_void_p
    crypt32.CertOpenStore.argtypes = [ctypes.c_void_p, wintypes.DWORD,
                                      ctypes.c_void_p, wintypes.DWORD,
                                      ctypes.c_void_p]
    crypt32.CertEnumCertificatesInStore.restype = PCERT_CONTEXT
    crypt32.CertEnumCertificatesInStore.argtypes = [ctypes.c_void_p, PCERT_CONTEXT]
    crypt32.CertGetNameStringW.restype = wintypes.DWORD
    crypt32.CertGetNameStringW.argtypes = [PCERT_CONTEXT, wintypes.DWORD,
                                           wintypes.DWORD, ctypes.c_void_p,
                                           wintypes.LPWSTR, wintypes.DWORD]
    crypt32.CertCloseStore.argtypes = [ctypes.c_void_p, wintypes.DWORD]
    crypt32.CertGetCertificateContextProperty.restype = wintypes.BOOL
    crypt32.CertGetCertificateContextProperty.argtypes = [
        PCERT_CONTEXT, wintypes.DWORD, ctypes.c_void_p,
        ctypes.POINTER(wintypes.DWORD)]


def _name(context, issuer: bool = False) -> str:
    flags = CERT_NAME_ISSUER_FLAG if issuer else 0
    size = crypt32.CertGetNameStringW(context, CERT_NAME_SIMPLE_DISPLAY_TYPE,
                                      flags, None, None, 0)
    if size <= 1:
        return ""
    buffer = ctypes.create_unicode_buffer(size)
    crypt32.CertGetNameStringW(context, CERT_NAME_SIMPLE_DISPLAY_TYPE, flags,
                               None, buffer, size)
    return buffer.value


CERT_KEY_PROV_INFO_PROP_ID = 2


def _has_private_key(context) -> bool:
    """Дали Windows знае за приватниот клуч (кај токен — дали е вклучен)."""
    size = wintypes.DWORD(0)
    ok = crypt32.CertGetCertificateContextProperty(
        context, CERT_KEY_PROV_INFO_PROP_ID, None, ctypes.byref(size))
    return bool(ok) and size.value > 0


def _serial(info) -> str:
    """Серискиот број — бајтите доаѓаат обратно, како кај Windows приказот."""
    blob = info.SerialNumber
    data = bytes(blob.pbData[i] & 0xFF for i in range(blob.cbData))
    return data[::-1].hex().lstrip("0").upper() or "0"


def _moment(filetime):
    """FILETIME → datetime (или None)."""
    import datetime

    value = (filetime.dwHighDateTime << 32) | filetime.dwLowDateTime
    if not value:
        return None
    try:
        return datetime.datetime.fromtimestamp(
            value / 10_000_000 - 11_644_473_600)          # од 1601 во 1970
    except (OverflowError, OSError, ValueError):
        return None


def _as_date(moment) -> str:
    return moment.strftime("%d.%m.%Y") if moment else ""


def list_certificates(include_machine: bool = True) -> list[Sertifikat]:
    """Сертификатите што ги гледа Windows (личен склад на корисникот и машината)."""
    if not WINDOWS:
        return []
    found: list[Sertifikat] = []
    stores = [(CERT_SYSTEM_STORE_CURRENT_USER, "корисник")]
    if include_machine:
        stores.append((CERT_SYSTEM_STORE_LOCAL_MACHINE, "компјутер"))

    for flag, label in stores:
        handle = crypt32.CertOpenStore(
            ctypes.c_void_p(CERT_STORE_PROV_SYSTEM_W), 0, None, flag,
            ctypes.c_wchar_p(STORE_MY))
        if not handle:
            continue
        try:
            context = crypt32.CertEnumCertificatesInStore(handle, None)
            while context:
                info = context.contents.pCertInfo.contents
                import datetime

                do = _moment(info.NotAfter)
                od = _moment(info.NotBefore)
                sega = datetime.datetime.now()
                item = Sertifikat(
                    subject=_name(context), issuer=_name(context, issuer=True),
                    serial=_serial(info), valid_from=_as_date(od),
                    valid_to=_as_date(do), store=label,
                    has_key=_has_private_key(context),
                    expired=bool((do and do < sega) or (od and od > sega)))
                if item.subject and not any(x.serial == item.serial for x in found):
                    found.append(item)
                context = crypt32.CertEnumCertificatesInStore(handle, context)
        finally:
            crypt32.CertCloseStore(handle, 0)
    # Прво оние со кои може да се потпише — тие се бараат.
    found.sort(key=lambda c: (not c.usable, c.subject.lower()))
    return found


def by_serial(serial: str) -> Sertifikat | None:
    serial = str(serial or "").strip().upper()
    if not serial:
        return None
    for item in list_certificates():
        if item.serial == serial:
            return item
    return None
