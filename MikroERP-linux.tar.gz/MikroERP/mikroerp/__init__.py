# -*- coding: utf-8 -*-
from .version import VERSION, APP_NAME

__all__ = ["VERSION", "APP_NAME"]
