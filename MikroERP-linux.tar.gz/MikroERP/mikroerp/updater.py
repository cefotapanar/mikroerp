# -*- coding: utf-8 -*-
"""Проверка и преземање нова верзија.

Изворот се пишува во `config.ini` → `[update] izvor` и може да биде:

* **GitHub репо** — `cefotapanar/mikroerp`. Тогаш најновото издание се чита
  преку јавниот GitHub API; нема манифест да се одржува, само се качува ново
  издание во прелистувачот.
* **Адреса до JSON** — `https://…/latest.json` со `{"verzija": …, "zip": …}`,
  ако некогаш се качува на сопствен сајт.
* **Мрежна папка** — `\\\\server\\erp\\update`, каде стои `latest.json` и ZIP-от.

Празно поле = проверката е исклучена и апликацијата не бара ништо на интернет.

Зошто вака: ажурирањето мора да работи и без ниту една инсталирана алатка кај
корисникот, и да не пипне ништо од неговите податоци.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

from .config import config
from .paths import app_dir
from .version import VERSION

TIMEOUT = 12
AGENT = {"User-Agent": "MikroERP-updater"}

# Оттука се земаат новите верзии ако во config.ini не е впишано друго.
# Репото е трајно и е само за пакети — изворниот код не оди таму.
DEFAULT_SOURCE = "cefotapanar/mikroerp"

# Со ваква вредност во config.ini проверката се гаси наполно.
OFF_VALUES = {"isklucheno", "исклучено", "off", "ne", "не", "-", "0"}

# Папки и фајлови што НИКОГАШ не се препишуваат при ажурирање.
KEEP = ("data", "backups", "logs")
KEEP_FILES = ("config.ini",)


class UpdateError(RuntimeError):
    pass


@dataclass
class Release:
    version: str
    url: str = ""
    size: int = 0
    notes: str = ""
    name: str = ""
    sha256: str = ""

    @property
    def newer(self) -> bool:
        return is_newer(self.version, VERSION)


# ------------------------------------------------------------------ верзии
def _parts(version: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", str(version or "0"))) or (0,)


def is_newer(candidate: str, current: str = VERSION) -> bool:
    """Дали `candidate` е поновa од `current` (0.20.0 > 0.9.0)."""
    left, right = _parts(candidate), _parts(current)
    size = max(len(left), len(right))
    left += (0,) * (size - len(left))
    right += (0,) * (size - len(right))
    return left > right


def configured() -> str:
    """Она што е впишано во config.ini (може да е празно)."""
    return str(config().get("update", "izvor") or "").strip()


def _apply_unix(new_folder: Path) -> None:
    """Истото како на Windows, само со школка наместо cmd.

    И тука фајловите не смеат да се менуваат додека апликацијата работи (макар
    Python веќе ги прочитал), па скриптата чека процесот да излезе.
    """
    target = app_dir()
    folder = Path(tempfile.gettempdir()) / "mikroerp_update"
    folder.mkdir(parents=True, exist_ok=True)
    script = folder / "azuriraj.sh"
    log = folder / "azuriraj.log"
    excludes = " ".join(f"--exclude='{name}'" for name in KEEP + KEEP_FILES)

    script.write_text(
        "#!/bin/sh\n"
        f'PID={os.getpid()}\n'
        f'LOG="{log}"\n'
        'echo "чекам да се затвори $PID" > "$LOG"\n'
        "i=0\n"
        'while kill -0 "$PID" 2>/dev/null; do\n'
        "  i=$((i+1))\n"
        '  [ "$i" -gt 150 ] && { echo "НЕ СЕ ЗАТВОРИ — прекинувам" >> "$LOG"; exit 1; }\n'
        "  sleep 2\n"
        "done\n"
        'echo "копирам" >> "$LOG"\n'
        f'if command -v rsync >/dev/null 2>&1; then\n'
        f'  rsync -a {excludes} "{new_folder}/" "{target}/" >> "$LOG" 2>&1\n'
        "else\n"
        f'  (cd "{new_folder}" && tar cf - .) | (cd "{target}" && tar xf - '
        + " ".join(f"--exclude='{name}'" for name in KEEP + KEEP_FILES)
        + ') >> "$LOG" 2>&1\n'
        "fi\n"
        f'chmod +x "{target}/mikroerp.sh" 2>/dev/null\n'
        'echo "палам повторно" >> "$LOG"\n'
        f'"{target}/mikroerp.sh" >/dev/null 2>&1 &\n',
        encoding="utf-8",
    )
    script.chmod(0o755)
    subprocess.Popen(["/bin/sh", str(script)], stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     start_new_session=True, close_fds=True)


def cleanup() -> None:
    """Го брише привременото од претходно ажурирање (пакетот е ~14 MB).

    Се повикува при стартување: ако ажурирањето поминало, работната папка
    повеќе не му треба никому; ако паднало, дневникот се чува одделно.
    """
    folder = Path(tempfile.gettempdir()) / "mikroerp_update"
    if not folder.exists():
        return
    for item in folder.iterdir():
        if item.name == "azuriraj.log":
            continue
        try:
            if item.is_dir():
                shutil.rmtree(item, ignore_errors=True)
            else:
                item.unlink(missing_ok=True)
        except OSError:
            pass


def source() -> str:
    """Од каде навистина се проверува. Празно = проверката е исклучена."""
    value = configured()
    if value.lower() in OFF_VALUES:
        return ""
    return value or DEFAULT_SOURCE


def is_default() -> bool:
    return source() == DEFAULT_SOURCE and not configured()


def enabled() -> bool:
    return bool(source())


# ---------------------------------------------------------------- проверка
def _fresh(url: str, tag: str = "") -> str:
    """Додава ознака на адресата за да не се врати кеширан одговор.

    GitHub го држи `latest.json` во кеш до неколку минути. Без ова, веднаш по
    објавување апликацијата ја гледа старата верзија — а полошо, може да го
    симне стариот пакет со новиот потпис и да се пожали дека преземањето е
    расипано. Кај манифестот ознаката е времето (секогаш свежо), кај пакетот е
    верзијата (се кешира правилно, по издание).
    """
    if not url.lower().startswith(("http://", "https://")):
        return url
    import time

    mark = tag or str(int(time.time()))
    return url + ("&" if "?" in url else "?") + "v=" + mark


def _read(url: str) -> bytes:
    request = urllib.request.Request(url, headers=dict(AGENT, **{
        "Cache-Control": "no-cache", "Pragma": "no-cache"}))
    with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
        return response.read()


def asset_for_platform(data: dict) -> tuple[str, int, str]:
    """Кој пакет е за овој систем: (име, големина, потпис).

    Windows добива .zip со готова апликација, Linux добива .tar.gz со изворот
    (PyInstaller не може да гради за друг систем, па Linux пакетот е изворен и
    се пушта со `mikroerp.sh`).
    """
    if sys.platform != "win32":
        linux = data.get("linux") or {}
        if linux.get("fajl"):
            return (str(linux["fajl"]), int(linux.get("golemina") or 0),
                    str(linux.get("sha256") or "").strip())
    return (str(data.get("zip") or "MikroERP.zip"),
            int(data.get("golemina") or 0),
            str(data.get("sha256") or "").strip())


def _github_file(repo: str, path: str) -> bytes | None:
    """Фајл од репото преку API. `None` ако го нема.

    Намерно НЕ се чита преку raw.githubusercontent.com: таму одговорот стои во
    кеш до 5 минути, па веднаш по објавување апликацијата гледа стара верзија —
    и уште полошо, може да го земе стариот пакет со новиот потпис. API-то е
    свежо и го дава истиот фајл.
    """
    url = f"https://api.github.com/repos/{repo}/contents/{path}"
    request = urllib.request.Request(url, headers=dict(
        AGENT, Accept="application/vnd.github.raw"))
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return None
        raise


def _from_github(repo: str) -> Release:
    # Прво се гледа `latest.json` во самото репо (така објавува objavi.py).
    try:
        manifest = _github_file(repo, "latest.json")
    except (urllib.error.URLError, OSError) as exc:
        raise UpdateError(f"Нема врска со GitHub:\n{exc}") from exc
    if manifest is not None:
        try:
            data = json.loads(manifest.decode("utf-8", "replace"))
        except ValueError as exc:
            raise UpdateError("latest.json во репото не е исправен.") from exc
        version = str(data.get("verzija") or data.get("version") or "").lstrip("vV")
        if not version:
            raise UpdateError("Во latest.json недостасува „verzija“.")
        name, size, digest = asset_for_platform(data)
        return Release(
            version=version,
            url=f"https://api.github.com/repos/{repo}/contents/{name}",
            size=size,
            notes=str(data.get("napomena") or "").strip(),
            name=name, sha256=digest)

    api = f"https://api.github.com/repos/{repo}/releases/latest"
    try:
        data = json.loads(_read(api).decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise UpdateError(
                f"Во „{repo}“ нема ни latest.json ни објавено издание.\n\n"
                "Провери го името на репото.")
        raise UpdateError(f"GitHub врати грешка {exc.code}.") from exc
    except (urllib.error.URLError, OSError) as exc:
        raise UpdateError(f"Нема врска со GitHub:\n{exc}") from exc
    except ValueError as exc:
        raise UpdateError("GitHub врати неразбирлив одговор.") from exc

    version = str(data.get("tag_name") or data.get("name") or "").lstrip("vV")
    asset = None
    for item in data.get("assets") or []:
        if str(item.get("name", "")).lower().endswith(".zip"):
            asset = item
            break
    if not version:
        raise UpdateError("Изданието на GitHub нема ознака со верзија.")
    if asset is None:
        raise UpdateError(
            f"Изданието {version} нема прикачен ZIP.\n\n"
            "Во GitHub, кај Release, повлечи го MikroERP-<верзија>.zip.")
    return Release(version=version, url=asset["browser_download_url"],
                   size=int(asset.get("size") or 0),
                   notes=str(data.get("body") or "").strip(),
                   name=str(asset.get("name") or ""))


def _from_manifest(url_or_folder: str) -> Release:
    """`latest.json` на сајт или во мрежна папка."""
    base = url_or_folder.rstrip("/\\")
    if base.lower().startswith(("http://", "https://")):
        target = base if base.lower().endswith(".json") else base + "/latest.json"
        raw = _read(_fresh(target))
        root = target.rsplit("/", 1)[0]
    else:
        folder = Path(base)
        target = folder if folder.suffix.lower() == ".json" else folder / "latest.json"
        if not target.exists():
            raise UpdateError(f"Не е најден {target}.")
        raw = target.read_bytes()
        root = str(target.parent)
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
    except ValueError as exc:
        raise UpdateError("Датотеката latest.json не е исправна.") from exc

    version = str(data.get("verzija") or data.get("version") or "").lstrip("vV")
    link = str(data.get("zip") or data.get("url") or "")
    if link and not link.lower().startswith(("http://", "https://")) \
            and not Path(link).is_absolute():
        link = (root + "/" + link) if root.startswith("http") else str(Path(root) / link)
    if not version or not link:
        raise UpdateError("Во latest.json недостасува „verzija“ или „zip“.")
    return Release(version=version, url=link, size=int(data.get("golemina") or 0),
                   notes=str(data.get("napomena") or "").strip(),
                   name=Path(link).name,
                   sha256=str(data.get("sha256") or "").strip())


def check() -> Release | None:
    """Кое издание е најново. `None` ако проверката е исклучена."""
    izvor = source()
    if not izvor:
        return None
    if re.fullmatch(r"[\w.-]+/[\w.-]+", izvor):        # корисник/репо
        return _from_github(izvor)
    return _from_manifest(izvor)


# --------------------------------------------------------------- преземање
def download(release: Release, on_progress=None) -> Path:
    """Го симнува ZIP-от во привремена папка и враќа патека до него."""
    folder = Path(tempfile.gettempdir()) / "mikroerp_update"
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / (release.name or f"MikroERP-{release.version}.zip")

    if release.url.lower().startswith(("http://", "https://")):
        headers = dict(AGENT)
        if "api.github.com" in release.url:
            headers["Accept"] = "application/vnd.github.raw"
            link = release.url                 # API-то не кешира долго
        else:
            # Ознака со верзијата — за да не дојде стар пакет од кешот.
            link = _fresh(release.url, release.version)
        request = urllib.request.Request(link, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
                total = int(response.headers.get("Content-Length") or release.size or 0)
                done = 0
                with open(target, "wb") as out:
                    while True:
                        chunk = response.read(65536)
                        if not chunk:
                            break
                        out.write(chunk)
                        done += len(chunk)
                        if on_progress:
                            on_progress(done, total)
        except (urllib.error.URLError, OSError) as exc:
            raise UpdateError(f"Преземањето не успеа:\n{exc}") from exc
    else:
        try:
            shutil.copy2(release.url, target)
        except OSError as exc:
            raise UpdateError(f"Датотеката не може да се копира:\n{exc}") from exc

    if release.sha256:
        import hashlib

        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        if digest.lower() != release.sha256.lower():
            target.unlink(missing_ok=True)
            raise UpdateError(
                "Преземената датотека не е онаа што се очекува (различен потпис).\n\n"
                "Најверојатно преземањето прекинало. Пробај повторно.")
    import tarfile

    # Windows добива .zip, Linux .tar.gz — и двата мора да се отвораат.
    if not (zipfile.is_zipfile(target) or tarfile.is_tarfile(target)):
        raise UpdateError("Преземеното не е исправен пакет — "
                          "прекини и пробај пак.")
    return target


def unpack(archive_path: Path) -> Path:
    """Го отпакува пакетот и ја враќа папката со новата верзија."""
    import tarfile

    folder = Path(archive_path).parent / "raspakuvano"
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True, exist_ok=True)
    path = Path(archive_path)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            archive.extractall(folder)
    elif tarfile.is_tarfile(path):
        with tarfile.open(path) as archive:
            archive.extractall(folder, filter="data")
    else:
        raise UpdateError("Преземеното не е ниту ZIP ниту tar.gz.")

    # Пакетот носи една папка (MikroERP/) — внатре е апликацијата
    entries = [p for p in folder.iterdir() if p.is_dir()]
    root = entries[0] if len(entries) == 1 else folder
    if not (root / "MikroERP.exe").exists() and not (root / "main.py").exists():
        raise UpdateError("Во пакетот нема ни MikroERP.exe ни main.py — "
                          "не е вистинскиот пакет.")
    return root


# --------------------------------------------------------------- вградување
def is_linux_package() -> bool:
    """Linux пакетот е изворен — се препознава по скриптата за пуштање."""
    return sys.platform != "win32" and (app_dir() / "mikroerp.sh").exists()


def can_apply() -> tuple[bool, str]:
    if sys.platform == "win32":
        if not getattr(sys, "frozen", False):
            return False, ("Ажурирањето работи само на спакуваната верзија "
                           "(MikroERP.exe), не и кога се стартува од изворен код.")
        return True, ""
    if is_linux_package():
        return True, ""
    return False, ("Ажурирањето работи на спакуваната верзија; овде "
                   "апликацијата е пуштена од изворен код.")


def apply(new_folder: Path) -> None:
    """Ги заменува фајловите и ја рестартира апликацијата.

    Windows не дозволува програмата сама да се пребрише додека работи, па
    работата ја завршува мала придружна скрипта: чека овој процес да излезе,
    ги копира новите фајлови и повторно ја пали апликацијата. Податоците
    (`data`, `backups`, `logs`, `config.ini`) намерно се прескокнуваат.
    """
    ok, reason = can_apply()
    if not ok:
        raise UpdateError(reason)
    if sys.platform != "win32":
        return _apply_unix(new_folder)

    target = app_dir()
    exclude_dirs = " ".join(f'"{name}"' for name in KEEP)
    exclude_files = " ".join(f'"{name}"' for name in KEEP_FILES)
    folder = Path(tempfile.gettempdir()) / "mikroerp_update"
    folder.mkdir(parents=True, exist_ok=True)
    script = folder / "azuriraj.cmd"
    log = folder / "azuriraj.log"
    probe = folder / "proces.txt"

    # Чекањето НАМЕРНО е без цевки (`tasklist | find`): кога скриптата се пушта
    # без конзола, `find` останува да чека на влез и целото ажурирање виси.
    # Затоа списокот процеси оди во датотека, па се пребарува во неа.
    script.write_text(
        "@echo off\r\n"
        "setlocal\r\n"
        f'set "PID={os.getpid()}"\r\n'
        f'set "LOG={log}"\r\n'
        f'set "PROBE={probe}"\r\n'
        'echo [%DATE% %TIME%] чекам да се затвори %PID% > "%LOG%"\r\n'
        "set /a BROJ=0\r\n"
        ":cekaj\r\n"
        "set /a BROJ+=1\r\n"
        'if %BROJ% GTR 150 (echo НЕ СЕ ЗАТВОРИ — прекинувам >> "%LOG%" & goto kraj)\r\n'
        'tasklist /FI "PID eq %PID%" /NH /FO CSV > "%PROBE%" 2>nul\r\n'
        'findstr /C:"%PID%" "%PROBE%" >nul 2>nul\r\n'
        "if not errorlevel 1 (\r\n"
        "  ping -n 2 127.0.0.1 >nul\r\n"
        "  goto cekaj\r\n"
        ")\r\n"
        'echo [%TIME%] копирам >> "%LOG%"\r\n'
        f'robocopy "{new_folder}" "{target}" /E /IS /IT /R:2 /W:1 '
        f'/XD {exclude_dirs} /XF {exclude_files} >> "%LOG%" 2>&1\r\n'
        'if errorlevel 8 (echo КОПИРАЊЕТО ПАДНА >> "%LOG%" & goto kraj)\r\n'
        'echo [%TIME%] палам повторно >> "%LOG%"\r\n'
        f'start "" "{target / "MikroERP.exe"}"\r\n'
        ":kraj\r\n"
        'del "%PROBE%" 2>nul\r\n',
        encoding="utf-8",
    )
    # Без DETACHED_PROCESS: тој ѝ ја одзема конзолата на скриптата, па секоја
    # наредба отвора свој прозорец. CREATE_NO_WINDOW е доволно и е тивко.
    subprocess.Popen(
        ["cmd", "/c", str(script)],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
        | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        close_fds=True,
    )
