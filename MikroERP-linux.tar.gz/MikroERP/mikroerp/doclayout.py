# -*- coding: utf-8 -*-
"""Распоред на документот на А4 — еден распоред за преглед и за печатач.

Документот се опишува како податоци (`Doc`), а тука се претвора во **примитиви
во милиметри**: текст, линија, правоаголник, слика. Потоа истите примитиви ги
црта и прегледот на екран и печатачот — па она што се гледа е она што излегува.

Мерењето на текстот оди преку tkinter (го има секогаш), на фиксна мерка од
`MEASURE` пиксели на милиметар; при цртање само се менува размерот.
"""

from __future__ import annotations

from dataclasses import dataclass, field

PAGE_W, PAGE_H = 210.0, 297.0        # A4 во милиметри
MARGIN_X, MARGIN_TOP, MARGIN_BOTTOM = 12.0, 12.0, 14.0
CONTENT_W = PAGE_W - 2 * MARGIN_X
CONTENT_BOTTOM = PAGE_H - MARGIN_BOTTOM

MEASURE = 4.0                        # пиксели на милиметар при мерење
PT_MM = 0.3528                       # 1 типографска точка во милиметри

# стил → (големина во точки, задебелено, боја)
STYLES = {
    "firm": (13.0, True, "#000000"),
    "firmline": (9.0, False, "#222222"),
    "title": (15.0, True, "#000000"),
    "docno": (13.0, True, "#000000"),
    "meta": (9.5, False, "#333333"),
    "label": (8.0, False, "#666666"),
    "party": (11.0, True, "#000000"),
    "normal": (9.5, False, "#111111"),
    "th": (9.0, True, "#000000"),
    "td": (9.5, False, "#111111"),
    "small": (8.5, False, "#555555"),
    "grand": (12.0, True, "#000000"),
    "foot": (8.0, False, "#888888"),
}

HEAD_FILL = "#EEEEEE"
GRID = "#BBBBBB"
GRID_HEAD = "#999999"


def line_height(style: str) -> float:
    return STYLES[style][0] * PT_MM * 1.35


@dataclass
class Doc:
    """Документ подготвен за хартија."""
    title: str = ""
    doc_no: str = ""
    file_name: str = "dokument"
    meta: list = field(default_factory=list)          # [(етикета, вредност)]
    party_label: str = ""
    party: list = field(default_factory=list)         # редови текст
    party_name: str = ""
    columns: list = field(default_factory=list)       # [{"key","text","align","w"}]
    rows: list = field(default_factory=list)
    totals: list = field(default_factory=list)        # [(текст, вредност, главен)]
    note: str = ""
    payment_note: str = ""
    signs: list = field(default_factory=list)
    info: list = field(default_factory=list)          # редови контекст (извештаи)


# --------------------------------------------------------------- мерење
_fonts: dict = {}


def _font(style: str, scale: float = MEASURE):
    from tkinter import font as tkfont

    size, bold, _color = STYLES[style]
    key = (style, round(scale, 3))
    if key not in _fonts:
        _fonts[key] = tkfont.Font(size=-max(1, round(size * PT_MM * scale)),
                                  weight="bold" if bold else "normal")
    return _fonts[key]


def measure(text: str, style: str) -> float:
    """Ширина на текстот во милиметри."""
    if not text:
        return 0.0
    try:
        return _font(style).measure(str(text)) / MEASURE
    except Exception:      # noqa: BLE001 — без Tk (тест без прозорец) → проценка
        return len(str(text)) * STYLES[style][0] * PT_MM * 0.52


def elide(text: str, style: str, width: float) -> str:
    """Го скратува текстот со „…“ ако не собира во ширината."""
    text = str(text or "")
    if measure(text, style) <= width:
        return text
    while text and measure(text + "…", style) > width:
        text = text[:-1]
    return text + "…" if text else ""


def wrap(text: str, style: str, width: float, max_lines: int = 3) -> list[str]:
    words = str(text or "").split()
    lines: list[str] = []
    current = ""
    for word in words:
        probe = (current + " " + word).strip()
        if measure(probe, style) <= width or not current:
            current = probe
        else:
            lines.append(current)
            current = word
            if len(lines) == max_lines - 1:
                break
    if current:
        lines.append(current)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
    if lines and measure(lines[-1], style) > width:
        lines[-1] = elide(lines[-1], style, width)
    return lines or [""]


# ------------------------------------------------------------- распоред
class _Painter:
    """Собира примитиви за една страница."""

    def __init__(self):
        self.pages: list[list] = [[]]

    @property
    def current(self) -> list:
        return self.pages[-1]

    def new_page(self) -> None:
        self.pages.append([])

    def text(self, x, y, text, style="normal", width=None, align="l"):
        if text in (None, ""):
            return
        self.current.append(("text", float(x), float(y), text, style,
                             None if width is None else float(width), align))

    def line(self, x1, y1, x2, y2, width=0.25, color="#333333"):
        self.current.append(("line", float(x1), float(y1), float(x2), float(y2),
                             float(width), color))

    def rect(self, x, y, w, h, fill=None, outline=GRID, width=0.2):
        self.current.append(("rect", float(x), float(y), float(w), float(h),
                             fill, outline, float(width)))

    def image(self, x, y, w, h, path):
        self.current.append(("image", float(x), float(y), float(w), float(h), path))


def _company_lines() -> tuple[str, list[str], str]:
    from .paper import company

    firm = company()
    lines = [x for x in (firm["adresa"], firm["grad"]) if x]
    contact = " · ".join(x for x in (firm["telefon"], firm["email"], firm["web"]) if x)
    if contact:
        lines.append(contact)
    ids = " · ".join(x for x in (f"ЕДБ {firm['edb']}" if firm["edb"] else "",
                                 f"ЕМБС {firm['embs']}" if firm["embs"] else "") if x)
    if ids:
        lines.append(ids)
    from .paper import bank_lines
    lines += bank_lines()

    # Истата брана како кај PDF-от: нерегистриран примерок нема лого.
    from .paper import logo_file

    candidate = logo_file()
    path = ""
    if candidate is not None and candidate.suffix.lower() in (".png", ".gif"):
        path = str(candidate)
    return firm["naziv"], lines, path


def _column_widths(doc: Doc) -> list[float]:
    """Ширини по колона: бројките колку што им треба, називот го зема вишокот."""
    padding = 2.6
    widths = []
    for col in doc.columns:
        style_head = "th"
        width = measure(col.get("text", ""), style_head)
        for row in doc.rows[:400]:
            width = max(width, measure(row.get(col["key"], ""), "td"))
        widths.append(width + padding)
    total = sum(widths)
    stretch = next((i for i, c in enumerate(doc.columns) if c.get("wide")), None)
    if stretch is None:
        stretch = max(range(len(widths)), key=lambda i: widths[i]) if widths else None
    if stretch is not None:
        if total < CONTENT_W:
            widths[stretch] += CONTENT_W - total
        elif total > CONTENT_W:
            widths[stretch] = max(18.0, widths[stretch] - (total - CONTENT_W))
    return widths


def paginate(doc: Doc) -> list[list]:
    """Го распоредува документот и враќа список страници со примитиви."""
    painter = _Painter()
    left, right = MARGIN_X, MARGIN_X + CONTENT_W
    y = MARGIN_TOP

    # ------------------------------------------------------------- заглавие
    naziv, firm_lines, logo = _company_lines()
    top = y
    if logo:
        painter.image(left, y, 55, 20, logo)
    painter.text(left, y, naziv, "firm", CONTENT_W, "r")
    y += line_height("firm")
    for text in firm_lines:
        painter.text(left, y, text, "firmline", CONTENT_W, "r")
        y += line_height("firmline")
    if logo:
        y = max(y, top + 20)
    y += 1.6
    painter.line(left, y, right, y, 0.6)
    y += 3.5

    # ---------------------------------------------------------------- наслов
    painter.text(left, y, doc.title.upper(), "title")
    if doc.doc_no:
        painter.text(left, y + 0.6, doc.doc_no, "docno", CONTENT_W, "r")
    y += line_height("title") + 1.2

    if doc.meta:
        parts = "     ".join(f"{label}: {value}" for label, value in doc.meta)
        painter.text(left, y, parts, "meta")
        y += line_height("meta") + 1.5
    for text in doc.info:
        painter.text(left, y, text, "meta")
        y += line_height("meta")
    if doc.info:
        y += 1.5

    # ----------------------------------------------------------- другата страна
    if doc.party or doc.party_name:
        box_w = 88.0
        inner = 2.4
        box_y = y
        cursor = box_y + inner
        rows = []
        if doc.party_label:
            rows.append((doc.party_label.upper(), "label"))
        if doc.party_name:
            rows.append((doc.party_name, "party"))
        rows += [(text, "normal") for text in doc.party]
        height = sum(line_height(style) for _t, style in rows) + 2 * inner
        painter.rect(left, box_y, box_w, height, None, GRID)
        for text, style in rows:
            painter.text(left + inner, cursor, elide(text, style, box_w - 2 * inner),
                         style)
            cursor += line_height(style)
        y = box_y + height + 4.5

    # ---------------------------------------------------------------- табела
    widths = _column_widths(doc)
    head_h = line_height("th") + 1.6
    row_h = line_height("td") + 1.4

    def draw_head(top_y: float) -> float:
        painter.rect(left, top_y, sum(widths), head_h, HEAD_FILL, GRID_HEAD)
        x = left
        for col, width in zip(doc.columns, widths):
            painter.text(x + 1.3, top_y + 0.9,
                         elide(col.get("text", ""), "th", width - 2.6), "th",
                         width - 2.6, col.get("align", "l"))
            if x > left:
                painter.line(x, top_y, x, top_y + head_h, 0.2, GRID_HEAD)
            x += width
        return top_y + head_h

    if doc.columns:
        y = draw_head(y)
        for row in doc.rows:
            if y + row_h > CONTENT_BOTTOM - 6:
                painter.text(left, CONTENT_BOTTOM - 4, "продолжува…", "small",
                             CONTENT_W, "r")
                painter.new_page()
                y = draw_head(MARGIN_TOP)
            painter.rect(left, y, sum(widths), row_h, None, GRID)
            x = left
            for col, width in zip(doc.columns, widths):
                painter.text(x + 1.3, y + 0.7,
                             elide(row.get(col["key"], ""), "td", width - 2.6), "td",
                             width - 2.6, col.get("align", "l"))
                if x > left:
                    painter.line(x, y, x, y + row_h, 0.2, GRID)
                x += width
            y += row_h
        y += 4

    # --------------------------------------------------------------- збирови
    if doc.totals:
        need = sum(line_height("grand" if grand else "normal") + 1.2
                   for _l, _v, grand in doc.totals)
        if y + need > CONTENT_BOTTOM:
            painter.new_page()
            y = MARGIN_TOP
        box_w = 80.0
        x = right - box_w
        for label, value, grand in doc.totals:
            style = "grand" if grand else "normal"
            if grand:
                painter.line(x, y, right, y, 0.5)
                y += 1.4
            painter.text(x, y, label, style)
            painter.text(x, y, value, style, box_w, "r")
            y += line_height(style) + 1.0
        y += 3

    # ----------------------------------------------------- забелешки и потписи
    for text, style in ((doc.note, "normal"), (doc.payment_note, "small")):
        if not text:
            continue
        for part in wrap(text, style, CONTENT_W, max_lines=4):
            if y + line_height(style) > CONTENT_BOTTOM:
                painter.new_page()
                y = MARGIN_TOP
            painter.text(left, y, part, style)
            y += line_height(style)
        y += 2.5

    if doc.signs:
        y = max(y + 12, CONTENT_BOTTOM - 26)
        if y + 16 > CONTENT_BOTTOM:
            painter.new_page()
            y = CONTENT_BOTTOM - 26
        slot = CONTENT_W / len(doc.signs)
        for index, text in enumerate(doc.signs):
            x = left + index * slot
            if text == "М.П.":
                painter.text(x, y - 2, text, "small", slot, "c")
                continue
            painter.line(x + slot * 0.12, y, x + slot * 0.88, y, 0.25, "#666666")
            painter.text(x, y + 1.2, text, "small", slot, "c")

    for pageno, primitives in enumerate(painter.pages, start=1):
        label = (f"Страна {pageno} од {len(painter.pages)}   ·   "
                 if len(painter.pages) > 1 else "")
        primitives.append(("text", MARGIN_X, PAGE_H - MARGIN_BOTTOM + 4,
                           label + "Изработено во MikroERP", "foot", CONTENT_W, "c"))
    return painter.pages
