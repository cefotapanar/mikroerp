# -*- coding: utf-8 -*-
"""Миграции на базата.

Секој update на апликацијата додава НОВА миграција на крајот од листата —
никогаш не се менува веќе објавена миграција.  При стартување апликацијата
ги извршува само оние што недостасуваат, во трансакција.  Така базата на
корисникот се надградува сама, без губење податоци.
"""

from __future__ import annotations

from .db import Database
from .logging_setup import log

# ---------------------------------------------------------------------------
# 001 — основа: подесувања, шифрарник (брендови, клиенти, артикли), броила
# ---------------------------------------------------------------------------
M001 = """
CREATE TABLE settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT ''
);

CREATE TABLE brands (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    note       TEXT    NOT NULL DEFAULT '',
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_brands_name ON brands (name COLLATE NOCASE);

CREATE TABLE partners (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    code           TEXT    NOT NULL DEFAULT '',
    name           TEXT    NOT NULL,
    tax_number     TEXT    NOT NULL DEFAULT '',   -- ЕДБ
    reg_number     TEXT    NOT NULL DEFAULT '',   -- ЕМБС
    address        TEXT    NOT NULL DEFAULT '',
    city           TEXT    NOT NULL DEFAULT '',
    country        TEXT    NOT NULL DEFAULT 'Македонија',
    phone          TEXT    NOT NULL DEFAULT '',
    email          TEXT    NOT NULL DEFAULT '',
    contact_person TEXT    NOT NULL DEFAULT '',
    bank_account   TEXT    NOT NULL DEFAULT '',
    bank_name      TEXT    NOT NULL DEFAULT '',
    is_customer    INTEGER NOT NULL DEFAULT 1,    -- купувач
    is_supplier    INTEGER NOT NULL DEFAULT 0,    -- добавувач
    note           TEXT    NOT NULL DEFAULT '',
    active         INTEGER NOT NULL DEFAULT 1,
    created_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_partners_name ON partners (name COLLATE NOCASE);
CREATE UNIQUE INDEX ux_partners_code ON partners (code COLLATE NOCASE) WHERE code <> '';

CREATE TABLE items (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    code           TEXT    NOT NULL,              -- шифра
    barcode        TEXT    NOT NULL DEFAULT '',
    name           TEXT    NOT NULL,
    brand_id       INTEGER REFERENCES brands (id) ON DELETE SET NULL,
    unit           TEXT    NOT NULL DEFAULT 'ком',
    tax_rate       REAL    NOT NULL DEFAULT 18,   -- ДДВ %
    purchase_price REAL    NOT NULL DEFAULT 0,    -- набавна (без ДДВ)
    price_retail   REAL    NOT NULL DEFAULT 0,    -- МПЦ (со ДДВ)
    price_partner  REAL    NOT NULL DEFAULT 0,    -- партнерска (без ДДВ)
    min_stock      REAL    NOT NULL DEFAULT 0,
    note           TEXT    NOT NULL DEFAULT '',
    active         INTEGER NOT NULL DEFAULT 1,
    created_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at     TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_items_code ON items (code COLLATE NOCASE);
CREATE INDEX ix_items_name  ON items (name COLLATE NOCASE);
CREATE INDEX ix_items_brand ON items (brand_id);

-- Броила за нумерирање на документите, посебно по тип и по година.
CREATE TABLE doc_counters (
    doc_type TEXT    NOT NULL,
    year     INTEGER NOT NULL,
    last_no  INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (doc_type, year)
);
"""

M002 = """
-- Магацини. Засега се работи со еден (стандардниот), но сите документи и
-- движења го носат магацинот од прв ден, за да може подоцна да се вклучат
-- повеќе магацини без преправање на податоците.
CREATE TABLE warehouses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT    NOT NULL DEFAULT '',
    name       TEXT    NOT NULL,
    address    TEXT    NOT NULL DEFAULT '',
    is_default INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    note       TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_warehouses_name ON warehouses (name COLLATE NOCASE);
INSERT INTO warehouses (code, name, is_default) VALUES ('01', 'Главен магацин', 1);

-- Приемници (влез на стока во магацин)
CREATE TABLE goods_receipts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_no        TEXT    NOT NULL,              -- PR-0001-26
    doc_year      INTEGER NOT NULL,
    doc_seq       INTEGER NOT NULL,
    date          TEXT    NOT NULL,              -- YYYY-MM-DD
    partner_id    INTEGER REFERENCES partners (id),
    warehouse_id  INTEGER NOT NULL REFERENCES warehouses (id),
    supplier_doc  TEXT    NOT NULL DEFAULT '',   -- број на документ од добавувачот
    supplier_date TEXT    NOT NULL DEFAULT '',
    status        TEXT    NOT NULL DEFAULT 'нацрт',   -- нацрт | проведена
    update_prices INTEGER NOT NULL DEFAULT 1,         -- при проведување да ја запише набавната цена во шифрарникот
    note          TEXT    NOT NULL DEFAULT '',
    total_net     REAL    NOT NULL DEFAULT 0,
    total_vat     REAL    NOT NULL DEFAULT 0,
    total_gross   REAL    NOT NULL DEFAULT 0,
    posted_at     TEXT    NOT NULL DEFAULT '',
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_receipts_no ON goods_receipts (doc_no);
CREATE INDEX ix_receipts_date ON goods_receipts (date);

CREATE TABLE goods_receipt_items (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_id INTEGER NOT NULL REFERENCES goods_receipts (id) ON DELETE CASCADE,
    line_no    INTEGER NOT NULL DEFAULT 0,
    item_id    INTEGER NOT NULL REFERENCES items (id),
    qty        REAL    NOT NULL DEFAULT 0,
    price      REAL    NOT NULL DEFAULT 0,       -- набавна по единица, без ДДВ
    discount   REAL    NOT NULL DEFAULT 0,       -- рабат во %
    tax_rate   REAL    NOT NULL DEFAULT 18,
    net        REAL    NOT NULL DEFAULT 0,
    vat        REAL    NOT NULL DEFAULT 0,
    gross      REAL    NOT NULL DEFAULT 0
);
CREATE INDEX ix_receipt_items_receipt ON goods_receipt_items (receipt_id);
CREATE INDEX ix_receipt_items_item ON goods_receipt_items (item_id);

-- FIFO серии: секој влез прави серија со своја цена на чинење.
CREATE TABLE stock_batches (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id         INTEGER NOT NULL REFERENCES items (id),
    warehouse_id    INTEGER NOT NULL REFERENCES warehouses (id),
    date            TEXT    NOT NULL,
    doc_type        TEXT    NOT NULL,
    doc_id          INTEGER NOT NULL,
    doc_no          TEXT    NOT NULL DEFAULT '',
    source_line_id  INTEGER,
    qty_in          REAL    NOT NULL DEFAULT 0,
    qty_left        REAL    NOT NULL DEFAULT 0,
    unit_cost       REAL    NOT NULL DEFAULT 0,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_batches_fifo ON stock_batches (item_id, warehouse_id, date, id);

-- Сите движења: + влез, − излез. Залихата е збир од оваа табела.
CREATE TABLE stock_moves (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id      INTEGER NOT NULL REFERENCES items (id),
    warehouse_id INTEGER NOT NULL REFERENCES warehouses (id),
    date         TEXT    NOT NULL,
    doc_type     TEXT    NOT NULL,
    doc_id       INTEGER NOT NULL,
    doc_no       TEXT    NOT NULL DEFAULT '',
    batch_id     INTEGER REFERENCES stock_batches (id),
    qty          REAL    NOT NULL DEFAULT 0,
    unit_cost    REAL    NOT NULL DEFAULT 0,
    value        REAL    NOT NULL DEFAULT 0,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_moves_item ON stock_moves (item_id, warehouse_id);
CREATE INDEX ix_moves_doc ON stock_moves (doc_type, doc_id);
"""

# ---------------------------------------------------------------------------
# Регистар на миграции: (број, опис, SQL)
# Новите update-и се додаваат ТУКА, на крајот.
# ---------------------------------------------------------------------------
M003 = """
-- Артиклите добиваат вид (производ/услуга), дозвола за негативна залиха и
-- парни цени (без ДДВ / со ДДВ) за малопродажната и партнерската цена.
ALTER TABLE items ADD COLUMN is_service         INTEGER NOT NULL DEFAULT 0;
ALTER TABLE items ADD COLUMN allow_negative     INTEGER NOT NULL DEFAULT 0;
ALTER TABLE items ADD COLUMN price_retail_net   REAL    NOT NULL DEFAULT 0;
ALTER TABLE items ADD COLUMN price_partner_gross REAL   NOT NULL DEFAULT 0;

-- Постоечките податоци: price_retail беше „со ДДВ“, price_partner „без ДДВ“.
UPDATE items SET price_retail_net =
    ROUND(price_retail / (1 + tax_rate / 100.0), 2) WHERE price_retail <> 0;
UPDATE items SET price_partner_gross =
    ROUND(price_partner * (1 + tax_rate / 100.0), 2) WHERE price_partner <> 0;
"""

M004 = """
-- Испратници (излез на стока од магацин). `cost` е цената на чинење што
-- FIFO ја одзел за таа ставка — основа за пресметка на заработувачка.
CREATE TABLE goods_issues (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_no       TEXT    NOT NULL,              -- IS-0001-26
    doc_year     INTEGER NOT NULL,
    doc_seq      INTEGER NOT NULL,
    date         TEXT    NOT NULL,
    partner_id   INTEGER REFERENCES partners (id),
    warehouse_id INTEGER NOT NULL REFERENCES warehouses (id),
    status       TEXT    NOT NULL DEFAULT 'проведена',
    note         TEXT    NOT NULL DEFAULT '',
    total_net    REAL    NOT NULL DEFAULT 0,
    total_vat    REAL    NOT NULL DEFAULT 0,
    total_gross  REAL    NOT NULL DEFAULT 0,
    total_cost   REAL    NOT NULL DEFAULT 0,
    posted_at    TEXT    NOT NULL DEFAULT '',
    created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_issues_no ON goods_issues (doc_no);
CREATE INDEX ix_issues_date ON goods_issues (date);

CREATE TABLE goods_issue_items (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id INTEGER NOT NULL REFERENCES goods_issues (id) ON DELETE CASCADE,
    line_no  INTEGER NOT NULL DEFAULT 0,
    item_id  INTEGER NOT NULL REFERENCES items (id),
    qty      REAL    NOT NULL DEFAULT 0,
    price    REAL    NOT NULL DEFAULT 0,        -- продажна по единица, без ДДВ
    discount REAL    NOT NULL DEFAULT 0,
    tax_rate REAL    NOT NULL DEFAULT 18,
    net      REAL    NOT NULL DEFAULT 0,
    vat      REAL    NOT NULL DEFAULT 0,
    gross    REAL    NOT NULL DEFAULT 0,
    cost     REAL    NOT NULL DEFAULT 0
);
CREATE INDEX ix_issue_items_issue ON goods_issue_items (issue_id);
CREATE INDEX ix_issue_items_item ON goods_issue_items (item_id);
"""

M005 = """
-- Продажни документи: профактура и излезна фактура во иста табела, за да може
-- профактурата да се претвори во фактура без препишување.
--   * профактурата НИКОГАШ не ја движи залихата;
--   * фактурата ја движи, освен ако е направена од испратница
--     (тогаш стоката веќе излегла и `moves_stock` е 0).
CREATE TABLE sales_docs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kind         TEXT    NOT NULL,              -- profaktura | faktura
    doc_no       TEXT    NOT NULL,              -- PF-0001-26 / IF-0001-26
    doc_year     INTEGER NOT NULL,
    doc_seq      INTEGER NOT NULL,
    date         TEXT    NOT NULL,
    due_date     TEXT    NOT NULL DEFAULT '',   -- рок на плаќање / важи до
    partner_id   INTEGER REFERENCES partners (id),
    warehouse_id INTEGER NOT NULL REFERENCES warehouses (id),
    issue_id     INTEGER REFERENCES goods_issues (id),   -- фактурирана испратница
    source_id    INTEGER REFERENCES sales_docs (id),     -- профактурата од која е
    moves_stock  INTEGER NOT NULL DEFAULT 0,
    note         TEXT    NOT NULL DEFAULT '',
    total_net    REAL    NOT NULL DEFAULT 0,
    total_vat    REAL    NOT NULL DEFAULT 0,
    total_gross  REAL    NOT NULL DEFAULT 0,
    total_cost   REAL    NOT NULL DEFAULT 0,
    created_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_sales_no ON sales_docs (kind, doc_no);
CREATE INDEX ix_sales_kind_date ON sales_docs (kind, date);
CREATE INDEX ix_sales_issue ON sales_docs (issue_id);
CREATE INDEX ix_sales_source ON sales_docs (source_id);

CREATE TABLE sales_doc_items (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_id   INTEGER NOT NULL REFERENCES sales_docs (id) ON DELETE CASCADE,
    line_no  INTEGER NOT NULL DEFAULT 0,
    item_id  INTEGER NOT NULL REFERENCES items (id),
    qty      REAL    NOT NULL DEFAULT 0,
    price    REAL    NOT NULL DEFAULT 0,
    discount REAL    NOT NULL DEFAULT 0,
    tax_rate REAL    NOT NULL DEFAULT 18,
    net      REAL    NOT NULL DEFAULT 0,
    vat      REAL    NOT NULL DEFAULT 0,
    gross    REAL    NOT NULL DEFAULT 0,
    cost     REAL    NOT NULL DEFAULT 0
);
CREATE INDEX ix_sales_items_doc ON sales_doc_items (doc_id);
CREATE INDEX ix_sales_items_item ON sales_doc_items (item_id);
"""

M006 = """
-- Видот на артиклот станува три-вреден:
--   стока    — се купува и продава (стандардно)
--   производ — се ИЗРАБОТУВА со работен налог (само тие можат да се
--              произведуваат); може и да се купува
--   услуга   — не се води на залиха
-- `is_service` останува како брз показател дали артиклот воопшто оди на лагер.
ALTER TABLE items ADD COLUMN kind TEXT NOT NULL DEFAULT 'стока';
UPDATE items SET kind = 'услуга' WHERE is_service = 1;

-- Влезни фактури (обврска кон добавувач).
--   * направена од приемница → стоката веќе влегла, фактурата само ја евидентира;
--   * самостојна → сама ја внесува стоката во магацин (`moves_stock` = 1).
CREATE TABLE purchase_invoices (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_no        TEXT    NOT NULL,             -- VF-0001-26
    doc_year      INTEGER NOT NULL,
    doc_seq       INTEGER NOT NULL,
    date          TEXT    NOT NULL,
    due_date      TEXT    NOT NULL DEFAULT '',  -- рок на плаќање
    partner_id    INTEGER REFERENCES partners (id),
    warehouse_id  INTEGER NOT NULL REFERENCES warehouses (id),
    receipt_id    INTEGER REFERENCES goods_receipts (id),
    supplier_doc  TEXT    NOT NULL DEFAULT '',  -- бројот на фактурата кај добавувачот
    supplier_date TEXT    NOT NULL DEFAULT '',
    moves_stock   INTEGER NOT NULL DEFAULT 0,
    update_prices INTEGER NOT NULL DEFAULT 1,
    note          TEXT    NOT NULL DEFAULT '',
    total_net     REAL    NOT NULL DEFAULT 0,
    total_vat     REAL    NOT NULL DEFAULT 0,
    total_gross   REAL    NOT NULL DEFAULT 0,
    created_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at    TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_purchases_no ON purchase_invoices (doc_no);
CREATE INDEX ix_purchases_date ON purchase_invoices (date);
CREATE INDEX ix_purchases_receipt ON purchase_invoices (receipt_id);

CREATE TABLE purchase_invoice_items (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_id   INTEGER NOT NULL REFERENCES purchase_invoices (id) ON DELETE CASCADE,
    line_no  INTEGER NOT NULL DEFAULT 0,
    item_id  INTEGER NOT NULL REFERENCES items (id),
    qty      REAL    NOT NULL DEFAULT 0,
    price    REAL    NOT NULL DEFAULT 0,
    discount REAL    NOT NULL DEFAULT 0,
    tax_rate REAL    NOT NULL DEFAULT 18,
    net      REAL    NOT NULL DEFAULT 0,
    vat      REAL    NOT NULL DEFAULT 0,
    gross    REAL    NOT NULL DEFAULT 0
);
CREATE INDEX ix_purchase_items_doc ON purchase_invoice_items (doc_id);
CREATE INDEX ix_purchase_items_item ON purchase_invoice_items (item_id);
"""

M007 = """
-- Работни налози: материјалите излегуваат од еден магацин, готовиот производ
-- влегува во друг (може и во истиот). Цената на чинење на производот е збир
-- на цените на чинење на вложените материјали, поделен со произведената
-- количина.
CREATE TABLE work_orders (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_no            TEXT    NOT NULL,          -- RN-0001-26
    doc_year          INTEGER NOT NULL,
    doc_seq           INTEGER NOT NULL,
    date              TEXT    NOT NULL,
    item_id           INTEGER NOT NULL REFERENCES items (id),   -- производот
    qty               REAL    NOT NULL DEFAULT 0,
    from_warehouse_id INTEGER NOT NULL REFERENCES warehouses (id),
    to_warehouse_id   INTEGER NOT NULL REFERENCES warehouses (id),
    status            TEXT    NOT NULL DEFAULT 'започнат',      -- започнат | произведен
    material_cost     REAL    NOT NULL DEFAULT 0,
    unit_cost         REAL    NOT NULL DEFAULT 0,
    produced_at       TEXT    NOT NULL DEFAULT '',
    note              TEXT    NOT NULL DEFAULT '',
    created_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at        TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_work_orders_no ON work_orders (doc_no);
CREATE INDEX ix_work_orders_date ON work_orders (date);
CREATE INDEX ix_work_orders_item ON work_orders (item_id);

CREATE TABLE work_order_items (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES work_orders (id) ON DELETE CASCADE,
    line_no  INTEGER NOT NULL DEFAULT 0,
    item_id  INTEGER NOT NULL REFERENCES items (id),
    qty      REAL    NOT NULL DEFAULT 0,
    cost     REAL    NOT NULL DEFAULT 0
);
CREATE INDEX ix_work_order_items_order ON work_order_items (order_id);
CREATE INDEX ix_work_order_items_item ON work_order_items (item_id);
"""

M008 = """
-- Банкарски изводи. Може да се внесат рачно или да се увезат од MT940.
CREATE TABLE bank_statements (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    account    TEXT    NOT NULL DEFAULT '',     -- нашата сметка
    bank_name  TEXT    NOT NULL DEFAULT '',
    doc_no     TEXT    NOT NULL,                -- број на изводот
    year       INTEGER NOT NULL,
    date       TEXT    NOT NULL,
    opening    REAL    NOT NULL DEFAULT 0,
    closing    REAL    NOT NULL DEFAULT 0,
    total_in   REAL    NOT NULL DEFAULT 0,
    total_out  REAL    NOT NULL DEFAULT 0,
    ref        TEXT    NOT NULL DEFAULT '',     -- :20: од MT940
    source     TEXT    NOT NULL DEFAULT 'рачно',-- рачно | MT940
    file_name  TEXT    NOT NULL DEFAULT '',
    note       TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_statements ON bank_statements (account, year, doc_no);
CREATE INDEX ix_statements_date ON bank_statements (date);

CREATE TABLE bank_statement_lines (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    statement_id INTEGER NOT NULL REFERENCES bank_statements (id) ON DELETE CASCADE,
    line_no      INTEGER NOT NULL DEFAULT 0,
    date         TEXT    NOT NULL DEFAULT '',
    direction    TEXT    NOT NULL DEFAULT 'прилив',   -- прилив | одлив
    amount       REAL    NOT NULL DEFAULT 0,
    cp_account   TEXT    NOT NULL DEFAULT '',   -- сметка на другата страна
    cp_name      TEXT    NOT NULL DEFAULT '',
    purpose      TEXT    NOT NULL DEFAULT '',
    code         TEXT    NOT NULL DEFAULT '',   -- шифра на намена
    bank_ref     TEXT    NOT NULL DEFAULT '',
    partner_id   INTEGER REFERENCES partners (id),
    matched_by   TEXT    NOT NULL DEFAULT '',   -- сметка | име | рачно | AI
    note         TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_statement_lines ON bank_statement_lines (statement_id);
CREATE INDEX ix_statement_lines_partner ON bank_statement_lines (partner_id);
"""

M009 = """
-- Клиентот е правно или физичко лице. `name` е КРАТКИОТ назив (главен, се
-- гледа насекаде), `full_name` е полниот назив од УЈП (се печати кога ќе се
-- побара). Физичко лице нема ЕДБ/ЕМБС ни контакти.
ALTER TABLE partners ADD COLUMN kind      TEXT NOT NULL DEFAULT 'правно';  -- правно | физичко
ALTER TABLE partners ADD COLUMN full_name TEXT NOT NULL DEFAULT '';

CREATE TABLE partner_contacts (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    partner_id INTEGER NOT NULL REFERENCES partners (id) ON DELETE CASCADE,
    line_no    INTEGER NOT NULL DEFAULT 0,
    name       TEXT    NOT NULL DEFAULT '',
    phone      TEXT    NOT NULL DEFAULT '',
    email      TEXT    NOT NULL DEFAULT '',
    note       TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX ix_partner_contacts ON partner_contacts (partner_id);

-- Дали документот да го печати полниот назив на клиентот.
ALTER TABLE goods_receipts     ADD COLUMN use_full_name INTEGER NOT NULL DEFAULT 0;
ALTER TABLE goods_issues       ADD COLUMN use_full_name INTEGER NOT NULL DEFAULT 0;
ALTER TABLE sales_docs         ADD COLUMN use_full_name INTEGER NOT NULL DEFAULT 0;
ALTER TABLE purchase_invoices  ADD COLUMN use_full_name INTEGER NOT NULL DEFAULT 0;

-- Трошоци. Категоријата служи за извештаи; банкарските одливи стануваат
-- „Оперативни трошоци“ автоматски.
CREATE TABLE expenses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_no      TEXT    NOT NULL,              -- ТР-0001-26
    doc_year    INTEGER NOT NULL,
    doc_seq     INTEGER NOT NULL,
    date        TEXT    NOT NULL,
    partner_id  INTEGER REFERENCES partners (id),
    category    TEXT    NOT NULL DEFAULT '',
    description TEXT    NOT NULL DEFAULT '',
    amount      REAL    NOT NULL DEFAULT 0,    -- со ДДВ
    vat_rate    REAL    NOT NULL DEFAULT 0,
    vat_amount  REAL    NOT NULL DEFAULT 0,
    net         REAL    NOT NULL DEFAULT 0,
    source      TEXT    NOT NULL DEFAULT 'рачно',   -- рачно | извод
    note        TEXT    NOT NULL DEFAULT '',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_expenses_no ON expenses (doc_no);
CREATE INDEX ix_expenses_date ON expenses (date);
CREATE INDEX ix_expenses_category ON expenses (category);

-- Плаќање: ставка од извод затвора фактура или трошок.
CREATE TABLE payments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    line_id     INTEGER NOT NULL REFERENCES bank_statement_lines (id) ON DELETE CASCADE,
    target_kind TEXT    NOT NULL,              -- izlezna_faktura | vlezna_faktura | trosok
    target_id   INTEGER NOT NULL,
    amount      REAL    NOT NULL DEFAULT 0,
    date        TEXT    NOT NULL DEFAULT '',
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX ix_payments_line ON payments (line_id);
CREATE INDEX ix_payments_target ON payments (target_kind, target_id);

-- Ставка од извод што е сама по себе трошок (провизии и слично).
ALTER TABLE bank_statement_lines ADD COLUMN expense_id INTEGER REFERENCES expenses (id);
"""

M010 = """
-- Шифрите на намена на плаќањето стануваат шифрарник што корисникот го уредува
-- и дополнува. Правилата тука одлучуваат што прави изводот сам:
--   auto_expense     — ставката веднаш станува трошок (банкарски провизии…)
--   expense_category — во која категорија
--   ask_always       — не погодувај клиент и не памети сметка (банка/менувачница)
CREATE TABLE payment_codes (
    code             TEXT PRIMARY KEY,
    name             TEXT    NOT NULL DEFAULT '',
    category         TEXT    NOT NULL DEFAULT '',
    auto_expense     INTEGER NOT NULL DEFAULT 0,
    expense_category TEXT    NOT NULL DEFAULT '',
    ask_always       INTEGER NOT NULL DEFAULT 0,
    active           INTEGER NOT NULL DEFAULT 1,
    note             TEXT    NOT NULL DEFAULT ''
);
"""

M011 = """
-- Трошокот што го создала ставка од извод носи ПОТПИС ОД КАДЕ ДОШОЛ.
-- Потписот е „извод:<сметка>|<година>|<број>|<р.бр на ставка>“ и е единствен
-- за таа ставка. Со него истиот извод не може да создаде ист трошок двапати
-- (пр. изводот е избришан, па повторно увезен) — трошокот се препознава и се
-- пре-употребува наместо да се создаде нов.
ALTER TABLE expenses ADD COLUMN origin_key TEXT NOT NULL DEFAULT '';
CREATE INDEX ix_expenses_origin ON expenses (origin_key);

-- Постоечките трошоци создадени од извод го добиваат потписот сега.
UPDATE expenses SET origin_key = COALESCE((
    SELECT 'извод:' || s.account || '|' || s.year || '|' || s.doc_no || '|' || l.line_no
    FROM bank_statement_lines l
    JOIN bank_statements s ON s.id = l.statement_id
    WHERE l.expense_id = expenses.id
    ORDER BY l.id LIMIT 1
), '')
WHERE source = 'извод';
"""

M012 = """
-- Врски меѓу документите: испратница ↔ излезна фактура,
-- приемница ↔ влезна фактура. Табела наместо едно поле, зашто во пракса
-- НЕКОЛКУ испратници одат на ЕДНА фактура (месечна фактура за повеќе испораки),
-- а и една испратница може да се фактурира на делови.
CREATE TABLE doc_links (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_kind TEXT    NOT NULL,          -- ispratnica | priemnica
    source_id   INTEGER NOT NULL,
    target_kind TEXT    NOT NULL,          -- faktura | vlezna_faktura
    target_id   INTEGER NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_doc_links ON doc_links
    (source_kind, source_id, target_kind, target_id);
CREATE INDEX ix_doc_links_target ON doc_links (target_kind, target_id);

-- Постоечките врски (фактура направена од испратница/приемница) влегуваат тука.
INSERT INTO doc_links (source_kind, source_id, target_kind, target_id)
SELECT 'ispratnica', issue_id, 'faktura', id
FROM sales_docs WHERE issue_id IS NOT NULL;

INSERT INTO doc_links (source_kind, source_id, target_kind, target_id)
SELECT 'priemnica', receipt_id, 'vlezna_faktura', id
FROM purchase_invoices WHERE receipt_id IS NOT NULL;
"""

M013 = """
-- Класификација на документот: слободен текст што корисникот сам го смислува
-- (пр. „Веледрогерија“, „Проект Куманово“, „Извоз“). Слободен текст, а не
-- шифрарник, зашто во пракса поделбата се менува — а листата на фактури потоа
-- се филтрира по неа.
ALTER TABLE sales_docs ADD COLUMN classification TEXT NOT NULL DEFAULT '';
CREATE INDEX ix_sales_classification ON sales_docs (classification);
"""

M014 = """
-- Банките и трансакциските сметки на фирмата. Една банка може да има повеќе
-- сметки, а за секоја се одлучува дали се печати на фактурата. Изводите се
-- водат по сметка (`bank_statements.account`), па оваа табела е и изворот за
-- изборот „за која сметка е изводот“.
CREATE TABLE bank_accounts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_name       TEXT    NOT NULL DEFAULT '',
    account_no      TEXT    NOT NULL,
    show_on_invoice INTEGER NOT NULL DEFAULT 1,
    active          INTEGER NOT NULL DEFAULT 1,
    sort_order      INTEGER NOT NULL DEFAULT 0,
    note            TEXT    NOT NULL DEFAULT '',
    created_at      TEXT    NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE UNIQUE INDEX ux_bank_accounts_no ON bank_accounts (account_no);

-- Сметката што досега стоеше во подесувањата станува прва сметка.
INSERT INTO bank_accounts (bank_name, account_no, show_on_invoice)
SELECT COALESCE((SELECT value FROM settings WHERE key = 'firma_banka'), ''),
       (SELECT value FROM settings WHERE key = 'firma_ziro_smetka'), 1
WHERE EXISTS (SELECT 1 FROM settings
              WHERE key = 'firma_ziro_smetka' AND TRIM(value) <> '');
"""

M015 = """
-- Сторно на излезна фактура и повратница на испратница.
--
-- Сторното е ОГЛЕДАЛО на фактурата со негативни количини и износи: во книгите
-- се брише ефектот, а самата фактура останува (бројот не смее да исчезне).
-- Повратницата е испратница во обратна насока — стоката се враќа на залиха по
-- ЦЕНАТА ПО КОЈА ИЗЛЕГЛА (не по набавна, како приемница).
ALTER TABLE sales_docs ADD COLUMN is_storno INTEGER NOT NULL DEFAULT 0;
ALTER TABLE sales_docs ADD COLUMN storno_of_id INTEGER REFERENCES sales_docs (id);
CREATE INDEX ix_sales_storno ON sales_docs (storno_of_id);

-- Состојба во е-Фактура (УЈП). Штом фактурата е поднесена, не смее да се
-- брише — тогаш единствениот пат назад е сторно.
ALTER TABLE sales_docs ADD COLUMN ujp_status TEXT NOT NULL DEFAULT '';
ALTER TABLE sales_docs ADD COLUMN ujp_euid TEXT NOT NULL DEFAULT '';
ALTER TABLE sales_docs ADD COLUMN ujp_sent_at TEXT NOT NULL DEFAULT '';

ALTER TABLE goods_issues ADD COLUMN is_return INTEGER NOT NULL DEFAULT 0;
ALTER TABLE goods_issues ADD COLUMN return_of_id INTEGER REFERENCES goods_issues (id);
CREATE INDEX ix_issues_return ON goods_issues (return_of_id);
"""

MIGRATIONS: list[tuple[int, str, str]] = [
    (1, "Основа: подесувања, брендови, клиенти, артикли, броила", M001),
    (2, "Материјално: магацини, приемници, FIFO серии, движења", M002),
    (3, "Артикли: производ/услуга, негативна залиха, цени со и без ДДВ", M003),
    (4, "Материјално: испратници со цена на чинење по FIFO", M004),
    (5, "Продажба: профактури и излезни фактури", M005),
    (6, "Артикли: вид стока/производ/услуга + влезни фактури", M006),
    (7, "Материјално: работни налози (материјали → производ)", M007),
    (8, "Банка: изводи и ставки од извод", M008),
    (9, "Клиенти: вид и контакти; трошоци; плаќања од извод", M009),
    (10, "Шифри на плаќање како уреден шифрарник", M010),
    (11, "Трошоците од извод носат потпис (без дупли трошоци)", M011),
    (12, "Врски: испратница ↔ фактура, приемница ↔ влезна фактура", M012),
    (13, "Класификација на излезните фактури", M013),
    (14, "Банки и трансакциски сметки на фирмата", M014),
    (15, "Сторно на фактура, повратница на испратница, состојба во УЈП", M015),
]

SCHEMA_TABLE = """
CREATE TABLE IF NOT EXISTS schema_migrations (
    version    INTEGER PRIMARY KEY,
    name       TEXT NOT NULL,
    applied_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
)
"""


def current_version(database: Database) -> int:
    database.execute(SCHEMA_TABLE)
    return int(database.scalar("SELECT COALESCE(MAX(version), 0) FROM schema_migrations", default=0) or 0)


def target_version() -> int:
    return max((m[0] for m in MIGRATIONS), default=0)


def migrate(database: Database) -> int:
    """Ги применува сите миграции што недостасуваат. Враќа колку се применети."""
    database.execute(SCHEMA_TABLE)
    done = {int(r["version"]) for r in database.query("SELECT version FROM schema_migrations")}
    applied = 0
    for version, name, sql in sorted(MIGRATIONS, key=lambda m: m[0]):
        if version in done:
            continue
        log.info("Миграција %03d — %s", version, name)
        # Контролата на трансакцијата мора да е ВО скриптата: executescript()
        # прво комитира сè што е во тек, па надворешен BEGIN не би важел.
        safe_name = name.replace("'", "''")
        script = (
            "BEGIN;\n"
            f"{sql}\n"
            "INSERT INTO schema_migrations (version, name) VALUES "
            f"({version}, '{safe_name}');\n"
            "COMMIT;"
        )
        try:
            database.executescript(script)
        except Exception:
            try:
                database.execute("ROLLBACK")
            except Exception:  # noqa: BLE001 — можно е веќе да нема отворена трансакција
                pass
            log.exception("Падна миграција %03d", version)
            raise
        applied += 1
    if applied:
        log.info("Применети %d миграции. Верзија на шема: %d", applied, current_version(database))
    return applied
