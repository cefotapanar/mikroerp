# -*- coding: utf-8 -*-
"""Ситни помагала — датуми и пребарување низ кирилица/латиница."""

from __future__ import annotations

import re
from datetime import date, datetime

INPUT_FORMATS = ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y", "%d.%m.%y", "%d-%m-%Y")


def today() -> str:
    return date.today().isoformat()


def parse_date(text) -> str:
    """Прифаќа 2026-08-12, 12.08.2026, 12/08/2026 → враќа ISO (за базата)."""
    text = str(text or "").strip()
    if not text:
        return today()
    for pattern in INPUT_FORMATS:
        try:
            return datetime.strptime(text, pattern).date().isoformat()
        except ValueError:
            continue
    raise ValueError(f"Невалиден датум: „{text}“ (пример: 12.08.2026)")


def fmt_date(iso) -> str:
    """ISO од базата → 12.08.2026 за приказ."""
    text = str(iso or "").strip()
    if not text:
        return ""
    try:
        return datetime.strptime(text[:10], "%Y-%m-%d").strftime("%d.%m.%Y")
    except ValueError:
        return text


# --------------------------------------------------------------- пребарување
# Пишувањето „crna“, „црна“ или „CRNA“ мора да го најде истиот артикл.
# Затоа и барањето и текстот се сведуваат на иста „латинична скелетна“ форма:
# ш/ч/ж/ѓ/ќ/љ/њ/џ одат на една буква, а латиничните диграфи (sh, ch, zh, gj…)
# се собираат на истата таа буква.
_CYR = str.maketrans({
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "ѓ": "g", "е": "e",
    "ж": "z", "з": "z", "ѕ": "z", "и": "i", "ј": "j", "к": "k", "л": "l",
    "љ": "l", "м": "m", "н": "n", "њ": "n", "о": "o", "п": "p", "р": "r",
    "с": "s", "т": "t", "ќ": "k", "у": "u", "ф": "f", "х": "h", "ц": "c",
    "ч": "c", "џ": "d", "ш": "s",
    # соседни азбуки, за секој случај
    "ђ": "d", "ћ": "c", "й": "j", "ы": "i", "э": "e", "ю": "u", "я": "a",
    "щ": "s", "ъ": "", "ь": "",
})

_DIGRAPHS = (("sh", "s"), ("ch", "c"), ("zh", "z"), ("gj", "g"), ("kj", "k"),
             ("lj", "l"), ("nj", "n"), ("dz", "z"), ("dj", "d"), ("ss", "s"))

_JUNK = re.compile(r"[^a-z0-9 ]+")


def fold(text) -> str:
    """Сведување на облик по кој се споредува (кирилица = латиница)."""
    result = str(text or "").casefold()
    result = result.translate(_CYR)
    for pair, single in _DIGRAPHS:
        result = result.replace(pair, single)
    result = _JUNK.sub(" ", result)
    return " ".join(result.split())


def matches(query, *targets) -> bool:
    """Дали сите зборови од барањето се наоѓаат во некое од полињата."""
    needle = fold(query)
    if not needle:
        return True
    haystack = " ".join(fold(t) for t in targets)
    return all(word in haystack for word in needle.split())
