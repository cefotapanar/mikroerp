# -*- coding: utf-8 -*-
"""Регистрација на примерокот.

MikroERP се дели бесплатно, но **нерегистриран примерок печати документи без
назив на фирмата и без лого**. Регистрацијата ги отклучува двете и му дава на
сопственикот увид кој ја користи апликацијата.

Тоа е сè што се разменува со серверот — **двa повика и ништо повеќе**. Нема
синхронизација, нема заедничка база, апликацијата не чита податоци од серверот.

Најважното правило: **проверката никогаш не смее да биде услов за работа.**
MikroERP мора да работи офлајн. Ако повикот не помине од која било причина, се
продолжува со последната позната состојба и се молчи. Заклучување има само на
јасен одговор `blocked` или `unknown`.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass
from datetime import date, datetime

from .logging_setup import log
from .repo import settings
from .version import VERSION

BASE = "https://unimer.krste.mk"
# Клучот на апликацијата НЕ е тајна — оди во .exe-то што се дели. Серверот со
# него не отвора ништо, само прима пријава.
APP_KEY = "338c2e24ff2d39dd754bea8e075bf6ac"
TIMEOUT = 15
PROVERKA_NA_DENOVI = 1

KEY_INSTALL = "reg_install_id"
KEY_LICENCA = "reg_licenca"
KEY_STATUS = "reg_status"
KEY_DATUM = "reg_datum"
KEY_PROVERKA = "reg_proverka"


class VrskaError(RuntimeError):
    """Серверот не е достапен — не е одговор, туку нема врска."""


@dataclass
class Rezultat:
    ok: bool
    status: str = ""
    message: str = ""
    company_name: str = ""


# ------------------------------------------------------------------ состојба
def install_id() -> str:
    """Белегот на оваа инсталација; се создава еднаш и живее во базата.

    Во базата, а не во config.ini, за да преживее ажурирање — `data\\` се
    изземa при копирањето на новите фајлови.
    """
    current = str(settings.get(KEY_INSTALL, "") or "").strip()
    if current:
        return current
    new_id = uuid.uuid4().hex
    settings.set(KEY_INSTALL, new_id)
    return new_id


def licenca() -> str:
    return str(settings.get(KEY_LICENCA, "") or "").strip()


def status() -> str:
    return str(settings.get(KEY_STATUS, "") or "").strip()


def aktivna() -> bool:
    """Единственото прашање што му го поставува остатокот од апликацијата."""
    return bool(licenca())


def datum() -> str:
    return str(settings.get(KEY_DATUM, "") or "").strip()


def zakluci(nov_status: str = "blocked") -> None:
    """Го брише лиценцниот клуч — називот и логото пак не се печатат."""
    settings.save_many({KEY_LICENCA: "", KEY_STATUS: nov_status})


def sostojba_tekst() -> str:
    """Кратка состојба за екранот Фирма."""
    if not aktivna():
        return "Не е регистрирана — називот и логото не се печатат."
    firma = str(settings.get("firma_naziv", "") or "").strip()
    parts = [x for x in (firma, licenca()) if x]
    tekst = "Регистрирана: " + " · ".join(parts)
    if datum():
        tekst += f"   (од {datum()})"
    return tekst


# ------------------------------------------------------------------- повици
def _post(path: str, payload: dict) -> tuple[int, dict]:
    """(HTTP код, тело). Крева `VrskaError` само кога нема врска."""
    request = urllib.request.Request(
        BASE + path,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={
            "X-MikroERP-Key": APP_KEY,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "MikroERP/" + VERSION,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
            raw = response.read()
            code = response.status
    except urllib.error.HTTPError as exc:
        # Телото носи објаснување — без него корисникот добива гола бројка.
        code = exc.code
        try:
            raw = exc.read()
        except Exception:      # noqa: BLE001
            raw = b""
    except (urllib.error.URLError, OSError) as exc:
        raise VrskaError(str(exc)) from exc

    try:
        data = json.loads(raw.decode("utf-8", "replace")) if raw else {}
    except ValueError:
        data = {}
    return code, (data if isinstance(data, dict) else {})


def podatoci() -> dict:
    """Она што се праќа — од ЗАЧУВАНИТЕ подесувања за фирмата."""
    values = settings.all()
    return {
        "install_id": install_id(),
        # ЕДБ-от оди како што е внесен; серверот сам го чисти.
        "tax_id": str(values.get("firma_edb") or values.get("ujp_edb") or "").strip(),
        "company_name": str(values.get("firma_naziv") or "").strip(),
        "email": str(values.get("firma_email") or "").strip(),
        "phone": str(values.get("firma_telefon") or "").strip(),
        "address": str(values.get("firma_adresa") or "").strip(),
        "city": str(values.get("firma_grad") or "").strip(),
        "contact_person": str(values.get("firma_direktor") or "").strip(),
        "app_version": VERSION,
    }


def nedostasuva(data: dict | None = None) -> str:
    """Што недостасува за да се праќа воопшто. Празно = сè е тука."""
    data = data or podatoci()
    if not data["tax_id"]:
        return "ЕДБ"
    if not data["company_name"]:
        return "Назив на фирмата"
    return ""


def registriraj(data: dict | None = None) -> Rezultat:
    """Го праќа повикот и ја запишува состојбата."""
    data = data or podatoci()
    missing = nedostasuva(data)
    if missing:
        return Rezultat(False, "error", f"Прво пополни го полето „{missing}“ "
                                        "во податоците за фирмата и зачувај.")

    code, body = _post("/mikroerp/registracija", data)
    server_status = str(body.get("status") or "").strip()
    message = str(body.get("message") or "").strip()
    # Во дневникот оди само дали поминало и кодот — никогаш клучеви.
    log.info("Регистрација: HTTP %s, состојба „%s“", code, server_status or "—")

    if code == 200 and server_status == "active":
        key = str(body.get("license_key") or "").strip()
        if not key:
            return Rezultat(False, "error",
                            "Серверот не врати лиценцен клуч. Обиди се повторно.")
        settings.save_many({
            KEY_LICENCA: key,
            KEY_STATUS: "active",
            KEY_DATUM: date.today().isoformat(),
            KEY_PROVERKA: datetime.now().isoformat(timespec="seconds"),
        })
        return Rezultat(True, "active",
                        "Примерокот е регистриран. Називот и логото веќе се "
                        "печатат на документите.",
                        str(body.get("company_name") or "").strip())

    if code == 200 and server_status == "blocked":
        zakluci()
        return Rezultat(False, "blocked",
                        message or "Фирмата е запрена. Јави се кај издавачот.")
    if code == 503:
        return Rezultat(False, "disabled",
                        message or "Регистрацијата моментално не е достапна. "
                                   "Обиди се подоцна.")
    if code == 403:
        return Rezultat(False, "error",
                        "Оваа верзија не може да се регистрира — симни ново "
                        "издание.")
    if code == 422:
        return Rezultat(False, "error", message or "Недостасува податок.")
    return Rezultat(False, "error",
                    message or f"Неочекуван одговор од серверот ({code}).")


# ------------------------------------------------------------ тивка проверка
def treba_proverka() -> bool:
    """Најмногу еднаш дневно, и само ако воопшто има што да се проверува."""
    if not aktivna():
        return False
    last = str(settings.get(KEY_PROVERKA, "") or "").strip()
    if not last:
        return True
    try:
        when = datetime.fromisoformat(last)
    except ValueError:
        return True
    return (datetime.now() - when).days >= PROVERKA_NA_DENOVI


def proveri_sega() -> Rezultat:
    """Проверка на барање на корисникот — оваа зборува, за разлика од `proveri`."""
    code, body = _post("/mikroerp/proverka", {
        "install_id": install_id(),
        "license_key": licenca(),
        "app_version": VERSION,
    })
    server_status = str(body.get("status") or "").strip()
    log.info("Проверка на регистрација (рачна): HTTP %s, состојба „%s“",
             code, server_status or "—")

    if code == 200 and server_status == "active":
        settings.set(KEY_PROVERKA, datetime.now().isoformat(timespec="seconds"))
        return Rezultat(True, "active", "Регистрацијата е во ред.",
                        str(body.get("company_name") or "").strip())
    if code == 200 and server_status in ("blocked", "unknown"):
        zakluci(server_status)
        return Rezultat(
            False, server_status,
            str(body.get("message") or "").strip()
            or ("Фирмата е запрена — називот и логото повеќе не се печатат."
                if server_status == "blocked"
                else "Серверот не ја познава оваа инсталација. "
                     "Регистрирај се повторно."))
    return Rezultat(False, "error",
                    str(body.get("message") or "").strip()
                    or f"Неочекуван одговор од серверот ({code}).")


def proveri() -> None:
    """Повремената проверка. НИКОГАШ не крева и никогаш не пречи.

    Заклучување има само на јасен одговор од серверот; при каква било грешка
    во врската состојбата останува како што била.
    """
    if not treba_proverka():
        return
    try:
        code, body = _post("/mikroerp/proverka", {
            "install_id": install_id(),
            "license_key": licenca(),
            "app_version": VERSION,
        })
    except VrskaError:
        return                     # нема интернет — не менувај ништо, молчи
    except Exception:              # noqa: BLE001 — проверката не смее да пречи
        return

    if code != 200:
        log.info("Проверка на регистрација: HTTP %s", code)
        return
    server_status = str(body.get("status") or "").strip()
    if server_status == "active":
        settings.set(KEY_PROVERKA, datetime.now().isoformat(timespec="seconds"))
    elif server_status in ("blocked", "unknown"):
        log.info("Проверка на регистрација: серверот врати „%s“", server_status)
        zakluci(server_status)
