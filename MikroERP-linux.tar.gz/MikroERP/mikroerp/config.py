# -*- coding: utf-8 -*-
"""Читање/запишување на config.ini.

Ако фајлот не постои — се креира со стандардни вредности.
Ако постои, но недостасуваат клучеви (нова верзија) — тие се додаваат,
без да се изгуби она што корисникот го поставил.
"""

from __future__ import annotations

import configparser
from pathlib import Path
from typing import Dict

from . import paths

# Стандардни вредности + коментари што се запишуваат во новиот config.ini
DEFAULTS: Dict[str, Dict[str, str]] = {
    "baza": {
        # Коса црта работи и на Windows и на Linux.
        "fajl": "data/mikroerp.db",
    },
    "izgled": {
        # windows = стандардна Windows тема (препорачано); може и: clam
        "tema": "windows",
        # празно / 0 = системски фонт и големина
        "font": "",
        "golemina_font": "0",
        "prozorec": "1280x780",
        # 1 = апликацијата се отвора на цел екран
        "polnekran": "1",
    },
    "backup": {
        "avtomatski": "1",
        "zadrzi_kopii": "15",
    },
    "app": {
        "naslov": "MikroERP",
        "decimali_kolicina": "3",
        "decimali_pari": "2",
    },
    "update": {
        # За во иднина — засега празно, ажурирањата се рачни.
        "izvor": "",
    },
}

HEADER = """; ============================================================
;  MikroERP — конфигурација
;  Овој фајл се чита при стартување на апликацијата.
;  Релативните патеки се однесуваат на папката со MikroERP.exe
; ============================================================
"""


class Config:
    def __init__(self, file: Path | None = None) -> None:
        self.file = Path(file) if file else paths.CONFIG_FILE
        self._cp = configparser.ConfigParser()
        self.load()

    # ------------------------------------------------------------ load/save
    def load(self) -> None:
        if self.file.exists():
            try:
                self._cp.read(self.file, encoding="utf-8")
            except (configparser.Error, UnicodeDecodeError):
                # Оштетен config.ini не смее да ја сруши апликацијата.
                self._cp = configparser.ConfigParser()
        changed = False
        for section, values in DEFAULTS.items():
            if not self._cp.has_section(section):
                self._cp.add_section(section)
                changed = True
            for key, value in values.items():
                if not self._cp.has_option(section, key):
                    self._cp.set(section, key, value)
                    changed = True
        if changed:
            self.save()

    def save(self) -> None:
        self.file.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.file.with_suffix(".ini.tmp")
        with open(tmp, "w", encoding="utf-8") as fh:
            if not self.file.exists():
                fh.write(HEADER)
            self._cp.write(fh)
        tmp.replace(self.file)

    # --------------------------------------------------------------- getters
    def get(self, section: str, key: str, fallback: str = "") -> str:
        try:
            return self._cp.get(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return DEFAULTS.get(section, {}).get(key, fallback)

    def get_int(self, section: str, key: str, fallback: int = 0) -> int:
        try:
            return int(str(self.get(section, key)).strip())
        except (TypeError, ValueError):
            return fallback

    def get_bool(self, section: str, key: str, fallback: bool = False) -> bool:
        value = str(self.get(section, key)).strip().lower()
        if value in ("1", "true", "da", "да", "yes", "on"):
            return True
        if value in ("0", "false", "ne", "не", "no", "off"):
            return False
        return fallback

    def set(self, section: str, key: str, value) -> None:
        if not self._cp.has_section(section):
            self._cp.add_section(section)
        self._cp.set(section, key, str(value))

    # --------------------------------------------------------------- изведени
    @property
    def db_path(self) -> Path:
        return paths.resolve(self.get("baza", "fajl"))


_config: Config | None = None


def config() -> Config:
    """Единствена (singleton) инстанца на конфигурацијата."""
    global _config
    if _config is None:
        _config = Config()
    return _config
