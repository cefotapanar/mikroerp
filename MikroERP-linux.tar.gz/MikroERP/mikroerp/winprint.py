# -*- coding: utf-8 -*-
"""Печатење директно на печатач (Windows, GDI преку ctypes).

Истите примитиви во милиметри што ги црта прегледот се цртаат и овде, само
претворени во точки на печатачот. Значи нема прелистувач во патот на
печатењето — се отвора обичниот Windows дијалог за избор на печатач.

Ако нешто не е достапно (друг систем, стар драјвер), се крева `PrintError` и
повикувачот нуди PDF како резервен пат.
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes

from . import doclayout

WINDOWS = sys.platform == "win32"


class PrintError(RuntimeError):
    pass


if WINDOWS:
    gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
    comdlg32 = ctypes.WinDLL("comdlg32", use_last_error=True)

    class DOCINFOW(ctypes.Structure):
        _fields_ = [
            ("cbSize", ctypes.c_int),
            ("lpszDocName", wintypes.LPCWSTR),
            ("lpszOutput", wintypes.LPCWSTR),
            ("lpszDatatype", wintypes.LPCWSTR),
            ("fwType", wintypes.DWORD),
        ]

    class PRINTDLGW(ctypes.Structure):
        _fields_ = [
            ("lStructSize", wintypes.DWORD),
            ("hwndOwner", wintypes.HWND),
            ("hDevMode", wintypes.HGLOBAL),
            ("hDevNames", wintypes.HGLOBAL),
            ("hDC", wintypes.HDC),
            ("Flags", wintypes.DWORD),
            ("nFromPage", wintypes.WORD),
            ("nToPage", wintypes.WORD),
            ("nMinPage", wintypes.WORD),
            ("nMaxPage", wintypes.WORD),
            ("nCopies", wintypes.WORD),
            ("hInstance", wintypes.HINSTANCE),
            ("lCustData", wintypes.LPARAM),
            ("lpfnPrintHook", ctypes.c_void_p),
            ("lpfnSetupHook", ctypes.c_void_p),
            ("lpPrintTemplateName", wintypes.LPCWSTR),
            ("lpSetupTemplateName", wintypes.LPCWSTR),
            ("hPrintTemplate", wintypes.HGLOBAL),
            ("hSetupTemplate", wintypes.HGLOBAL),
        ]

    class LOGFONTW(ctypes.Structure):
        _fields_ = [
            ("lfHeight", wintypes.LONG), ("lfWidth", wintypes.LONG),
            ("lfEscapement", wintypes.LONG), ("lfOrientation", wintypes.LONG),
            ("lfWeight", wintypes.LONG), ("lfItalic", wintypes.BYTE),
            ("lfUnderline", wintypes.BYTE), ("lfStrikeOut", wintypes.BYTE),
            ("lfCharSet", wintypes.BYTE), ("lfOutPrecision", wintypes.BYTE),
            ("lfClipPrecision", wintypes.BYTE), ("lfQuality", wintypes.BYTE),
            ("lfPitchAndFamily", wintypes.BYTE), ("lfFaceName", ctypes.c_wchar * 32),
        ]

    PD_RETURNDC = 0x00000100
    PD_NOPAGENUMS = 0x00000008
    PD_NOSELECTION = 0x00000004
    PD_USEDEVMODECOPIESANDCOLLATE = 0x00040000
    LOGPIXELSX, LOGPIXELSY = 88, 90
    PHYSICALOFFSETX, PHYSICALOFFSETY = 112, 113
    TA_LEFT, TA_RIGHT, TA_CENTER, TA_TOP = 0, 2, 6, 0
    FW_NORMAL, FW_BOLD = 400, 700
    TRANSPARENT = 1
    PS_SOLID = 0


# ------------------------------------------------------------------- слики
def png_bgra(path) -> tuple[int, int, bytes] | None:
    """PNG → (ширина, висина, пиксели BGRA), без надворешна библиотека.

    Печатачот бара суровa слика; Tk не ја дава како бајти, па PNG-то се
    отпакува тука. Провидноста се спојува со бело, зашто печатачите не се
    снаоѓаат со алфа. Ако форматот е необичен (16 бита, преплетен) → None,
    и логото едноставно не се печати наместо да падне печатењето.
    """
    import struct
    import zlib

    try:
        data = open(path, "rb").read()
    except OSError:
        return None
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        return None

    pos = 8
    width = height = depth = color_type = interlace = 0
    idat = bytearray()
    palette = b""
    trans = b""
    while pos + 8 <= len(data):
        length, tag = struct.unpack(">I4s", data[pos:pos + 8])
        chunk = data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if tag == b"IHDR":
            (width, height, depth, color_type, _comp, _filt,
             interlace) = struct.unpack(">IIBBBBB", chunk)
        elif tag == b"PLTE":
            palette = chunk
        elif tag == b"tRNS":
            trans = chunk
        elif tag == b"IDAT":
            idat += chunk
        elif tag == b"IEND":
            break
    if not width or depth != 8 or interlace != 0:
        return None
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(color_type)
    if channels is None:
        return None

    try:
        raw = zlib.decompress(bytes(idat))
    except zlib.error:
        return None

    stride = width * channels
    out = bytearray(width * height * 4)
    previous = bytearray(stride)
    offset = 0
    for row in range(height):
        if offset >= len(raw):
            return None
        filter_type = raw[offset]
        offset += 1
        line = bytearray(raw[offset:offset + stride])
        offset += stride
        if len(line) < stride:
            return None
        for i in range(stride):
            a = line[i - channels] if i >= channels else 0
            b = previous[i]
            c = previous[i - channels] if i >= channels else 0
            value = line[i]
            if filter_type == 1:
                value += a
            elif filter_type == 2:
                value += b
            elif filter_type == 3:
                value += (a + b) >> 1
            elif filter_type == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                value += a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
            line[i] = value & 0xFF
        previous = line

        base = row * width * 4
        for x in range(width):
            alpha = 255
            if color_type == 2:
                r, g, b = line[x * 3:x * 3 + 3]
            elif color_type == 6:
                r, g, b, alpha = line[x * 4:x * 4 + 4]
            elif color_type == 0:
                r = g = b = line[x]
            elif color_type == 4:
                r = g = b = line[x * 2]
                alpha = line[x * 2 + 1]
            else:                                   # палета
                entries = len(palette) // 3
                if not entries:
                    return None
                index = min(line[x], entries - 1)
                r, g, b = palette[index * 3:index * 3 + 3]
                if index < len(trans):
                    alpha = trans[index]
            if alpha != 255:                        # врз бело
                r = (r * alpha + 255 * (255 - alpha)) // 255
                g = (g * alpha + 255 * (255 - alpha)) // 255
                b = (b * alpha + 255 * (255 - alpha)) // 255
            cell = base + x * 4
            out[cell] = b
            out[cell + 1] = g
            out[cell + 2] = r
            out[cell + 3] = 255
    return width, height, bytes(out)


def convert_to_png(source, target) -> bool:
    """Која било слика (JPG, BMP, TIFF…) → PNG, преку GDI+ на Windows.

    Логото мора да е PNG за да го гледаат и прегледот и печатачот; корисникот
    обично има JPG. Наместо да го одбиваме, го претвораме еднаш при внесот.
    """
    if not WINDOWS:
        return False

    class GdiplusStartupInput(ctypes.Structure):
        _fields_ = [("GdiplusVersion", ctypes.c_uint32),
                    ("DebugEventCallback", ctypes.c_void_p),
                    ("SuppressBackgroundThread", wintypes.BOOL),
                    ("SuppressExternalCodecs", wintypes.BOOL)]

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                    ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]

    try:
        gdiplus = ctypes.WinDLL("gdiplus")
    except OSError:
        return False

    # CLSID на вградениот PNG-кодер (стандарден за GDI+)
    png_encoder = GUID(0x557CF406, 0x1A04, 0x11D3,
                       (0x9A, 0x73, 0x00, 0x00, 0xF8, 0x1E, 0xF3, 0x2E))
    token = ctypes.c_void_p()
    startup = GdiplusStartupInput(1, None, False, False)
    gdiplus.GdiplusStartup.argtypes = [ctypes.POINTER(ctypes.c_void_p),
                                       ctypes.POINTER(GdiplusStartupInput),
                                       ctypes.c_void_p]
    if gdiplus.GdiplusStartup(ctypes.byref(token), ctypes.byref(startup), None) != 0:
        return False
    image = ctypes.c_void_p()
    try:
        gdiplus.GdipLoadImageFromFile.argtypes = [wintypes.LPCWSTR,
                                                  ctypes.POINTER(ctypes.c_void_p)]
        if gdiplus.GdipLoadImageFromFile(str(source), ctypes.byref(image)) != 0:
            return False
        gdiplus.GdipSaveImageToFile.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR,
                                                ctypes.POINTER(GUID), ctypes.c_void_p]
        status = gdiplus.GdipSaveImageToFile(image, str(target),
                                             ctypes.byref(png_encoder), None)
        return status == 0
    finally:
        if image:
            gdiplus.GdipDisposeImage.argtypes = [ctypes.c_void_p]
            gdiplus.GdipDisposeImage(image)
        gdiplus.GdiplusShutdown.argtypes = [ctypes.c_void_p]
        gdiplus.GdiplusShutdown(token)


if WINDOWS:
    class BITMAPINFOHEADER(ctypes.Structure):
        _fields_ = [
            ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG),
            ("biHeight", wintypes.LONG), ("biPlanes", wintypes.WORD),
            ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
            ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG),
            ("biYPelsPerMeter", wintypes.LONG), ("biClrUsed", wintypes.DWORD),
            ("biClrImportant", wintypes.DWORD),
        ]

    BI_RGB, DIB_RGB_COLORS, SRCCOPY, HALFTONE = 0, 0, 0x00CC0020, 4

    # Функциите што враќаат ХЕНДЛ мора да имаат restype на покажувач — инаку
    # на 64-битен Windows вредноста се сече на 32 бита и цртањето „исчезнува“.
    _HANDLE = ctypes.c_void_p
    for _name in ("CreateFontIndirectW", "CreatePen", "CreateSolidBrush",
                  "SelectObject", "CreateCompatibleDC", "CreateCompatibleBitmap",
                  "CreateDCW"):
        getattr(gdi32, _name).restype = _HANDLE
    gdi32.SelectObject.argtypes = [_HANDLE, _HANDLE]
    gdi32.DeleteObject.argtypes = [_HANDLE]
    gdi32.DeleteDC.argtypes = [_HANDLE]
    gdi32.TextOutW.argtypes = [_HANDLE, ctypes.c_int, ctypes.c_int,
                               wintypes.LPCWSTR, ctypes.c_int]
    gdi32.GetTextExtentPoint32W.argtypes = [_HANDLE, wintypes.LPCWSTR, ctypes.c_int,
                                            ctypes.POINTER(wintypes.SIZE)]
    # Првиот аргумент секаде е ХЕНДЛ (64-битен) — без ова ctypes го сече на int.
    for _name in ("SetBkMode", "SetTextAlign", "SetStretchBltMode"):
        getattr(gdi32, _name).argtypes = [_HANDLE, ctypes.c_int]
    for _name in ("StartPage", "EndPage", "EndDoc"):
        getattr(gdi32, _name).argtypes = [_HANDLE]
    gdi32.CreateCompatibleDC.argtypes = [_HANDLE]
    gdi32.CreateCompatibleBitmap.argtypes = [_HANDLE, ctypes.c_int, ctypes.c_int]
    gdi32.CreateDCW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR,
                                wintypes.LPCWSTR, ctypes.c_void_p]
    gdi32.GetPixel.argtypes = [_HANDLE, ctypes.c_int, ctypes.c_int]
    gdi32.MoveToEx.argtypes = [_HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    gdi32.LineTo.argtypes = [_HANDLE, ctypes.c_int, ctypes.c_int]
    gdi32.SetTextColor.argtypes = [_HANDLE, wintypes.DWORD]
    gdi32.GetDeviceCaps.argtypes = [_HANDLE, ctypes.c_int]
    gdi32.StretchDIBits.argtypes = [
        _HANDLE, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, wintypes.DWORD]
    gdi32.StartDocW.argtypes = [_HANDLE, ctypes.c_void_p]


def _rgb(color: str) -> int:
    color = (color or "#000000").lstrip("#")
    r, g, b = int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)
    return r | (g << 8) | (b << 16)


class _Device:
    """Печатачот како платно во милиметри."""

    def __init__(self, hdc):
        self.hdc = hdc
        self.dpi_x = gdi32.GetDeviceCaps(hdc, LOGPIXELSX) or 300
        self.dpi_y = gdi32.GetDeviceCaps(hdc, LOGPIXELSY) or 300
        # Печатачот не може да печати до самиот раб — цртањето се поместува
        # за неотпечатливиот раб, за да не се исече лево и горе.
        self.off_x = gdi32.GetDeviceCaps(hdc, PHYSICALOFFSETX)
        self.off_y = gdi32.GetDeviceCaps(hdc, PHYSICALOFFSETY)
        self._fonts: dict = {}
        self._pens: dict = {}

    def x(self, mm: float) -> int:
        return int(round(mm * self.dpi_x / 25.4)) - self.off_x

    def y(self, mm: float) -> int:
        return int(round(mm * self.dpi_y / 25.4)) - self.off_y

    def font(self, style: str):
        if style not in self._fonts:
            size, bold, _color = doclayout.STYLES[style]
            logfont = LOGFONTW()
            logfont.lfHeight = -int(round(size * self.dpi_y / 72.0))
            logfont.lfWeight = FW_BOLD if bold else FW_NORMAL
            logfont.lfCharSet = 1                      # DEFAULT_CHARSET
            logfont.lfQuality = 5                      # CLEARTYPE_QUALITY
            logfont.lfFaceName = "Segoe UI"
            self._fonts[style] = gdi32.CreateFontIndirectW(ctypes.byref(logfont))
        return self._fonts[style]

    def pen(self, color: str, width_mm: float):
        key = (color, round(width_mm, 3))
        if key not in self._pens:
            width = max(1, int(round(width_mm * self.dpi_x / 25.4)))
            self._pens[key] = gdi32.CreatePen(PS_SOLID, width, _rgb(color))
        return self._pens[key]

    def text_width(self, text: str, style: str) -> int:
        size = wintypes.SIZE()
        gdi32.SelectObject(self.hdc, self.font(style))
        gdi32.GetTextExtentPoint32W(self.hdc, text, len(text), ctypes.byref(size))
        return size.cx

    def cleanup(self) -> None:
        for handle in list(self._fonts.values()) + list(self._pens.values()):
            gdi32.DeleteObject(handle)
        self._fonts.clear()
        self._pens.clear()


def _draw_page(dev: _Device, primitives) -> None:
    gdi32.SetBkMode(dev.hdc, TRANSPARENT)
    for item in primitives:
        kind = item[0]
        if kind == "text":
            _, x, y, text, style, width, align = item
            size, _bold, color = doclayout.STYLES[style]
            gdi32.SelectObject(dev.hdc, dev.font(style))
            gdi32.SetTextColor(dev.hdc, _rgb(color))
            px, py = dev.x(x), dev.y(y)
            if width and align == "r":
                gdi32.SetTextAlign(dev.hdc, TA_RIGHT | TA_TOP)
                px = dev.x(x + width)
            elif width and align == "c":
                gdi32.SetTextAlign(dev.hdc, TA_CENTER | TA_TOP)
                px = dev.x(x + width / 2)
            else:
                gdi32.SetTextAlign(dev.hdc, TA_LEFT | TA_TOP)
            text = str(text)
            gdi32.TextOutW(dev.hdc, px, py, text, len(text))
        elif kind == "line":
            _, x1, y1, x2, y2, width, color = item
            gdi32.SelectObject(dev.hdc, dev.pen(color, width))
            gdi32.MoveToEx(dev.hdc, dev.x(x1), dev.y(y1), None)
            gdi32.LineTo(dev.hdc, dev.x(x2), dev.y(y2))
        elif kind == "rect":
            _, x, y, w, h, fill, outline, width = item
            left, top, right, bottom = dev.x(x), dev.y(y), dev.x(x + w), dev.y(y + h)
            if fill:
                brush = gdi32.CreateSolidBrush(_rgb(fill))
                rect = wintypes.RECT(left, top, right, bottom)
                user32 = ctypes.WinDLL("user32")
                user32.FillRect.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                            ctypes.c_void_p]
                user32.FillRect(dev.hdc, ctypes.byref(rect), brush)
                gdi32.DeleteObject(brush)
            if outline:
                gdi32.SelectObject(dev.hdc, dev.pen(outline, width))
                gdi32.MoveToEx(dev.hdc, left, top, None)
                for point in ((right, top), (right, bottom), (left, bottom),
                              (left, top)):
                    gdi32.LineTo(dev.hdc, *point)
        elif kind == "image":
            _, x, y, w, h, path = item
            _draw_image(dev, x, y, w, h, path)


def _draw_image(dev: "_Device", x, y, w, h, path) -> None:
    """Логото на хартија. Ако сликата не се чита — се прескокнува тивко."""
    decoded = png_bgra(path)
    if decoded is None:
        return
    width, height, pixels = decoded
    # се задржува односот на страните во дозволената рамка
    scale = min(w / max(width, 1), h / max(height, 1))
    draw_w = max(1, int(round(width * scale * dev.dpi_x / 25.4)))
    draw_h = max(1, int(round(height * scale * dev.dpi_y / 25.4)))

    header = BITMAPINFOHEADER()
    header.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    header.biWidth = width
    header.biHeight = -height              # одозгора надолу
    header.biPlanes = 1
    header.biBitCount = 32
    header.biCompression = BI_RGB
    buffer = ctypes.create_string_buffer(pixels, len(pixels))
    gdi32.SetStretchBltMode(dev.hdc, HALFTONE)
    gdi32.StretchDIBits(dev.hdc, dev.x(x), dev.y(y), draw_w, draw_h,
                        0, 0, width, height, buffer, ctypes.byref(header),
                        DIB_RGB_COLORS, SRCCOPY)


def draw_to_dc(hdc, pages, page_index: int = 0) -> None:
    """Цртање на веќе постоечки DC — за проверка без печатач."""
    dev = _Device(hdc)
    try:
        _draw_page(dev, pages[page_index])
    finally:
        dev.cleanup()


def print_pages(pages, doc_name: str = "MikroERP документ", hwnd: int = 0) -> bool:
    """Го отвора дијалогот за печатач и печати. Враќа False ако е откажано."""
    if not WINDOWS:
        raise PrintError("Директното печатење работи само на Windows.")

    dialog = PRINTDLGW()
    dialog.lStructSize = ctypes.sizeof(PRINTDLGW)
    dialog.hwndOwner = hwnd or 0
    dialog.Flags = (PD_RETURNDC | PD_NOPAGENUMS | PD_NOSELECTION
                    | PD_USEDEVMODECOPIESANDCOLLATE)
    dialog.nCopies = 1
    if not comdlg32.PrintDlgW(ctypes.byref(dialog)):
        return False                       # корисникот кликнал Откажи
    if not dialog.hDC:
        raise PrintError("Печатачот не врати површина за печатење.")

    dev = _Device(dialog.hDC)
    info = DOCINFOW()
    info.cbSize = ctypes.sizeof(DOCINFOW)
    info.lpszDocName = doc_name
    try:
        if gdi32.StartDocW(dev.hdc, ctypes.byref(info)) <= 0:
            raise PrintError("Печатењето не почна (StartDoc).")
        for primitives in pages:
            gdi32.StartPage(dev.hdc)
            _draw_page(dev, primitives)
            gdi32.EndPage(dev.hdc)
        gdi32.EndDoc(dev.hdc)
    finally:
        dev.cleanup()
        gdi32.DeleteDC(dev.hdc)
        for handle in (dialog.hDevMode, dialog.hDevNames):
            if handle:
                ctypes.WinDLL("kernel32").GlobalFree(handle)
    return True
