# -*- coding: utf-8 -*-
"""Документите како хартија.

Тука документот се претвора во `Doc` — опис на она што треба да стои на
хартијата. Од тој ист опис потоа:

  * `doclayout.paginate` прави страници за **прегледот и печатачот**;
  * `paper.document_html` прави HTML за **PDF**.

Значи изгледот се менува на едно место, а не во шест екрани.
"""

from __future__ import annotations

from .doclayout import Doc
from .money import D, fmt, fmt_qty, q2
from .repo import issues, partners, purchases, receipts, sales, warehouses, workorders
from .util import fmt_date

# вид → (наслов, репо, како се вика другата страна)
KINDS = {
    "faktura": ("Фактура", sales, "Купувач"),
    "profaktura": ("Профактура", sales, "Купувач"),
    "ispratnica": ("Испратница", issues, "Примач"),
    "priemnica": ("Приемница", receipts, "Добавувач"),
    "vlezna_faktura": ("Влезна фактура", purchases, "Добавувач"),
    "raboten_nalog": ("Работен налог", workorders, "Магацин"),
}

LINE_COLUMNS = [
    {"key": "no", "text": "Р.бр", "align": "c"},
    {"key": "code", "text": "Шифра", "align": "l"},
    {"key": "name", "text": "Назив", "align": "l", "wide": True},
    {"key": "unit", "text": "ЕМ", "align": "c"},
    {"key": "qty", "text": "Количина", "align": "r"},
    {"key": "price", "text": "Цена", "align": "r"},
    {"key": "discount", "text": "Рабат %", "align": "r"},
    {"key": "net", "text": "Износ", "align": "r"},
    {"key": "tax_rate", "text": "ДДВ %", "align": "r"},
    {"key": "vat", "text": "ДДВ", "align": "r"},
    {"key": "gross", "text": "Вкупно", "align": "r"},
]


class UnknownDocument(ValueError):
    pass


def _value(record, key):
    try:
        return record[key]
    except (KeyError, IndexError):
        return None


def _record(kind: str, rec_id: int):
    title, repo, party_label = KINDS[kind]
    record = repo.get(rec_id)
    if record is None:
        raise UnknownDocument("Документот не постои.")
    return title, repo, party_label, record


def _party(record) -> tuple[str, list[str]]:
    partner_id = _value(record, "partner_id")
    if not partner_id:
        return "", []
    row = partners.get(int(partner_id))
    if row is None:
        return "", []
    full = bool(_value(record, "use_full_name"))
    name = (row["full_name"] or row["name"]) if full else row["name"]
    lines = [x for x in (row["address"] or "",
                         " ".join(y for y in (row["city"] or "", row["country"] or "")
                                  if y).strip()) if x]
    ids = " · ".join(x for x in (f"ЕДБ {row['tax_number']}" if row["tax_number"] else "",
                                 f"ЕМБС {row['reg_number']}" if row["reg_number"] else "")
                     if x)
    if ids:
        lines.append(ids)
    if row["phone"]:
        lines.append(row["phone"])
    return name, lines


def _lines(repo, rec_id: int) -> tuple[list[dict], tuple]:
    rows = []
    net = vat = gross = D(0)
    for index, line in enumerate(repo.lines(rec_id), start=1):
        line_net, line_vat = q2(line["net"]), q2(line["vat"])
        line_gross = q2(line["gross"])
        net += line_net
        vat += line_vat
        gross += line_gross
        rows.append({
            "no": str(index),
            "code": line["item_code"],
            "name": line["item_name"],
            "unit": line["item_unit"],
            "qty": fmt_qty(line["qty"]),
            "price": fmt(line["price"]),
            "discount": fmt(line["discount"], 0) if D(line["discount"] or 0) else "",
            "net": fmt(line_net),
            "tax_rate": fmt(line["tax_rate"], 0),
            "vat": fmt(line_vat),
            "gross": fmt(line_gross),
        })
    return rows, (q2(net), q2(vat), q2(gross))


def _meta(kind: str, record) -> list[tuple]:
    meta = [("Датум", fmt_date(record["date"]))]
    if _value(record, "due_date"):
        meta.append(("Валута (рок)", fmt_date(record["due_date"])))
    if kind in ("faktura", "profaktura") and _value(record, "issue_no"):
        meta.append(("По испратница", record["issue_no"]))
    if kind in ("priemnica", "vlezna_faktura") and _value(record, "supplier_no"):
        meta.append(("Документ на добавувачот", record["supplier_no"]))
    warehouse_id = _value(record, "warehouse_id")
    if warehouse_id and len(warehouses.list_all()) > 1:
        row = warehouses.get(int(warehouse_id))
        if row is not None:
            meta.append(("Магацин", row["name"]))
    return meta


# ---------------------------------------------------------------- документ
def build(kind: str, rec_id: int) -> Doc:
    """Го подготвува документот за хартија."""
    if kind not in KINDS:
        raise UnknownDocument(f"Непознат вид документ: {kind}")
    if kind == "raboten_nalog":
        return _workorder_doc(rec_id)

    title, repo, party_label, record = _record(kind, rec_id)
    rows, (net, vat, gross) = _lines(repo, rec_id)
    name, party_lines = _party(record)

    doc = Doc(
        title=title,
        doc_no="бр. " + str(record["doc_no"]),
        file_name=f"{title}-{record['doc_no']}",
        meta=_meta(kind, record),
        party_label=party_label if name else "",
        party_name=name,
        party=party_lines,
        columns=LINE_COLUMNS,
        rows=rows,
        totals=[("Основица", fmt(net), False),
                ("ДДВ", fmt(vat), False),
                ("Вкупно за плаќање (ден.)", fmt(gross), True)],
        note=("Забелешка: " + record["note"]) if _value(record, "note") else "",
        signs=["Изготвил", "М.П.", "Примил"],
    )

    if kind in ("faktura", "profaktura"):
        doc.payment_note = payment_note(record["doc_no"])
    return doc


def payment_note(doc_no: str) -> str:
    """Сите сметки означени за печатење одат на документот."""
    from .paper import company
    from .repo import bank_accounts

    rows = bank_accounts.for_invoice()
    if rows:
        accounts = "; ".join(
            f"{row['account_no']}" + (f" — {row['bank_name']}" if row["bank_name"]
                                      else "")
            for row in rows)
        many = "сметките" if len(rows) > 1 else "сметка"
        return (f"Плаќањето се врши на {many}: {accounts}, "
                f"со повикување на број {doc_no}.")
    firm = company()
    if not firm["smetka"]:
        return ""
    return (f"Плаќањето се врши на сметка {firm['smetka']}"
            + (f" — {firm['banka']}" if firm["banka"] else "")
            + f", со повикување на број {doc_no}.")


def _workorder_doc(rec_id: int) -> Doc:
    record = workorders.get(rec_id)
    if record is None:
        raise UnknownDocument("Работниот налог не постои.")
    rows = []
    total = D(0)
    for index, line in enumerate(workorders.lines(rec_id), start=1):
        value = q2(line["cost"] if "cost" in line.keys() else 0)
        qty = D(line["qty"] or 0)
        total += value
        rows.append({
            "no": str(index), "code": line["item_code"], "name": line["item_name"],
            "unit": line["item_unit"], "qty": fmt_qty(qty),
            "price": fmt(value / qty if qty else 0), "net": fmt(value),
        })
    columns = []
    for col in LINE_COLUMNS:
        if col["key"] not in ("no", "code", "name", "unit", "qty", "price", "net"):
            continue
        text = {"price": "Цена на чинење", "net": "Вредност"}.get(col["key"],
                                                                  col["text"])
        columns.append(dict(col, text=text))

    product = ""
    if record["item_id"]:
        from .repo import items
        row = items.get(int(record["item_id"]))
        if row is not None:
            product = f'{row["code"]} — {row["name"]}'
    qty = D(record["qty"] or 0)

    return Doc(
        title="Работен налог",
        doc_no="бр. " + str(record["doc_no"]),
        file_name=f"Rabotenalog-{record['doc_no']}",
        meta=[("Датум", fmt_date(record["date"])), ("Состојба", record["status"])],
        party_label="Производ", party_name=product,
        party=[f"Количина: {fmt_qty(qty)}"],
        columns=columns, rows=rows,
        totals=[("Вредност на материјалите", fmt(total), False),
                ("Цена на чинење по единица", fmt(q2(total / qty) if qty else 0), True)],
        note=("Забелешка: " + record["note"]) if record["note"] else "",
        signs=["Издал", "М.П.", "Изработил"],
    )


def list_doc(title: str, columns, rows: list[dict], info: list[str] | None = None,
             totals: list[tuple] | None = None) -> Doc:
    """Извештај/листа како хартија — истите колони што се на екранот."""
    spec = []
    for col in columns:
        anchor = col.get("anchor", "")
        spec.append({
            "key": col["key"],
            "text": col.get("text", col["key"]),
            "align": "r" if anchor == "e" else ("c" if anchor == "center" else "l"),
            "wide": bool(col.get("stretch")),
        })
    return Doc(
        title=title, doc_no="", file_name=title,
        info=list(info or []),
        columns=spec,
        rows=[{c["key"]: str(row.get(c["key"], "")) for c in spec} for row in rows],
        totals=list(totals or []),
    )


# ---------------------------------------------------- текст (порака/е-пошта)
def document_text(kind: str, rec_id: int, max_lines: int = 15) -> str:
    """Документот како кратка порака — за копирање во порака или е-пошта."""
    if kind not in KINDS:
        raise UnknownDocument(f"Непознат вид документ: {kind}")
    from .paper import company

    title, repo, _label, record = _record(kind, rec_id)
    firm = company()
    out = [f"{title} бр. {record['doc_no']}"]
    if firm["naziv"]:
        out.append(firm["naziv"])
    out.append("Датум: " + fmt_date(record["date"]))
    name, _lines_ = _party(record)
    if name:
        out.append("За: " + name)
    out.append("")

    rows, totals = ([], (D(0), D(0), D(0))) if kind == "raboten_nalog" \
        else _lines(repo, rec_id)
    for row in rows[:max_lines]:
        rabat = f" −{row['discount']}%" if row["discount"] else ""
        out.append(f"• {row['name']}  {row['qty']} × {row['price']}{rabat} "
                   f"= {row['gross']}")
    if len(rows) > max_lines:
        out.append(f"… и уште {len(rows) - max_lines} ставки")

    out.append("")
    out.append(f"Вкупно со ДДВ: {fmt(totals[2])} ден.")
    if _value(record, "due_date"):
        out.append("Рок на плаќање: " + fmt_date(record["due_date"]))
    if kind in ("faktura", "profaktura"):
        from .repo import bank_accounts
        rows = bank_accounts.for_invoice()
        if rows:
            for row in rows:
                out.append(f"Сметка: {row['account_no']}"
                           + (f" ({row['bank_name']})" if row["bank_name"] else ""))
        elif firm["smetka"]:
            out.append(f"Сметка: {firm['smetka']}"
                       + (f" ({firm['banka']})" if firm["banka"] else ""))
    contact = " · ".join(x for x in (firm["telefon"], firm["email"]) if x)
    if contact:
        out.append(contact)
    return "\n".join(out)


def document_html(kind: str, rec_id: int) -> tuple[str, str]:
    """(HTML, име на датотека) — за PDF."""
    from . import paper
    doc = build(kind, rec_id)
    return paper.document_html(doc), doc.file_name
