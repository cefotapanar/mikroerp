# -*- coding: utf-8 -*-
"""Слој над SQLite.

Дизајн-одлуки:
  * WAL журнал — побрзо и поотпорно на прекини (нема оштетена база при пад на струја).
  * foreign_keys=ON — базата сама ги чува врските.
  * Автоматски резервни копии при стартување (се чуваат последните N).
  * Сите промени одат преку `tx()` — или сè поминува, или ништо.
"""

from __future__ import annotations

import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Sequence

from .logging_setup import log
from . import paths


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._tx_depth = 0
        paths.ensure_dir(self.path.parent)
        self.conn = sqlite3.connect(
            self.path,
            detect_types=sqlite3.PARSE_DECLTYPES,
            isolation_level=None,          # рачно управување со трансакции
            check_same_thread=False,
        )
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA busy_timeout = 5000")
        self.conn.execute("PRAGMA synchronous = FULL")
        self._add_functions()
        log.info("Отворена база: %s", self.path)

    def _add_functions(self) -> None:
        """Барањето во листите да е како во избирачите: без разлика на голема/
        мала буква и без разлика дали е пишувано кирилица или латиница.

        `LIKE` во SQLite не ги знае кириличните големи букви, ниту дека „ш“ и
        „sh“ се исто — затоа споредбата ја прави Python (`util.matches`) преку
        оваа функција.
        """
        from .util import matches

        def mk_match(haystack, needle) -> int:
            return 1 if matches(needle, haystack or "") else 0

        self.conn.create_function("mkmatch", 2, mk_match, deterministic=True)

    # ------------------------------------------------------------- прашалници
    def query(self, sql: str, params: Sequence[Any] | dict = ()) -> list[sqlite3.Row]:
        return self.conn.execute(sql, params).fetchall()

    def one(self, sql: str, params: Sequence[Any] | dict = ()) -> sqlite3.Row | None:
        return self.conn.execute(sql, params).fetchone()

    def scalar(self, sql: str, params: Sequence[Any] | dict = (), default=None):
        row = self.one(sql, params)
        return row[0] if row is not None else default

    def execute(self, sql: str, params: Sequence[Any] | dict = ()) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def executemany(self, sql: str, seq: Iterable[Sequence[Any]]) -> sqlite3.Cursor:
        return self.conn.executemany(sql, seq)

    def executescript(self, sql: str) -> None:
        self.conn.executescript(sql)

    # ----------------------------------------------------------- трансакции
    @contextmanager
    def tx(self):
        """`with db.tx():` — при грешка сè се враќа назад.

        Смее да се вгнездува: внатрешниот `tx()` се придружува на веќе
        отворената трансакција (SQLite нема вистински вгнездени трансакции).
        Грешка кај внатрешниот повик ја враќа целата надворешна трансакција.
        """
        if self._tx_depth:
            self._tx_depth += 1
            try:
                yield self
            finally:
                self._tx_depth -= 1
            return

        self.conn.execute("BEGIN")
        self._tx_depth = 1
        try:
            yield self
        except Exception:
            self._tx_depth = 0
            self.conn.execute("ROLLBACK")
            raise
        else:
            self._tx_depth = 0
            self.conn.execute("COMMIT")

    # -------------------------------------------------------------- помошни
    def insert(self, table: str, data: dict) -> int:
        cols = ", ".join(data.keys())
        marks = ", ".join(f":{k}" for k in data)
        cur = self.conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({marks})", data)
        return int(cur.lastrowid)

    def update(self, table: str, rec_id: int, data: dict) -> None:
        sets = ", ".join(f"{k} = :{k}" for k in data)
        params = dict(data, _id=rec_id)
        self.conn.execute(f"UPDATE {table} SET {sets} WHERE id = :_id", params)

    def delete(self, table: str, rec_id: int) -> None:
        self.conn.execute(f"DELETE FROM {table} WHERE id = ?", (rec_id,))

    # --------------------------------------------------------------- backup
    def backup(self, keep: int = 15) -> Path | None:
        """Онлајн резервна копија (безбедна и кога базата е отворена)."""
        if not self.path.exists():
            return None
        paths.ensure_dir(paths.BACKUPS_DIR)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = paths.BACKUPS_DIR / f"{self.path.stem}_{stamp}.db"
        try:
            with sqlite3.connect(target) as dest:
                self.conn.backup(dest)
        except sqlite3.Error as exc:
            log.warning("Неуспешна резервна копија: %s", exc)
            return None
        self._prune_backups(keep)
        log.info("Резервна копија: %s", target.name)
        return target

    def _prune_backups(self, keep: int) -> None:
        files = sorted(
            paths.BACKUPS_DIR.glob(f"{self.path.stem}_*.db"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        for old in files[max(keep, 1):]:
            try:
                old.unlink()
            except OSError:
                pass

    def export_copy(self, target: Path) -> Path:
        """Рачно зачувување на копија од базата на избрано место."""
        target = Path(target)
        paths.ensure_dir(target.parent)
        with sqlite3.connect(target) as dest:
            self.conn.backup(dest)
        return target

    def import_copy(self, source: Path) -> None:
        """Враќање од резервна копија (базата се затвора и се заменува)."""
        source = Path(source)
        if not source.exists():
            raise FileNotFoundError(source)
        # Провери дали е валидна SQLite база пред да се препише постоечката.
        probe = sqlite3.connect(source)
        try:
            probe.execute("SELECT count(*) FROM sqlite_master").fetchone()
        finally:
            probe.close()
        self.close()
        shutil.copy2(source, self.path)

    def close(self) -> None:
        try:
            self.conn.execute("PRAGMA optimize")
            self.conn.close()
        except sqlite3.Error:
            pass


_db: Database | None = None


def db() -> Database:
    if _db is None:
        raise RuntimeError("Базата не е отворена. Повикај open_database() прво.")
    return _db


def open_database(path: Path) -> Database:
    global _db
    _db = Database(path)
    return _db


def close_database() -> None:
    global _db
    if _db is not None:
        _db.close()
        _db = None
