#!/bin/sh
# Пуштање на MikroERP на Linux.
cd "$(dirname "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
    echo "Недостасува python3.  Debian/Ubuntu:  sudo apt install python3"
    exit 1
fi
if ! python3 -c "import tkinter" >/dev/null 2>&1; then
    echo "Недостасува tkinter.  Debian/Ubuntu:  sudo apt install python3-tk"
    echo "                      Fedora:         sudo dnf install python3-tkinter"
    exit 1
fi
exec python3 main.py "$@"
